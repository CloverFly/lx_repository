//
//  SelectItemViewController.h
//  CS_ZJTK
//
//  Created by Clover on 13-11-15.
//  Copyright (c) 2013年 Clover. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef enum 
{
    E_AS_TYPE = 0x88,
    E_BS_TYPE ,
    E_CS_TYPE ,
    E_DS_TYPE
    
}SELECT_TYPE;

@interface SelectItemViewController : UIViewController
<UITableViewDelegate,UITableViewDataSource>
{
    
}
@property(nonatomic,assign) id delegate;
@property(nonatomic)SELECT_TYPE m_Type;
@property (strong, nonatomic) IBOutlet UILabel *m_TitleLabel;
@property(strong,nonatomic)NSDictionary*m_BasicInfo;
-(id)initWithBasicInfo:(NSDictionary *)aBsicInfo;

@end

@protocol SelectItemDelegate <NSObject>

@optional

@required
-(void)selectItem:(SelectItemViewController *)selectItemVC re_SAIndex:(int)aIndex;
-(void)selectItem:(SelectItemViewController *)selectItemVC re_SBIndex:(int)aIndex;
-(void)selectItem:(SelectItemViewController *)selectItemVC re_SCIndex:(int)aIndex;
-(void)selectItem:(SelectItemViewController *)selectItemVC re_SDIndex:(int)aIndex;

@end
