//
//  SelectItemViewController.m
//  CS_ZJTK
//
//  Created by Clover on 13-11-15.
//  Copyright (c) 2013年 Clover. All rights reserved.
//

#import "SelectItemViewController.h"
#import "ZJTK_PopCell.h"
@interface SelectItemViewController ()

@end

@implementation SelectItemViewController

@synthesize delegate;

@synthesize m_TitleLabel;
@synthesize m_BasicInfo;
@synthesize m_Type;

-(id)initWithBasicInfo:(NSDictionary *)aBsicInfo
{
    if (self == [super init])
    {
        self.m_BasicInfo = aBsicInfo;
    }
    return self;
}


- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
	return YES;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    self.m_TitleLabel.text = [self.m_BasicInfo objectForKey:@"title"];
    
}
#pragma mark    UITableViewDataSource

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return  [[self.m_BasicInfo objectForKey:@"arr"]count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
     static NSString *identifier = @"ZJTK_PopCell";
     
     ZJTK_PopCell *cell = (ZJTK_PopCell*)[tableView dequeueReusableCellWithIdentifier:identifier];
     if (cell == nil)
     {
         cell = [[[NSBundle mainBundle] loadNibNamed:@"ZJTK_PopCell" owner:self options:nil] objectAtIndex:0];
         cell.selectionStyle = UITableViewCellSelectionStyleNone;
     
     }
     cell.m_titleLabel.text = [[self.m_BasicInfo objectForKey:@"arr"] objectAtIndex:[indexPath row]];
    return cell;
}

#pragma mark UITableViewDelegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 35;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    switch (m_Type)
    {
        case E_AS_TYPE:
            [delegate selectItem:self re_SAIndex:[indexPath row]];
            break;
        case E_BS_TYPE:
            [delegate selectItem:self re_SBIndex:[indexPath row]];
            break;
        case E_CS_TYPE:
            [delegate selectItem:self re_SCIndex:[indexPath row]];
            break;
        case E_DS_TYPE:
            [delegate selectItem:self re_SDIndex:[indexPath row]];
            break;
        default:
            break;
    }
}
@end
