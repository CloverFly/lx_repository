//
//  ViewController.m
//  CS_ZJTK
//
//  Created by Clover on 13-11-15.
//  Copyright (c) 2013年 Clover. All rights reserved.
//

#import "ViewController.h"
#import "SelectItemViewController.h"
#import "SDWebImageManager.h"
#import <QuartzCore/QuartzCore.h>


@interface ViewController ()

@property (nonatomic, strong)UIPopoverController *showwarnPopoverController;
@property (strong, nonatomic) IBOutlet UIImageView*testImageView;
@property (strong, nonatomic) IBOutlet UILabel*KK;
@end

@implementation ViewController

@synthesize testImageView;
@synthesize KK;

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    
    NSURL*url = [NSURL URLWithString:@"http://img.cqsq.com/thumb/1311/thread/74_968292_189f65a4a97c5e1.jpg"];
    [[SDImageCache sharedImageCache] clearDisk];
    
    
    
    [[SDWebImageManager sharedManager] downloadWithURL:url
                                               options:SDWebImageLowPriority
                                              progress:^(NSUInteger receivedSize, long long expectedSize)
     {
         KK.text = [NSString stringWithFormat:@"%d%@",(int)(receivedSize*100/expectedSize),@"%"];
         
     }
                                             completed:^(UIImage *aImage, NSError *error, SDImageCacheType cacheType, BOOL finished)
     {
         if (finished)
         {
             testImageView.image = aImage;
             
         }
     }];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(IBAction)kk:(UIButton*)sender
{
    NSMutableDictionary*aDic = [[NSMutableDictionary alloc] init];
    [aDic setObject:@"AA" forKey:@"title"];
    [aDic setObject:[NSArray arrayWithObjects:
                     @"离离原上草",
                     @"一岁一枯荣",
                     @"野火烧不尽",
                     @"春风吹又生",
                     nil] forKey:@"arr"];
    SelectItemViewController *warnPop = [[SelectItemViewController alloc]initWithBasicInfo:aDic];
    [warnPop setContentSizeForViewInPopover:CGSizeMake(200, 400)];
    
    switch (sender.tag)
    {
        case 10:
            warnPop.m_Type = E_AS_TYPE;
            break;
        case 11:
            warnPop.m_Type = E_BS_TYPE;
            break;
        case 12:
            warnPop.m_Type = E_CS_TYPE;
            break;
        case 13:
            warnPop.m_Type = E_DS_TYPE;
            break;
        default:
            break;
    }
    
    warnPop.delegate = self;
    
    
    
    self.showwarnPopoverController = [[UIPopoverController alloc] initWithContentViewController:warnPop];
    [self.showwarnPopoverController presentPopoverFromRect:sender.frame inView:[(UIButton *)sender superview] permittedArrowDirections:UIPopoverArrowDirectionUp animated:YES];
}

-(void)selectItem:(SelectItemViewController *)selectItemVC re_SAIndex:(int)aIndex
{
    NSArray*arr = [NSArray arrayWithObjects:
     @"离离原上草",
     @"一岁一枯荣",
     @"野火烧不尽",
     @"春风吹又生",
     nil];
    NSLog(@"A--%@",[arr objectAtIndex:aIndex]);
    [self.showwarnPopoverController dismissPopoverAnimated:YES];
}
-(void)selectItem:(SelectItemViewController *)selectItemVC re_SBIndex:(int)aIndex
{
    NSArray*arr = [NSArray arrayWithObjects:
                   @"离离原上草",
                   @"一岁一枯荣",
                   @"野火烧不尽",
                   @"春风吹又生",
                   nil];
    NSLog(@"B--%@",[arr objectAtIndex:aIndex]);
    [self.showwarnPopoverController dismissPopoverAnimated:YES];
}
-(void)selectItem:(SelectItemViewController *)selectItemVC re_SCIndex:(int)aIndex
{
    NSArray*arr = [NSArray arrayWithObjects:
                   @"离离原上草",
                   @"一岁一枯荣",
                   @"野火烧不尽",
                   @"春风吹又生",
                   nil];
    NSLog(@"C--%@",[arr objectAtIndex:aIndex]);
    [self.showwarnPopoverController dismissPopoverAnimated:YES];
}
-(void)selectItem:(SelectItemViewController *)selectItemVC re_SDIndex:(int)aIndex
{
//    NSArray*arr = [NSArray arrayWithObjects:
//                   @"离离原上草",
//                   @"一岁一枯荣",
//                   @"野火烧不尽",
//                   @"春风吹又生",
//                   nil];
//    NSLog(@"D--%@",[arr objectAtIndex:aIndex]);
//    
//    
//    
    NSURL*url = [NSURL URLWithString:@"http://img.cqsq.com/thumb/1311/thread/74_968292_189f65a4a97c5e1.jpg"];
    [[SDImageCache sharedImageCache] clearDisk];
    
    
    
    [[SDWebImageManager sharedManager] downloadWithURL:url
                                               options:SDWebImageLowPriority
                                              progress:^(NSUInteger receivedSize, long long expectedSize)
     {
         KK.text = [NSString stringWithFormat:@"%d%@",(int)(receivedSize*100/expectedSize),@"%"];
         
     }
                                             completed:^(UIImage *aImage, NSError *error, SDImageCacheType cacheType, BOOL finished)
     {
         if (finished)
         {
             testImageView.image = aImage;
             
         }
     }];
    [self.showwarnPopoverController dismissPopoverAnimated:YES];
}
@end
