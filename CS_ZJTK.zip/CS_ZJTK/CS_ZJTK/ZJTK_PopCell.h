//
//  ZJTK_PopCell.h
//  CS_ZJTK
//
//  Created by Clover on 13-11-15.
//  Copyright (c) 2013年 Clover. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZJTK_PopCell : UITableViewCell
@property(nonatomic,strong)IBOutlet UILabel*m_titleLabel;
@end
