//
//  LxAppDelegate.h
//  CloverWaterFall
//
//  Created by Clover on 14-7-5.
//  Copyright (c) 2014年 Clover. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LxAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
