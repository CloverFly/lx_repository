//
//  LxWaterFallCell.h
//  CloverWaterFall
//
//  Created by Clover on 14-7-5.
//  Copyright (c) 2014年 Clover. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LxWaterFallCell : UICollectionViewCell

@property(nonatomic,strong)IBOutlet UIImageView*m_cellImageView;
@property(nonatomic,strong)IBOutlet UILabel*m_Label;


@end
