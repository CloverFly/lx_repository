//
//  LxWeatherCell.h
//  CloverWaterFall
//
//  Created by Clover on 14-7-8.
//  Copyright (c) 2014年 Clover. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LxWeatherCell : UICollectionViewCell

@end
