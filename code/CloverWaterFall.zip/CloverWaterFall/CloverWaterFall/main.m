//
//  main.m
//  CloverWaterFall
//
//  Created by Clover on 14-7-5.
//  Copyright (c) 2014年 Clover. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "LxAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([LxAppDelegate class]));
    }
}
