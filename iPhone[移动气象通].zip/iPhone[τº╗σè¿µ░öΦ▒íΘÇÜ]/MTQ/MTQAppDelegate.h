//
//  MTQAppDelegate.h
//  MTQ
//
//  Created by lesogo on 13-12-9.
//  Copyright (c) 2013年 Lesogo. All rights reserved.
//

#import <UIKit/UIKit.h>

#import <MessageUI/MessageUI.h>

#import "GetLocation.h"
#import "ASIFormDataRequest.h"

@interface MTQAppDelegate : UIResponder
<UIApplicationDelegate,GetLocationDelegate,UIAlertViewDelegate,
MFMessageComposeViewControllerDelegate>
{
    GetLocation *m_GetLocation;
    BOOL isFull;
}

@property (strong, nonatomic) GetLocation *m_GetLocation;

@property (nonatomic) BOOL            isFull;
@property (nonatomic) BOOL            isWifiAddress;
@property (strong, nonatomic) NSString              *m_NewVersionUrlString;
@property (strong, nonatomic) UIWindow              *window;
@property (strong, nonatomic) UINavigationController*navController;

-(void)DeviceRegister:(NSString*)aTokenString :(BOOL)isStartSoft;//设备注册
-(void)sumbitCityList;//同步本地城市列表

-(void)checkVersion;//版本监测

@end
