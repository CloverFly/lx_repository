//
//  MTQAppDelegate.m
//  MTQ
//
//  Created by lesogo on 13-12-9.
//  Copyright (c) 2013年 Lesogo. All rights reserved.
//

#import "MTQAppDelegate.h"

#import "MTQ_WeatherReport_ViewController.h"
#import "MTQ_Logo_ViewController.h"
#import "MainTabBarViewController.h"
#import "VideoPlaySDK.h"
@implementation MTQAppDelegate

@synthesize isFull;
@synthesize navController;
@synthesize window = _window;
@synthesize isWifiAddress;
@synthesize m_GetLocation;

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    isFull = NO;
    isWifiAddress = NO;
    
    //版本监测
    [self checkVersion];
    
    //数据库
    DBMSEngine *TempDBMSEngine = [[DBMSEngine alloc] init];
    TempDBMSEngine = nil;
    
    //上传城市列表
    [self sumbitCityList];
    
    //定位
    self.m_GetLocation = [[GetLocation alloc] initWithDelegate:self];
    [self.m_GetLocation startUpdateLocation];
    
    //设备注册
    if ([Tools readUserDefaultsInfo:K_guide])
    {
        [self DeviceRegister:nil :YES];
        
        //注册通知
        [[UIApplication sharedApplication] registerForRemoteNotificationTypes:
         UIRemoteNotificationTypeBadge |
         UIRemoteNotificationTypeAlert |
         UIRemoteNotificationTypeSound];
    }
    
    //window
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    
    MainTabBarViewController*viewCtri = [[MainTabBarViewController alloc] init];
    MTQ_Logo_ViewController *viewCtri2 = [[MTQ_Logo_ViewController alloc] init];
    navController = [[UINavigationController alloc] initWithRootViewController:[Tools readUserDefaultsInfo:K_guide]?viewCtri:viewCtri2];
    navController.navigationBarHidden = YES;
    
    self.window.rootViewController = navController;
    self.window.backgroundColor = [UIColor whiteColor];
    [self.window makeKeyAndVisible];
    // 初始化sdk
    VP_InitSDK();
    return YES;
}

- (void)application:(UIApplication *)application
didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)newDeviceToken
{
	//通知注册回调函数 返回newDeviceToken
	NSString *tempTokenString = [[NSString stringWithFormat:@"%@",newDeviceToken] stringByReplacingOccurrencesOfString:@"<" withString:@""];
	tempTokenString = [tempTokenString stringByReplacingOccurrencesOfString:@">" withString:@""];
	tempTokenString = [tempTokenString stringByReplacingOccurrencesOfString:@" " withString:@""];
    
    [self DeviceRegister:tempTokenString :YES];
}

- (void)application:(UIApplication *)application didFailToRegisterForRemoteNotificationsWithError:(NSError *)error
{
}


- (void)applicationWillResignActive:(UIApplication *)application
{
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    application.applicationIconBadgeNumber = 0;

    self.m_GetLocation = nil;
    self.m_GetLocation = [[GetLocation alloc] initWithDelegate:self];
    [self.m_GetLocation startUpdateLocation];
    
}

-(NSUInteger)application:(UIApplication *)application supportedInterfaceOrientationsForWindow:(UIWindow *)window
{
    if(isFull)
    {
        return UIInterfaceOrientationMaskAllButUpsideDown;
    }
    
    return UIInterfaceOrientationMaskPortrait;
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    application.applicationIconBadgeNumber = 0;
}

- (void)applicationWillTerminate:(UIApplication *)application
{
}

-(void)DeviceRegister:(NSString*)aTokenString :(BOOL)isStartSoft
{
    //设备注册
    NSURL *urlss = [NSURL URLWithString:[URL sumbitDeviceRegister]];
    ASIFormDataRequest *httpPostRequest = [ ASIFormDataRequest requestWithURL:urlss];
    [httpPostRequest setStringEncoding :NSUTF8StringEncoding];//设置数据类型为utf-8
    [httpPostRequest setPostValue:[Tools getMacAddress] forKey:K_deviceCode];
    if (aTokenString)
    {
        [httpPostRequest setPostValue:aTokenString forKey:K_pushCode];
    }
    [httpPostRequest setPostValue:@"1" forKey:K_system];
    
    DBMSEngine *tempEngine = [[DBMSEngine alloc] init];
    NSArray *dbDataArray = [tempEngine querryCityWeather];
    if (dbDataArray && dbDataArray.count)
    {
        DB_CityInfo *tempInfo = (DB_CityInfo*)[dbDataArray objectAtIndex:0];
        if (tempInfo && tempInfo.db_islocation && [tempInfo.db_islocation integerValue]==1)
        {
            [httpPostRequest setPostValue:tempInfo.db_cityId forKey:K_cityId];
        }
    }
    [httpPostRequest setDelegate:self];
    if (aTokenString)
    {
        [httpPostRequest setDidFinishSelector : @selector(responseComplete_deviceRegister_noTipsSendMessage:)];
    }
    else
    {
        if (isStartSoft)
        {
            if ([Tools getTokenString])
            {
                [httpPostRequest setDidFinishSelector : @selector(responseComplete_deviceRegister_noTipsSendMessage:)];
            }
            else
            {
                [httpPostRequest setDidFinishSelector : @selector(responseComplete_deviceRegister:)];
            }
        }
        else
        {
            [httpPostRequest setDidFinishSelector : @selector(responseComplete_deviceRegister:)];
        }
    }
    [httpPostRequest setDidFailSelector : @selector(responseFial_deviceRegister:)];
    [httpPostRequest startAsynchronous];
}

/**
 * 上传本地数据库城市列表
 */
-(void)sumbitCityList
{
    NSMutableString *keyString = [[NSMutableString alloc] init];
    
    DBMSEngine *tempEngine = [[DBMSEngine alloc] init];
    NSMutableArray *dataArray = [tempEngine querryCityWeather];
    for (DB_CityInfo *cityInfo in dataArray)
    {
        if (cityInfo && cityInfo.db_cityId)
        {
            [keyString appendFormat:@"%@,",cityInfo.db_cityId];
        }
    }
    
    NSURL *urlss = [NSURL URLWithString:[URL sumbitCityForSevicer]];
    ASIFormDataRequest *httpFormDataRequest = [ ASIFormDataRequest requestWithURL:urlss];
    [httpFormDataRequest setStringEncoding :NSUTF8StringEncoding];//设置数据类型为utf-8
    [httpFormDataRequest setPostValue:[Tools getMacAddress] forKey:K_deviceCode];
    [httpFormDataRequest setPostValue:[Tools getTokenString] forKey:K_token];
    [httpFormDataRequest setPostValue:keyString forKey:K_cityId];
    [httpFormDataRequest setDelegate:self];
    [httpFormDataRequest setDidFinishSelector : nil];
    [httpFormDataRequest setDidFailSelector : nil];
    [httpFormDataRequest startAsynchronous];
}

//版本监测
-(void)checkVersion
{
    NSURL *urlss = [NSURL URLWithString:[URL get_VersionCheckUrl]];
    ASIFormDataRequest *httpPostRequest = [ ASIFormDataRequest requestWithURL:urlss];
    [httpPostRequest setStringEncoding :NSUTF8StringEncoding];//设置数据类型为utf-8
    [httpPostRequest setPostValue:@"iphone" forKey:K_mobile];
    [httpPostRequest setPostValue:@"public" forKey:K_type];
    [httpPostRequest setPostValue:KVersionNum forKey:K_version];
    [httpPostRequest setDelegate:self];
    [httpPostRequest setDidFinishSelector : @selector(responseComplete_Version:)];
    [httpPostRequest setDidFailSelector : nil];
    [httpPostRequest startAsynchronous];
}


- (void)showMessageView:(int)aTag
{
    if( [MFMessageComposeViewController canSendText])
    {
        if (aTag==1)
        {
            //激活短信
            MFMessageComposeViewController * controller = [[MFMessageComposeViewController alloc]init];
            controller.recipients = [NSArray arrayWithObject:@"10658555002"];
            controller.body = [NSString stringWithFormat:@"[请点击发送此短信完成鉴权]2%@",[Tools getMacAddress]];
            controller.messageComposeDelegate = self;
            controller.view.tag = 0x111;
            [self.navController presentModalViewController:controller animated:YES];
        }
        else if(aTag == 2)
        {
            //定制短信
            MFMessageComposeViewController * controller = [[MFMessageComposeViewController alloc]init];
            controller.recipients = [NSArray arrayWithObject:@"10658555002"];
            controller.body = @"tqyb[请点击发送此短信完成定制]";
            controller.messageComposeDelegate = self;
            controller.view.tag = 0x222;
            [self.navController presentModalViewController:controller animated:YES];
        }
    }
    else
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"温馨提醒"
                                                        message:@"设备没有短信功能!"
                                                       delegate:nil
                                              cancelButtonTitle:nil
                                              otherButtonTitles:@"确定", nil];
        [alert show];
    }
}

#pragma mark --
#pragma mark MFMessageComposeViewControllerDelegate

- (void)messageComposeViewController:(MFMessageComposeViewController *)controller didFinishWithResult:(MessageComposeResult)result
{
    [controller dismissModalViewControllerAnimated:NO];//关键的一句   不能为YES
    
    switch (result)
    {
        case MessageComposeResultCancelled:       
            break;
        case MessageComposeResultFailed:
            break;
        case MessageComposeResultSent:
            if (controller.view.tag == 0x111)
            {
                [Tools saveUserDefaultsInfo:[NSDate date] :@"ActiveMessage"];
            }
            else if(controller.view.tag == 0x222)
            {
                [Tools saveUserDefaultsInfo:[NSDate date] :@"CustomMessage"];
            }
            break;
        default:
            break;
    }
}

#pragma mark
#pragma mark UIAlertViewDelegate

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (alertView.tag == 300)
    {
        if (buttonIndex)
        {
            if (self.m_NewVersionUrlString)
            {
                NSURL *url = [NSURL URLWithString:self.m_NewVersionUrlString];
                [[UIApplication sharedApplication] openURL:url];
            }
        }
    }
    else if(alertView.tag == 500)
    {
        if (buttonIndex)
        {
            [self showMessageView:1];
        }
    }
    else if(alertView.tag == 600)
    {
        if (buttonIndex)
        {
            [self showMessageView:2];
        }
    }
}

#pragma mark --
#pragma mark GetLocationDelegate

-(void)getNoLocation
{
}

-(void)getLocation:(GetLocation *)aGetLocation reCityInfo:(NSDictionary*)aCityInfo
{
    if (aCityInfo && [aCityInfo valueForKey:K_station])
    {
        //保存当前地理信息
        [Tools saveUserDefaultsInfo:aCityInfo :K_userLoactionInfo];
        NSString *locationKeyString = [aCityInfo valueForKey:K_station];
        
        CLLocation *location = (CLLocation*)[aCityInfo valueForKey:K_location];
        DB_CityInfo *locationCityInfo = [[DB_CityInfo alloc] init];
        locationCityInfo.db_islocation = @"1";
        locationCityInfo.db_cityId = locationKeyString;
        locationCityInfo.db_cityName = [aCityInfo valueForKey:K_county];
        locationCityInfo.db_latitude = [NSString stringWithFormat:@"%f",location.coordinate.latitude];
        locationCityInfo.db_longitude = [NSString stringWithFormat:@"%f",location.coordinate.longitude];
        
        DBMSEngine *TempDBMSEngine = [[DBMSEngine alloc] init];
        [TempDBMSEngine updateLocationInfo:locationCityInfo];
        TempDBMSEngine = nil;
        
        UIViewController *viewCtr = self.navController.topViewController;
        if ([viewCtr isKindOfClass:[MainTabBarViewController class]])
        {
            MainTabBarViewController *viewCtr = (MainTabBarViewController*)self.navController.topViewController;
            [viewCtr.viewController1 performSelector:@selector(loadInterface) withObject:nil afterDelay:0.01f];
        }
    }
}

#pragma mark -
#pragma mark ASIFormDataRequest-设备注册

-( void )responseFial_deviceRegister:(ASIFormDataRequest*)request
{
    AppDelegate.window.userInteractionEnabled = YES;
}

-( void )responseComplete_deviceRegister:(ASIFormDataRequest*)request
{
    AppDelegate.window.userInteractionEnabled = YES;
    NSDictionary *dic = [[request responseString] JSONValue];
    if(dic)
    {
        if ([[dic valueForKey:K_status] integerValue] == 200)
        {
            NSDictionary *oldDicitonary = [Tools readUserDefaultsInfo:K_token];
            [Tools saveUserDefaultsInfo:dic :K_token];
            if ([Tools isCustomized])
            {
                [Tools removeUserDefaults:@"ActiveMessage"];
                [Tools removeUserDefaults:@"CustomMessage"];
            }
            else
            {
                int auth = [[dic valueForKey:K_auth] integerValue];
                if (auth == 4)
                {
                    //已经退订
                    if (oldDicitonary)
                    {
                        int oldAuth = [[oldDicitonary valueForKeyPath:K_auth] intValue];
                        if (oldAuth == 4)
                        {
                            NSDate *tempDate = [Tools readUserDefaultsInfo:@"CustomMessage"];
                            NSDate *nowDate = [NSDate date];
                            if (tempDate)
                            {
                                NSDate *saveDate = [tempDate addTimeInterval:60*60];
                                if ([nowDate compare:saveDate] != NSOrderedDescending)
                                {
                                    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"温馨提醒"
                                                                                    message:@"你的定制信息正在验证中,请稍候再试!"
                                                                                   delegate:nil
                                                                          cancelButtonTitle:nil
                                                                          otherButtonTitles:@"确定", nil];
                                    [alert show];
                                    return;
                                }
                            }
                            //提示是否发送
                            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"温馨提醒"
                                                                                message:@"尊敬的用户：您还没有订购四川移动气象通-城市天气业务。仅需每月2元，即可享用地图查看、趋势预报、视频播报及每日天气短信等全部功能。现在是否需要定制？"
                                                                               delegate:self
                                                                      cancelButtonTitle:nil
                                                                      otherButtonTitles:@"否",@"是", nil];
                            alertView.tag = 600;
                            [alertView show];
                        }
                        else if(oldAuth != 4)
                        {
                            [Tools removeUserDefaults:@"ActiveMessage"];
                            [Tools removeUserDefaults:@"CustomMessage"];
                            
                            //提示是否发送
                            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"温馨提醒"
                                                                                message:@"尊敬的用户：您还没有订购四川移动气象通-城市天气业务。仅需每月2元，即可享用地图查看、趋势预报、视频播报及每日天气短信等全部功能。现在是否需要定制？"
                                                                               delegate:self
                                                                      cancelButtonTitle:nil
                                                                      otherButtonTitles:@"否",@"是", nil];
                            alertView.tag = 600;
                            [alertView show];
                        }
                    }
                }
                else if (auth == 3)
                {
                    //激活
                    NSDate *tempDate = [Tools readUserDefaultsInfo:@"ActiveMessage"];
                    NSDate *nowDate = [NSDate date];
                    if (tempDate)
                    {
                        NSDate *saveDate = [tempDate addTimeInterval:60*60];
                        if ([nowDate compare:saveDate] != NSOrderedDescending)
                        {
                            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"温馨提醒"
                                                                            message:@"你的激活信息正在验证中,请稍候再试!"
                                                                           delegate:nil
                                                                  cancelButtonTitle:nil
                                                                  otherButtonTitles:@"确定", nil];
                            [alert show];
                            return;
                        }
                    }
                    //提示是否发送
                    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"温馨提醒"
                                                                        message:@"￼发送短信至服务器激活客户端，本次操作将产生的费用由运营商收取。"
                                                                       delegate:self
                                                              cancelButtonTitle:nil
                                                              otherButtonTitles:@"否",@"是", nil];
                    alertView.tag = 500;
                    [alertView show];
                }
                else if(auth == 1)
                {
                     //定制
                    NSDate *tempDate = [Tools readUserDefaultsInfo:@"CustomMessage"];
                    NSDate *nowDate = [NSDate date];
                    if (tempDate)
                    {
                        NSDate *saveDate = [tempDate addTimeInterval:60*60];
                        if ([nowDate compare:saveDate] != NSOrderedDescending)
                        {
                            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"温馨提醒"
                                                                            message:@"你的定制信息正在验证中,请稍候再试!"
                                                                           delegate:nil
                                                                  cancelButtonTitle:nil
                                                                  otherButtonTitles:@"确定", nil];
                            [alert show];
                            return;
                        }
                    }
                    //提示是否发送
                    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"温馨提醒"
                                                                        message:@"尊敬的用户：您还没有订购四川移动气象通-城市天气业务。仅需每月2元，即可享用地图查看、趋势预报、视频播报及每日天气短信等全部功能。现在是否需要定制？"
                                                                       delegate:self
                                                              cancelButtonTitle:nil
                                                              otherButtonTitles:@"否",@"是", nil];
                    alertView.tag = 600;
                    [alertView show];
                }
            }
        }
	}
}
-( void )responseComplete_deviceRegister_noTipsSendMessage:(ASIFormDataRequest*)request
{
    //设备注册不提示发送短信
    AppDelegate.window.userInteractionEnabled = YES;
    NSDictionary *dic = [[request responseString] JSONValue];
    if(dic)
    {
        if ([[dic valueForKey:K_status] integerValue] == 200)
        {
            [Tools saveUserDefaultsInfo:dic :K_token];
            if ([Tools isCustomized])
            {
                [Tools removeUserDefaults:@"ActiveMessage"];
                [Tools removeUserDefaults:@"CustomMessage"];
            }
        }
    }
}

#pragma mark -
#pragma mark ASIFormDataRequest-版本监测

-( void )responseComplete_Version:(ASIFormDataRequest*)request
{
    NSDictionary *dic = [[request responseString] JSONValue];
    if(dic)
    {
        self.m_NewVersionUrlString = [dic valueForKey:K_url];
        if (self.m_NewVersionUrlString && [self.m_NewVersionUrlString isKindOfClass:[NSString class]] && self.m_NewVersionUrlString.length>10)
        {
            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"亲，有最新版本"
                                                                message:@"是否更新？"
                                                               delegate:self
                                                      cancelButtonTitle:nil
                                                      otherButtonTitles:@"下次更新",@"立即更新", nil];
            alertView.tag = 300;
            [alertView show];
        }
	}
}

@end
