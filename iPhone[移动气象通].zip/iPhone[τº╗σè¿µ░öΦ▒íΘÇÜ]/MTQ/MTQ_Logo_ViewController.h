//
//  MTQ_Logo_ViewController.h
//  scMobileWeather
//  等待界面
//  Created by 小呆 on 14-1-3.
//  Copyright (c) 2014年 Lesogo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MTQ_Logo_ViewController : UIViewController
<UIScrollViewDelegate>

@property(nonatomic,strong) IBOutlet UIScrollView   *m_ScrollView;
@property(nonatomic,strong) IBOutlet UIView         *m_interfaceView;

-(IBAction)nextInterfaceBtPressed:(id)sender;

@end
