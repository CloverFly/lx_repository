//
//  MTQ_Logo_ViewController.m
//  scMobileWeather
//
//  Created by 小呆 on 14-1-3.
//  Copyright (c) 2014年 Lesogo. All rights reserved.
//

#import "MTQ_Logo_ViewController.h"
#import "MainTabBarViewController.h"

@implementation MTQ_Logo_ViewController

-(id)init
{
    if (iPhone5)
    {
        self = [super initWithNibName:@"MTQ_Logo_ViewController_ip5" bundle:nil];
    }
    else
    {
        self = [super initWithNibName:@"MTQ_Logo_ViewController" bundle:nil];
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidLoad
{
    [super viewDidLoad];
  
    //保存当前的版本号
    [Tools saveUserDefaultsInfo:@"" :K_guide];
    
    self.m_ScrollView.contentSize = CGSizeMake(self.m_interfaceView.frame.size.width, self.m_interfaceView.frame.size.height-50);
}


-(IBAction)nextInterfaceBtPressed:(id)sender
{
    [AppDelegate DeviceRegister:nil :NO];
    [self registerNotifi];
    
    MainTabBarViewController *viewCtr = [[MainTabBarViewController alloc] init];
    [self.navigationController pushViewController:viewCtr animated:YES];
}

-(void)registerNotifi
{
    //注册通知
    [[UIApplication sharedApplication] registerForRemoteNotificationTypes:
     UIRemoteNotificationTypeBadge |
     UIRemoteNotificationTypeAlert |
     UIRemoteNotificationTypeSound];
}




@end
