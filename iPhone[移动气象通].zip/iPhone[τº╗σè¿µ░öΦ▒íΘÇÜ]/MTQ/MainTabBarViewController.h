//
//  MainTabBarViewController.h
//  scMobileWeather
//
//  Created by lesogo on 14-2-20.
//  Copyright (c) 2014年 Lesogo. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "MTQ_WeatherReport_ViewController.h"

@interface MainTabBarViewController : UITabBarController
{
    UIImageView *tempViews;
    MTQ_WeatherReport_ViewController    *viewController1;
}

@property(nonatomic,strong) MTQ_WeatherReport_ViewController    *viewController1;

@end
