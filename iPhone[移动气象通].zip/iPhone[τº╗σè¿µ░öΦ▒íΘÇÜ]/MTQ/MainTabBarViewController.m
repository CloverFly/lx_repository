//
//  MainTabBarViewController.m
//  scMobileWeather
//
//  Created by lesogo on 14-2-20.
//  Copyright (c) 2014年 Lesogo. All rights reserved.
//

#import "MainTabBarViewController.h"

#import "MTQ_WeatherReport_ViewController.h"
#import "MTQ_LiveMonitoring_ViewController.h"
#import "MTQ_Voide_ViewController.h"
#import "MainViewController.h"
#import "MTQ_QSViewController.h"

#define KMainTabBarDefaultTag   100

@implementation MainTabBarViewController

@synthesize viewController1;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void) hideTabBar
{
	for(UIView *view in self.view.subviews)
	{
		if([view isKindOfClass:[UITabBar class]])
		{
			view.hidden = YES;
		}
		else
		{
            if (iPhone5)
            {
                [view setFrame:CGRectMake(view.frame.origin.x, view.frame.origin.y, view.frame.size.width, 568)];
            }
            else
            {
                [view setFrame:CGRectMake(view.frame.origin.x, view.frame.origin.y, view.frame.size.width, 480)];
            }
		}
	}
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    [self hideTabBar];
    
    CGSize  buttonsize = CGSizeMake(64,44.0);//按钮的大小
    CGFloat barHeight = 44.0;//整个bar栏的高度
    CGFloat upDistance = (barHeight-buttonsize.height)/2.0;//上间距
    CGFloat lineDistance = 0.0;
    CGFloat leftDistance = (self.view.frame.size.width-buttonsize.width*5-lineDistance*4)/2.0;//左间距
    
    //背景
	tempViews = [[UIImageView alloc] initWithFrame:CGRectMake(0.0, self.view.frame.size.height-barHeight, self.view.frame.size.width, barHeight)];
    tempViews.image = [UIImage imageNamed:@"main_bg.png"];
    tempViews.userInteractionEnabled = YES;
    tempViews.backgroundColor = [UIColor blackColor];
	[self.view addSubview:tempViews];
    //按钮
    NSArray *NameArrays = [NSArray arrayWithObjects:@"main_1.png",@"main_2.png",@"main_3.png",@"main_4.png",@"main_5.png", nil];
    NSArray *SelectNameArrays = [NSArray arrayWithObjects:@"main_1s.png",@"main_2s.png",@"main_3s.png",@"main_4s.png",@"main_5s.png", nil];
    for (int i=0; i<5; i++)
    {
        UIButton *buttons = [[UIButton alloc] initWithFrame:CGRectMake(leftDistance+i*(buttonsize.width+lineDistance), upDistance,
                                                                       buttonsize.width, buttonsize.height)];
        buttons.tag = KMainTabBarDefaultTag+i;
        buttons.backgroundColor = [UIColor clearColor];
        [buttons setBackgroundImage:[UIImage imageNamed:[NameArrays objectAtIndex:i]] forState:UIControlStateNormal];
        [buttons setBackgroundImage:[UIImage imageNamed:[SelectNameArrays objectAtIndex:i]] forState:UIControlStateHighlighted];
        [buttons setBackgroundImage:[UIImage imageNamed:[NameArrays objectAtIndex:i]] forState:UIControlStateSelected];
        [buttons addTarget:nil
                    action:@selector(changeViewControllers:)
          forControlEvents:UIControlEventTouchUpInside];
        
        [tempViews addSubview:buttons];
        
        if (i == 0)
        {
            [buttons setBackgroundImage:[UIImage imageNamed:[SelectNameArrays objectAtIndex:i]] forState:UIControlStateNormal];
        }
    }
    
    //视图控制器
    self.viewController1 = [[MTQ_WeatherReport_ViewController alloc] init];
    MTQ_QSViewController                *viewController2 = [[MTQ_QSViewController alloc] init];
    MainViewController                  *viewController3 = [[MainViewController alloc] init];
    MTQ_LiveMonitoring_ViewController   *viewController4 = [[MTQ_LiveMonitoring_ViewController alloc] init];
    MTQ_Voide_ViewController            *viewController5 = [[MTQ_Voide_ViewController alloc] init];
    
	UINavigationController *navigation1 = [[UINavigationController alloc] initWithRootViewController:self.viewController1];
    UINavigationController *navigation2 = [[UINavigationController alloc] initWithRootViewController:viewController2];
    UINavigationController *navigation3 = [[UINavigationController alloc] initWithRootViewController:viewController3];
    UINavigationController *navigation4 = [[UINavigationController alloc] initWithRootViewController:viewController4];
    UINavigationController *navigation5 = [[UINavigationController alloc] initWithRootViewController:viewController5];
    navigation1.navigationBarHidden = YES;
    navigation2.navigationBarHidden = YES;
    navigation3.navigationBarHidden = YES;
    navigation4.navigationBarHidden = YES;
    navigation5.navigationBarHidden = YES;
    
    NSMutableArray *arrays = [[NSMutableArray alloc] init];
    [arrays addObject:navigation1];
	[arrays addObject:navigation2];
	[arrays addObject:viewController3];
	[arrays addObject:navigation4];
    [arrays addObject:navigation5];
    
    self.viewControllers = arrays;
	self.customizableViewControllers = arrays;
	self.selectedIndex = 0;
}

-(void)changeViewControllers:(UIButton*)sender
{
    int nowIndex = sender.tag-KMainTabBarDefaultTag;
    
    if (nowIndex == 1 || nowIndex == 4)
    {
        if (![Tools isCustomized])
        {
            AppDelegate.window.userInteractionEnabled = NO;
            [AppDelegate DeviceRegister:nil :NO];
            return;
        }
    }
    
    if (self.selectedIndex != nowIndex)
	{
        //去选中
        UIButton* buttons = (UIButton*)[tempViews viewWithTag:self.selectedIndex+KMainTabBarDefaultTag];
        [buttons setBackgroundImage:[buttons backgroundImageForState:UIControlStateSelected] forState:UIControlStateNormal];
        //高亮
        [sender setBackgroundImage:[sender backgroundImageForState:UIControlStateHighlighted] forState:UIControlStateNormal];
        
        self.selectedIndex = nowIndex;
	}
}

@end
