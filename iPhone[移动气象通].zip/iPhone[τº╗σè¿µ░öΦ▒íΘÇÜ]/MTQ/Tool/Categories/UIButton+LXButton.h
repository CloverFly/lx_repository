//
//  UIButton+LXButton.h
//  MTQ
//
//  Created by Clover on 13-12-17.
//  Copyright (c) 2013年 Lesogo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIButton (LXButton)
-(void)CustomStyleByColor:(UIColor*)aColor HighLightColor:(UIColor*)aHighLightColor;
-(void)addBorderByColor:(UIColor*)aColor;
@end
