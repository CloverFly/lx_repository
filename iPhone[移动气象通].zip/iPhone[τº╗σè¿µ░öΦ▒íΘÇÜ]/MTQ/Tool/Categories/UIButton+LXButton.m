//
//  UIButton+LXButton.m
//  MTQ
//
//  Created by Clover on 13-12-17.
//  Copyright (c) 2013年 Lesogo. All rights reserved.
//

#import "UIButton+LXButton.h"
#import <QuartzCore/QuartzCore.h>
@implementation UIButton (LXButton)
-(void)CustomStyleByColor:(UIColor*)aColor HighLightColor:(UIColor*)aHighLightColor
{
    [self bootstrapStyle];
    self.backgroundColor = aColor;
    self.layer.borderColor = [[UIColor clearColor] CGColor];
    [self setBackgroundImage:[self buttonImageFromColor:aColor] forState:UIControlStateNormal];
    [self setBackgroundImage:[self buttonImageFromColor:aHighLightColor] forState:UIControlStateHighlighted];
}

-(void)addBorderByColor:(UIColor*)aColor
{
    self.layer.cornerRadius = 4;//设置那个圆角的有多圆
    self.layer.borderWidth = 2;//设置边框的宽度，当然可以不要
    self.layer.borderColor = [aColor CGColor];//设置边框的颜色
    self.layer.masksToBounds = YES;//设为NO去试试
}
-(void)bootstrapStyle
{
    self.layer.borderWidth = 1;
    self.layer.cornerRadius = 0.0;
    self.layer.masksToBounds = YES;
    [self setAdjustsImageWhenHighlighted:NO];
    [self setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [self setTitleColor:[UIColor whiteColor] forState:UIControlStateHighlighted];
}
- (UIImage *) buttonImageFromColor:(UIColor *)color
{
    CGRect rect = CGRectMake(0, 0, self.frame.size.width, self.frame.size.height);
    UIGraphicsBeginImageContext(rect.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetFillColorWithColor(context, [color CGColor]);
    CGContextFillRect(context, rect);
    UIImage *img = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return img;
}
@end
