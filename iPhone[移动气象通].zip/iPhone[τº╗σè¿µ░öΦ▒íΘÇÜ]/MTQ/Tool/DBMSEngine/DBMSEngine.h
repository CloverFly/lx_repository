/*
 *
 *类名称:DBMSEngine
 *类功能:数据的存储类，对数据库进行了封装
 *      能进行 增－删－改－查
 */


#import <Foundation/Foundation.h>
#import <sqlite3.h>
#import <CoreLocation/CoreLocation.h>

@interface DBMSEngine : NSObject
{
    sqlite3 *database;	//数据库
	NSString *path;		//数据库路径
	BOOL	isDataBaseExit;//数据库是否创建成功
	NSArray *tableArray;//表的名称数组
}

@property(nonatomic,strong)NSArray *tableArray;

//数据库表
-(void)loadtableArray;
//当前数据库的路径
-(void)currentDataBasePath;
//打开数据库
-(void)openDataBase;
//创建表
-(void)createTable;

//-------通用-------
-(void)cleanTable:(NSInteger)aTableIndex;//清空该表
-(void)deleteData:(NSInteger)aTableIndex setId:(NSString*)aId;//删除一条消息数据

/*
 *  城市天气
 *输入:
 *  aTableIndex -- 表索引
 *  aMessageKey -- id
 *输出:
 *  DB_CityInfo     --  城市对象数据
 *  NSMutableArray  --  城市对象数据数组
 */
-(void)updateCityWeather:(DB_CityInfo*)aMessageData;//改-插
-(void)updateCityWeatherFormArray:(NSArray*)adataAray;//改-插
-(void)updateLocationInfo:(DB_CityInfo*)aSender;//改-插
-(void)deleteCityWeatherForObject:(DB_CityInfo*)aCityWeather;//删除
-(void)deleteCityWeatherForKey:(NSString*)aCityKey;//删除
-(void)cleanAllCityWeatherInfo;//删除
-(DB_CityInfo*)querryCityWeather:(NSString*)aCityKey;//查
-(NSMutableArray*)querryCityWeather;//查
-(DB_CityInfo*)querryLocationCity;//查


@end
