//
//  DBMSEngine.m
//  DataBaseTest
//
//  Created by apple on 11-10-21.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "DBMSEngine.h"

@implementation DBMSEngine

@synthesize tableArray;

#pragma mark -
#pragma mark dealloc

- (void)dealloc
{
    tableArray = nil;
	
	sqlite3_close(database);
    database = nil;
}

-(id)init
{
    self = [super init];
    if (self)
    {
        [self openDataBase];
    }
    return self;
}

#pragma mark -
#pragma mark sqlite3 Operate


-(void)currentDataBasePath
{
	NSArray *paths = NSSearchPathForDirectoriesInDomains( NSDocumentDirectory,NSUserDomainMask, YES);
	NSString *documentsDirectory = [paths objectAtIndex:0];
	path = [documentsDirectory stringByAppendingPathComponent:@"ydqxt.dat"];
}

-(void)loadtableArray
{
	tableArray = [[NSArray alloc] initWithObjects:
				  @"CityWeatherTable",		//0--全国天气表
				  nil];
}

-(void)openDataBase
{
	[self currentDataBasePath];
	
	[self  loadtableArray];
	
	//判读数据库文件是否存在--不存在就创建并且创建表,存在就直接打开
	BOOL fileExist = NO;
	if ([[NSFileManager defaultManager] fileExistsAtPath:path])
	{
		fileExist = YES;
	}
	
	//创建或者直接打开数据库
	int result;
	isDataBaseExit = NO;
	result = sqlite3_open([path UTF8String], &database);
	if (result == SQLITE_OK)
	{
		isDataBaseExit= YES;
		
		if (NO == fileExist)
		{
			//创建数据库表
			[self createTable];
		}
	}
}
//创建数据库表
-(void)createTable
{
	//创建表
    
    //城市表
    NSMutableString *tableString = [[NSMutableString alloc] init];
    [tableString appendFormat:@"create table %@(",[tableArray objectAtIndex:0]];
    [tableString appendString:@"id text,"];
    [tableString appendString:@"cityName text,"];
    [tableString appendString:@"latitude text,"];
    [tableString appendString:@"longitude text,"];
    [tableString appendString:@"updateTimer text,"];
    [tableString appendString:@"version text,"];
    [tableString appendString:@"content text,"];
    [tableString appendString:@"islocation text)"];
    sqlite3_exec(database,[tableString UTF8String],NULL,NULL,NULL);
    
    //默认添加
    DB_CityInfo *tempWeather = [[DB_CityInfo alloc] init];
    tempWeather.db_cityId = @"10000";
    tempWeather.db_cityName = @"北京";
    [self updateCityWeather:tempWeather];
    
}

//清空某个表的数据
-(void)cleanTable:(NSInteger)aTableIndex
{
	if (!isDataBaseExit)
		return;
	
	NSString *sqlString = [[NSString alloc] initWithFormat:@"delete from %@",[tableArray objectAtIndex:aTableIndex]];
	
	sqlite3_exec(database, [sqlString UTF8String], NULL, NULL, NULL);
}

//删除某个表指定id的数据
-(void)deleteData:(NSInteger)aTableIndex setId:(NSString*)aId
{
	if (!isDataBaseExit)
		return;
	
	NSString *sqlString = [[NSString alloc] initWithFormat:@"delete from %@ where id = '%@'",[tableArray objectAtIndex:aTableIndex],aId];
	
	sqlite3_exec(database, [sqlString UTF8String], NULL, NULL, NULL);
}

-(void)deleteCityWeatherForObject:(DB_CityInfo*)aCityWeather
{
    if (!isDataBaseExit)
		return;
    if (aCityWeather && aCityWeather.db_cityId != nil)
    {
        [self deleteCityWeatherForKey:aCityWeather.db_cityId];
    }
}


-(void)deleteCityWeatherForKey:(NSString*)aCityKey
{
    if (!isDataBaseExit)
		return;
	
    if (aCityKey != nil)
    {
        NSString *sqlString = [[NSString alloc] initWithFormat:@"delete from %@ where id = '%@'",[tableArray objectAtIndex:0],aCityKey];
        
        if(sqlite3_exec(database, [sqlString UTF8String], NULL, NULL, NULL)!=SQLITE_OK)
        {
            NSLog(@"delete fail");
        }
    }
}

-(void)cleanAllCityWeatherInfo
{
    if (!isDataBaseExit)
		return;
	
	NSString *sqlString = [[NSString alloc] initWithFormat:@"delete from %@",[tableArray objectAtIndex:0]];
	
	sqlite3_exec(database, [sqlString UTF8String], NULL, NULL, NULL);
}


//查询指定id的城市数据
-(DB_CityInfo*)querryCityWeather:(NSString*)aCityKey
{
	if (!isDataBaseExit || !aCityKey)
		return nil;
	
	DB_CityInfo *Weathers = [[DB_CityInfo alloc] init];
	Weathers.db_cityId = aCityKey;
	sqlite3_stmt * stat2;
	NSString *sqlString = [[NSString alloc] initWithFormat:@"select * from %@ where id = '%@'",[tableArray objectAtIndex:0],aCityKey];
	sqlite3_prepare( database, [sqlString UTF8String], -1, &stat2, 0 );
    
    BOOL isSuccess = NO;
	while(sqlite3_step( stat2 ) == SQLITE_ROW)
	{
		if (sqlite3_data_count(stat2) == 8)//8个字段
		{
            isSuccess = YES;
            //id
			//db_cityName
			const char *cityname = (const char *)sqlite3_column_text(stat2, 1);
			if (cityname != NULL)
			{
				Weathers.db_cityName = [NSString stringWithCString:cityname encoding:NSUTF8StringEncoding];
			}
            //latitude
			const char *latitude = (const char *)sqlite3_column_text(stat2, 2);
			if (latitude != NULL)
			{
				Weathers.db_latitude = [NSString stringWithCString:latitude encoding:NSUTF8StringEncoding];
			}
			
			//longitude
			const char *longitude = (const char *)sqlite3_column_text(stat2, 3);
			if (longitude != NULL)
			{
				Weathers.db_longitude = [NSString stringWithCString:longitude encoding:NSUTF8StringEncoding];
			}
            
            //updateTimer
			const char *updateTimer = (const char *)sqlite3_column_text(stat2, 4);
			if (updateTimer != NULL)
			{
				Weathers.db_updateTimer = [NSString stringWithCString:updateTimer encoding:NSUTF8StringEncoding];
			}
            //version
			const char *version = (const char *)sqlite3_column_text(stat2, 5);
			if (version != NULL)
			{
				Weathers.db_version = [NSString stringWithCString:version encoding:NSUTF8StringEncoding];
			}
            //content
			const char *content = (const char *)sqlite3_column_text(stat2, 6);
			if (content != NULL)
			{
				Weathers.db_content = [NSString stringWithCString:content encoding:NSUTF8StringEncoding];
			}
            //islocation
			const char *islocation = (const char *)sqlite3_column_text(stat2, 7);
			if (islocation != NULL)
			{
				Weathers.db_islocation = [NSString stringWithCString:islocation encoding:NSUTF8StringEncoding];
			}
		}
	}
	sqlite3_finalize(stat2);
	if (isSuccess)
    {
        return Weathers;
    }
	return nil;
}


//查询表内的所有城市数据
-(NSMutableArray*)querryCityWeather
{
	NSMutableArray *tempArray = [[NSMutableArray alloc] init];
	if (!isDataBaseExit)
		return tempArray;
	
	sqlite3_stmt * stat2;
	NSString *sqlString = [[NSString alloc] initWithFormat:@"select * from %@ ORDER BY islocation DESC",[tableArray objectAtIndex:0]];
	sqlite3_prepare( database, [sqlString UTF8String], -1, &stat2, 0 );
    BOOL isSuccess = NO;
	while(sqlite3_step( stat2 ) == SQLITE_ROW)
	{
		if (sqlite3_data_count(stat2) == 8)//8个字段
		{
			isSuccess = YES;
			DB_CityInfo	*Weathers = [[DB_CityInfo alloc] init];
            //id
            const char *tempid = (const char *)sqlite3_column_text(stat2, 0);
			if (tempid != NULL)
			{
				Weathers.db_cityId = [NSString stringWithCString:tempid encoding:NSUTF8StringEncoding];
			}
			//db_cityName
			const char *cityname = (const char *)sqlite3_column_text(stat2, 1);
			if (cityname != NULL)
			{
				Weathers.db_cityName = [NSString stringWithCString:cityname encoding:NSUTF8StringEncoding];
			}
            //latitude
			const char *latitude = (const char *)sqlite3_column_text(stat2, 2);
			if (latitude != NULL)
			{
				Weathers.db_latitude = [NSString stringWithCString:latitude encoding:NSUTF8StringEncoding];
			}
			
			//longitude
			const char *longitude = (const char *)sqlite3_column_text(stat2, 3);
			if (longitude != NULL)
			{
				Weathers.db_longitude = [NSString stringWithCString:longitude encoding:NSUTF8StringEncoding];
			}
            
            //updateTimer
			const char *updateTimer = (const char *)sqlite3_column_text(stat2, 4);
			if (updateTimer != NULL)
			{
				Weathers.db_updateTimer = [NSString stringWithCString:updateTimer encoding:NSUTF8StringEncoding];
			}
            //version
			const char *version = (const char *)sqlite3_column_text(stat2, 5);
			if (version != NULL)
			{
				Weathers.db_version = [NSString stringWithCString:version encoding:NSUTF8StringEncoding];
			}
            //content
			const char *content = (const char *)sqlite3_column_text(stat2, 6);
			if (content != NULL)
			{
				Weathers.db_content = [NSString stringWithCString:content encoding:NSUTF8StringEncoding];
			}
            //islocation
			const char *islocation = (const char *)sqlite3_column_text(stat2, 7);
			if (islocation != NULL)
			{
				Weathers.db_islocation = [NSString stringWithCString:islocation encoding:NSUTF8StringEncoding];
			}
			[tempArray addObject:Weathers];
		}
	}
	sqlite3_finalize(stat2);
	
    if (isSuccess && [tempArray count])
    {
        return tempArray;
    }
    return nil;
}

-(DB_CityInfo*)querryLocationCity
{
	if (!isDataBaseExit)
		return nil;
	
	sqlite3_stmt * stat2;
	NSString *sqlString = [[NSString alloc] initWithFormat:@"select * from %@ where islocation = '1'",[tableArray objectAtIndex:0]];
	sqlite3_prepare( database, [sqlString UTF8String], -1, &stat2, 0 );
    BOOL isSuccess = NO;
    DB_CityInfo	*Weathers = [[DB_CityInfo alloc] init];
	while(sqlite3_step( stat2 ) == SQLITE_ROW)
	{
		if (sqlite3_data_count(stat2) == 8)//8个字段
		{
			isSuccess = YES;
            //id
            const char *tempid = (const char *)sqlite3_column_text(stat2, 0);
			if (tempid != NULL)
			{
				Weathers.db_cityId = [NSString stringWithCString:tempid encoding:NSUTF8StringEncoding];
			}
			//db_cityName
			const char *cityname = (const char *)sqlite3_column_text(stat2, 1);
			if (cityname != NULL)
			{
				Weathers.db_cityName = [NSString stringWithCString:cityname encoding:NSUTF8StringEncoding];
			}
            //latitude
			const char *latitude = (const char *)sqlite3_column_text(stat2, 2);
			if (latitude != NULL)
			{
				Weathers.db_latitude = [NSString stringWithCString:latitude encoding:NSUTF8StringEncoding];
			}
			
			//longitude
			const char *longitude = (const char *)sqlite3_column_text(stat2, 3);
			if (longitude != NULL)
			{
				Weathers.db_longitude = [NSString stringWithCString:longitude encoding:NSUTF8StringEncoding];
			}
            
            //updateTimer
			const char *updateTimer = (const char *)sqlite3_column_text(stat2, 4);
			if (updateTimer != NULL)
			{
				Weathers.db_updateTimer = [NSString stringWithCString:updateTimer encoding:NSUTF8StringEncoding];
			}
            //version
			const char *version = (const char *)sqlite3_column_text(stat2, 5);
			if (version != NULL)
			{
				Weathers.db_version = [NSString stringWithCString:version encoding:NSUTF8StringEncoding];
			}
            //content
			const char *content = (const char *)sqlite3_column_text(stat2, 6);
			if (content != NULL)
			{
				Weathers.db_content = [NSString stringWithCString:content encoding:NSUTF8StringEncoding];
			}
            //islocation
			const char *islocation = (const char *)sqlite3_column_text(stat2, 7);
			if (islocation != NULL)
			{
				Weathers.db_islocation = [NSString stringWithCString:islocation encoding:NSUTF8StringEncoding];
			}
            break;
		}
	}
    
	sqlite3_finalize(stat2);
    if (isSuccess)
    {
        return Weathers;
    }
    
    return nil;
}

//更新指定id的数据
-(void)updateCityWeather:(DB_CityInfo*)aMessageData
{
	if(!isDataBaseExit || aMessageData==nil)
		return;
	
	if (aMessageData.db_cityId != nil)
	{
		DB_CityInfo *tempWeather = [self querryCityWeather:aMessageData.db_cityId];
		if (tempWeather)
		{
            NSMutableString *sqlString = [[NSMutableString alloc] init];
            [sqlString appendFormat:@"update %@ set ",[tableArray objectAtIndex:0]];
            if (aMessageData.db_cityName)
            {
                [sqlString appendFormat:@"cityName = '%@',",aMessageData.db_cityName];
            }
            else if(tempWeather.db_cityName)
            {
                [sqlString appendFormat:@"cityName = '%@',",tempWeather.db_cityName];
            }
            
            if (aMessageData.db_content)
            {
                [sqlString appendFormat:@"content = '%@',",aMessageData.db_content];
            }
            else if(tempWeather.db_content)
            {
                [sqlString appendFormat:@"content = '%@',",tempWeather.db_content];
            }
            
            if (aMessageData.db_islocation)
            {
                [sqlString appendFormat:@"islocation = '%@',",aMessageData.db_islocation];
            }
            else if(tempWeather.db_islocation)
            {
                [sqlString appendFormat:@"islocation = '%@',",tempWeather.db_islocation];
            }
            
            if (aMessageData.db_latitude)
            {
                [sqlString appendFormat:@"latitude = '%@',",aMessageData.db_latitude];
            }
            else if(tempWeather.db_latitude)
            {
                [sqlString appendFormat:@"latitude = '%@',",tempWeather.db_latitude];
            }
            
            if (aMessageData.db_longitude)
            {
                [sqlString appendFormat:@"longitude = '%@',",aMessageData.db_longitude];
            }
            else if(tempWeather.db_longitude)
            {
                [sqlString appendFormat:@"longitude = '%@',",tempWeather.db_longitude];
            }
            
            if (aMessageData.db_updateTimer)
            {
                [sqlString appendFormat:@"updateTimer = '%@',",aMessageData.db_updateTimer];
            }
            else if(tempWeather.db_updateTimer)
            {
                [sqlString appendFormat:@"updateTimer = '%@',",tempWeather.db_updateTimer];
            }
            
            if (aMessageData.db_version)
            {
                [sqlString appendFormat:@"version = '%@' ",aMessageData.db_version];
            }
            else if(tempWeather.db_version)
            {
                [sqlString appendFormat:@"version = '%@' ",tempWeather.db_version];
            }
            
            [sqlString appendFormat:@"where id = '%@'",aMessageData.db_cityId];
            
            if(sqlite3_exec(database, [sqlString UTF8String], NULL, NULL, NULL) != SQLITE_OK)
            {
                NSLog(@"数据库更新失败");
            }
            else
            {
                //NSLog(@"更新成功");
            }
		}
        else if(![aMessageData.db_cityId isEqual:@""])
        {
            //插入数据
            NSMutableString *sqlString = [[NSMutableString alloc] initWithString:@"insert into "];
            [sqlString appendString:[tableArray objectAtIndex:0]];
            [sqlString appendString:@"(id,"];
            [sqlString appendString:@"cityName,"];
            [sqlString appendString:@"latitude,"];
            [sqlString appendString:@"longitude,"];
            [sqlString appendString:@"updateTimer,"];
            [sqlString appendString:@"version,"];
            [sqlString appendString:@"content,"];
            [sqlString appendString:@"islocation)"];
            [sqlString appendString:@" values("];
            
            [sqlString appendFormat:@"'%@',",aMessageData.db_cityId];
            [sqlString appendFormat:@"'%@',",aMessageData.db_cityName?aMessageData.db_cityName:@""];
            [sqlString appendFormat:@"'%@',",aMessageData.db_latitude?aMessageData.db_latitude:@""];
            [sqlString appendFormat:@"'%@',",aMessageData.db_longitude?aMessageData.db_longitude:@""];
            [sqlString appendFormat:@"'%@',",aMessageData.db_updateTimer?aMessageData.db_updateTimer:@""];
            [sqlString appendFormat:@"'%@',",aMessageData.db_version?aMessageData.db_version:@""];
            [sqlString appendFormat:@"'%@',",aMessageData.db_content?aMessageData.db_content:@""];
            [sqlString appendFormat:@"'%@')",aMessageData.db_islocation?aMessageData.db_islocation:@"0"];
            
            if (sqlite3_exec(database, [sqlString UTF8String], nil, nil, nil) != SQLITE_OK )
            {
                NSLog(@"插入数据库失败");
            }
            else
            {
                //NSLog(@"插入成功");
            }
        }
	}
	else
	{
		NSLog(@"id not exit");
	}
}

-(void)updateCityWeatherFormArray:(NSArray*)adataAray
{
    for (DB_CityInfo *cityInfosss in adataAray)
    {
        if (cityInfosss)
        {
            [self updateCityWeather:cityInfosss];
        }
    }
}

-(void)updateLocationInfo:(DB_CityInfo*)aSender
{
    if(!isDataBaseExit || aSender==nil)
		return;
    
    DB_CityInfo *oldCityInfo = [self querryCityWeather:aSender.db_cityId];
    DB_CityInfo *LocationCity = [self querryLocationCity];
    
    if (oldCityInfo)//数据库中已经存在该城市
    {
        if (LocationCity)//数据库中有定位城市
        {
            //把已有定位城市切换成非定位城市
            NSMutableString *sqlString = [[NSMutableString alloc] init];
            [sqlString appendFormat:@"update %@ set islocation = '0' where id = '%@'",[tableArray objectAtIndex:0],LocationCity.db_cityId];
            if(sqlite3_exec(database, [sqlString UTF8String], NULL, NULL, NULL) != SQLITE_OK)
            {
                NSLog(@"数据库更新失败");
            }
        }
        
        //把已有城市切换成定位城市
        NSMutableString *sqlString = [[NSMutableString alloc] init];
        [sqlString appendFormat:@"update %@ set islocation = '1' where id = '%@'",[tableArray objectAtIndex:0],oldCityInfo.db_cityId];
        if(sqlite3_exec(database, [sqlString UTF8String], NULL, NULL, NULL) != SQLITE_OK)
        {
            NSLog(@"数据库更新失败");
        }
    }
    else//数据库中无该城市
    {
        if (LocationCity)
        {
            //把已有定位城市切换成非定位城市
            NSMutableString *sqlString = [[NSMutableString alloc] init];
            [sqlString appendFormat:@"update %@ set islocation = '0' where id = '%@'",[tableArray objectAtIndex:0],LocationCity.db_cityId];
            if(sqlite3_exec(database, [sqlString UTF8String], NULL, NULL, NULL) != SQLITE_OK)
            {
                NSLog(@"数据库更新失败");
            }
        }
        
        [self updateCityWeather:aSender];
    }
}


@end