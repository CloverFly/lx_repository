//
//  DB_CityInfo.h
//  MTQ
//  数据库--城市类
//  Created by lesogo on 13-12-24.
//  Copyright (c) 2013年 Lesogo. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DB_CityInfo : NSObject
{
    NSString    *db_cityName;       //城市名称
    NSString    *db_cityId;         //城市id
    NSString    *db_latitude;       //城市经纬度
    NSString    *db_longitude;      //城市经纬度
    NSString    *db_updateTimer;    //更新时间
    NSString    *db_version;        //数据版本号
    NSString    *db_content;        //数据体
    NSString    *db_islocation;     //是否是定位城市
}

@property(nonatomic,strong) NSString    *db_cityName;
@property(nonatomic,strong) NSString    *db_cityId;
@property(nonatomic,strong) NSString    *db_latitude;
@property(nonatomic,strong) NSString    *db_longitude;
@property(nonatomic,strong) NSString    *db_updateTimer;
@property(nonatomic,strong) NSString    *db_version;
@property(nonatomic,strong) NSString    *db_content;
@property(nonatomic,strong) NSString    *db_islocation;

@end
