//
//  DB_CityInfo.m
//  MTQ
//  数据库--城市类
//  Created by lesogo on 13-12-24.
//  Copyright (c) 2013年 Lesogo. All rights reserved.
//

#import "DB_CityInfo.h"

@implementation DB_CityInfo

@synthesize db_cityName;
@synthesize db_cityId;
@synthesize db_latitude;
@synthesize db_longitude;
@synthesize db_updateTimer;
@synthesize db_version;
@synthesize db_content;
@synthesize db_islocation;


-(id)init
{
	self = [super init];
	if (self)
	{
        //db_islocation = @"0";
	}
	return self;
}

@end
