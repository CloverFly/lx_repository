//
//  GetLocation.m
//  TestTimer
//  自动定位
//  Created by 四叶草 on 13-7-4.
//  Copyright (c) 2013年 Clover@lwr. All rights reserved.
//

#import "GetLocation.h"
#define ML_COUNTRY @"Country"
#define ML_STATE @"State"
#define ML_CITY @"City"
#define ML_SUBLOCALITY @"SubLocality"
#define ML_NAME @"Name"

@implementation GetLocation

@synthesize delegate;

- (id)initWithDelegate:(id)aDelegate;
{
    self = [super init];
    self.delegate = aDelegate ;
    
    return self;
}

#pragma mark 启动自动定位
- (void)startUpdateLocation
{
    isSuccess = NO;
    locationManager = [[CLLocationManager alloc] init];
    if ([CLLocationManager locationServicesEnabled])
	{
		locationManager.delegate = self;
		locationManager.distanceFilter = 200;
        locationManager.desiredAccuracy = kCLLocationAccuracyBest;
		[locationManager startUpdatingLocation];
    }
	else
	{
        [delegate getNoLocation];
    }
}

#pragma mark CLLocationManagerDelegate
- (void)locationManager:(CLLocationManager *)manager
	didUpdateToLocation:(CLLocation *)newLocation
		   fromLocation:(CLLocation *)oldLocation
{
    CLGeocoder * geoCoder = [[CLGeocoder alloc] init];
    [geoCoder reverseGeocodeLocation:newLocation completionHandler:^(NSArray *placemarks, NSError *error)
     {
         NSDictionary*findDic = nil;
         for (CLPlacemark * placemark in placemarks)
         {
             if (findDic)
             {
                 locationManager = nil;
                 return ;
             }
             
             NSMutableString*provinceName = nil;
             NSMutableString*cityName = nil;
             NSMutableString*SubLocality  = nil;
             
             if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 6.0)
             {
                 // iOS 6 code
                 if ([[placemark addressDictionary] objectForKey:ML_STATE]!=nil)
                 {
                     provinceName = [[NSMutableString alloc] initWithString:[[placemark addressDictionary] objectForKey:ML_STATE]];
                     [provinceName setString: [provinceName stringByReplacingOccurrencesOfString:@"省" withString:@""]];
                     [provinceName setString: [provinceName stringByReplacingOccurrencesOfString:@"市" withString:@""]];
                     [provinceName setString: [provinceName stringByReplacingOccurrencesOfString:@"宁夏回族自治区" withString:@"宁夏"]];
                     [provinceName setString: [provinceName stringByReplacingOccurrencesOfString:@"新疆维吾尔自治区" withString:@"新疆"]];
                     [provinceName setString: [provinceName stringByReplacingOccurrencesOfString:@"内蒙古自治区" withString:@"内蒙古"]];
                     [provinceName setString: [provinceName stringByReplacingOccurrencesOfString:@"广西壮族自治区" withString:@"广西"]];
                 }
                 else
                 {
                     provinceName = [[NSMutableString alloc] initWithString:[[placemark addressDictionary] objectForKey:ML_CITY]];
                     if (provinceName.length>2)
                     {
                         [provinceName setString: [provinceName stringByReplacingOccurrencesOfString:@"市" withString:@""]];
                         [provinceName setString: [provinceName stringByReplacingOccurrencesOfString:@"自治州" withString:@""]];
                     }
                 }
                 if ([[placemark addressDictionary] objectForKey:ML_CITY]!=nil)
                 {
                     cityName = [[NSMutableString alloc] initWithString:[[placemark addressDictionary] objectForKey:ML_CITY]];
                 }
                 else
                 {
                     cityName = [[NSMutableString alloc] initWithString:[[placemark addressDictionary] objectForKey:ML_STATE]];
                 }
                 if (cityName.length>2)
                 {
                     [cityName setString: [cityName stringByReplacingOccurrencesOfString:@"市" withString:@""]];
                     [cityName setString:[cityName stringByReplacingOccurrencesOfString:@"自治州" withString:@""]];
                 }
                 
                 if ([[placemark addressDictionary] objectForKey:ML_SUBLOCALITY]!=nil)
                 {
                     SubLocality = [[NSMutableString alloc] initWithString:[[placemark addressDictionary] objectForKey:ML_SUBLOCALITY]];
                     if (SubLocality.length>2)
                     {
                         [SubLocality setString:[SubLocality stringByReplacingOccurrencesOfString:@"区" withString:@""]];
                         [SubLocality setString:[SubLocality stringByReplacingOccurrencesOfString:@"县" withString:@""]];
                         [SubLocality setString:[SubLocality stringByReplacingOccurrencesOfString:@"市" withString:@""]];
                     }
                 }
             }
             else
             {
                 // iOS 4.x 5.x code
                 if ([[placemark addressDictionary] objectForKey:ML_STATE]!=nil)
                 {
                     provinceName = [[NSMutableString alloc] initWithString:[[placemark addressDictionary] objectForKey:ML_STATE]];
                 }
                 else
                 {
                     provinceName = [[NSMutableString alloc] initWithString:[[placemark addressDictionary] objectForKey:ML_CITY]];
                 }
                 if (provinceName.length)
                 {
                     [provinceName setString: [provinceName stringByReplacingOccurrencesOfString:@"省" withString:@""]];
                     [provinceName setString: [provinceName stringByReplacingOccurrencesOfString:@"市" withString:@""]];
                 }
                 
                 [provinceName setString: [provinceName stringByReplacingOccurrencesOfString:@"宁夏回族自治区" withString:@"宁夏"]];
                 [provinceName setString: [provinceName stringByReplacingOccurrencesOfString:@"新疆维吾尔自治区" withString:@"新疆"]];
                 [provinceName setString: [provinceName stringByReplacingOccurrencesOfString:@"内蒙古自治区" withString:@"内蒙古"]];
                 [provinceName setString: [provinceName stringByReplacingOccurrencesOfString:@"广西壮族自治区" withString:@"广西"]];
                 
                 
                 if ([[placemark addressDictionary] objectForKey:ML_CITY]!=nil)
                 {
                     cityName = [[NSMutableString alloc] initWithString:[[placemark addressDictionary] objectForKey:ML_CITY]];
                 }
                 if (cityName.length>2)
                 {
                     [cityName setString: [cityName stringByReplacingOccurrencesOfString:@"市" withString:@""]];
                     [cityName setString: [cityName stringByReplacingOccurrencesOfString:@"自治州" withString:@""]];
                 }
                 
                 if ([[placemark addressDictionary] objectForKey:ML_SUBLOCALITY]!=nil)
                 {
                     SubLocality = [[NSMutableString alloc] initWithString:[[placemark addressDictionary] objectForKey:ML_SUBLOCALITY]];
                     if (SubLocality.length>2)
                     {
                         [SubLocality setString:[SubLocality stringByReplacingOccurrencesOfString:@"区" withString:@""]];
                         [SubLocality setString:[SubLocality stringByReplacingOccurrencesOfString:@"县" withString:@""]];
                         [SubLocality setString:[SubLocality stringByReplacingOccurrencesOfString:@"市" withString:@""]];
                     }
                 }
             }
             //查找城市ID
             NSString *path = [[NSBundle mainBundle] pathForResource:@"GetLocation" ofType:@"plist"];
             NSDictionary*allCityDic1 =[NSDictionary dictionaryWithContentsOfFile:path];
             
             NSArray*allCityArr = [allCityDic1 objectForKey:provinceName];
             
             for (NSDictionary*tempDic in allCityArr)
             {
                 if ([[tempDic objectForKey:K_city] isEqualToString:cityName])
                 {
                     for (NSDictionary*countryTempDic in [tempDic objectForKey:K_county])
                     {
                         if ([[countryTempDic objectForKey:K_county] isEqualToString:SubLocality])
                         {
                             findDic=countryTempDic;
                             break;
                         }
                     }
                     if(findDic==nil)
                     {
                         for (NSDictionary*countryTempDic in [tempDic objectForKey:K_county])
                         {
                             if ([[countryTempDic objectForKey:K_city] isEqualToString:[countryTempDic objectForKey:K_county]])
                             {
                                 findDic=countryTempDic;
                                 break;
                             }
                         }
                     }
                     break;
                 }
             }
             //全省查找
             if (findDic==nil)
             {
                 for (NSDictionary*tempDic in allCityArr)
                 {
                     for (NSDictionary*tempCountryDic in [tempDic objectForKey:K_county])
                     {
                         if ([SubLocality rangeOfString:[tempCountryDic objectForKey:K_county]].location)
                         {
                             findDic=tempCountryDic;
                             break;
                         }
                     }
                 }
             }
             if (findDic!=nil)
             {
                 if ([delegate respondsToSelector:@selector(getLocation:reCityInfo:)])//
                 {                     
                     NSMutableDictionary *dataDictionary = [NSMutableDictionary dictionaryWithDictionary:findDic];
                     [dataDictionary setValue:placemark.name forKey:K_address];
                     [dataDictionary setValue:placemark.location forKey:K_location];
                     [dataDictionary setValue:placemark.subAdministrativeArea forKey:@"subAdministrativeArea"];
                     
                     [dataDictionary setValue:[NSString stringWithFormat:@"%f",newLocation.coordinate.latitude] forKey:K_latitude];
                     [dataDictionary setValue:[NSString stringWithFormat:@"%f",newLocation.coordinate.longitude] forKey:K_longitude];
                     if (isSuccess)
                     {
                         return;
                     }
                     isSuccess = YES;
                     [delegate getLocation:self reCityInfo:dataDictionary];
                 }
             }
         }
     }];
}

- (void)locationManager:(CLLocationManager *)manager
	   didFailWithError:(NSError *)error
{
    if ([delegate respondsToSelector:@selector(getNoLocation)])
    {
        //NSLog(@"获取当前经纬度信息失败");
        [delegate getNoLocation];
    }
}

@end
