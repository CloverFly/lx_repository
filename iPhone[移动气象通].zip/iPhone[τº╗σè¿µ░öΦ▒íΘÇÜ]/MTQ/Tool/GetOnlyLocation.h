//
//  GetOnlyLocation.h
//  CSiPadIn
//
//  Created by 小呆 on 14-3-26.
//  Copyright (c) 2014年 apple. All rights reserved.
//


#import <Foundation/Foundation.h>
#import <CoreLocation/CoreLocation.h>

@protocol GetOnlyLocationDelegate;

@interface GetOnlyLocation : NSObject
<CLLocationManagerDelegate>
{
    id delegate;
    CLLocationManager	*locationManager; //获取用户经纬度
}

@property (nonatomic) BOOL isSuccess;
@property (nonatomic) id   delegate;

- (void)startUpdateLocation;
- (id)initWithDelegate:(id)aDelegate;

@end

@protocol GetOnlyLocationDelegate <NSObject>

-(void)getOnlyLocation:(GetOnlyLocation *)aGetLocation locationInfo:(NSDictionary*)aDictionary;
-(void)locationError;

@end