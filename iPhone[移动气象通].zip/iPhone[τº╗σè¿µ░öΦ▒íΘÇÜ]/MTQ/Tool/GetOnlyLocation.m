//
//  GetOnlyLocation.m
//  CSiPadIn
//
//  Created by 小呆 on 14-3-26.
//  Copyright (c) 2014年 apple. All rights reserved.
//

#import "GetOnlyLocation.h"
#import "Tools.h"

@implementation GetOnlyLocation

@synthesize isSuccess;
@synthesize delegate;

- (id)initWithDelegate:(id)aDelegate;
{
    self = [super init];
    
    self.delegate = aDelegate ;
    
    return self;
}

#pragma mark 启动自动定位

- (void)startUpdateLocation
{
    isSuccess = NO;
    locationManager = [[CLLocationManager alloc] init];
    if ([CLLocationManager locationServicesEnabled])
	{
		locationManager.delegate = self;
		locationManager.distanceFilter = 200;
        locationManager.desiredAccuracy = kCLLocationAccuracyBest;
		[locationManager startUpdatingLocation];
    }
	else
	{
        //NSLog(@"尚未开启定位服务");
        //尚未开启定位服务
        if ([delegate respondsToSelector:@selector(locationError)])
        {
            [delegate locationError];
        }
    }
}

#pragma mark CLLocationManagerDelegate

- (void)locationManager:(CLLocationManager *)manager
	didUpdateToLocation:(CLLocation *)newLocation
		   fromLocation:(CLLocation *)oldLocation
{
    CLGeocoder * geoCoder = [[CLGeocoder alloc] init];
    [geoCoder reverseGeocodeLocation:newLocation completionHandler:^(NSArray *placemarks, NSError *error)
     {
         for (CLPlacemark * placemark in placemarks)
         {
             
             if (isSuccess)
             {
                 locationManager = nil;
                 return ;
             }
             /*
              NSLog(@"name%@",placemark.name);
              NSLog(@"thoroughfare%@",placemark.thoroughfare);
              NSLog(@"subThoroughfare%@",placemark.subThoroughfare);
              NSLog(@"locality%@",placemark.locality);
              NSLog(@"subLocality%@",placemark.subLocality);
              NSLog(@"administrativeArea%@",placemark.administrativeArea);
              NSLog(@"subAdministrativeArea%@",placemark.subAdministrativeArea);
              NSLog(@"postalCode%@",placemark.postalCode);
              NSLog(@"ISOcountryCode%@",placemark.ISOcountryCode);
              NSLog(@"country%@",placemark.country);
              NSLog(@"inlandWater%@",placemark.inlandWater);
              NSLog(@"ocean%@",placemark.ocean);
              */
             
             NSMutableDictionary *dataDictionary = [[NSMutableDictionary alloc] init];
             
             [dataDictionary setValue:[NSString stringWithFormat:@"%f",newLocation.coordinate.latitude] forKey:@"latitude"];
             [dataDictionary setValue:[NSString stringWithFormat:@"%f",newLocation.coordinate.longitude] forKey:@"longitude"];
             [dataDictionary setValue:placemark.name forKey:@"address"];
             [dataDictionary setValue:placemark.subAdministrativeArea forKey:@"subAdministrativeArea"];
             //[Tools saveUserDefaultsInfo:dataDictionary :@"Location"];
             
             if (isSuccess)
             {
                 return;
             }
             
             if ([delegate respondsToSelector:@selector(getOnlyLocation: locationInfo:)])
             {
                 [delegate getOnlyLocation:self locationInfo:dataDictionary];
             }
             
             isSuccess = YES;
         }
     }];
}

- (void)locationManager:(CLLocationManager *)manager
	   didFailWithError:(NSError *)error
{
	NSLog(@"获取当前经纬度信息失败");
    if ([delegate respondsToSelector:@selector(locationError)])
    {
        [delegate locationError];
    }
}

@end
