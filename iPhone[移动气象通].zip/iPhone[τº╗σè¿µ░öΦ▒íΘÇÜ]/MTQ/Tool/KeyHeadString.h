//
//  KeyHeadString.h
//  MTQ
//  预定义宏文件
//  Created by lesogo on 13-12-25.
//  Copyright (c) 2013年 Lesogo. All rights reserved.
//

#ifndef MTQ_KeyHeadString_h
#define MTQ_KeyHeadString_h


#define K_address           @"address"              //地址
#define K_alert             @"alert"                //提示
#define K_aqi               @"aqi"                  //空气质量指数
#define K_aqi_level         @"aqi_level"            //空气质量等级
#define K_area_code         @"area_code"            //地区码暂时留着
#define K_city              @"city"                 //城市
#define K_cityCode          @"cityCode"
#define K_small             @"small"
#define K_province          @"province"
#define K_deviceCode        @"deviceCode"
#define K_cityName          @"cityName"             //城市名
#define K_cityInfo          @"cityInfo"
#define K_cityId            @"cityId"
#define K_airForecst        @"airForecst"
#define K_pageNo            @"pageNo"
#define K_pageSize          @"pageSize"
#define K_cp                @"cp"
#define K_sk                @"sk"
#define K_sk_zd             @"sk_zd"
#define K_yb                @"yb"
#define K_jxhyb             @"jxhyb"
#define K_zh                @"zh"
#define K_alerts            @"alerts"
#define K_nongdu            @"nongdu"
#define K_lifeIndex         @"lifeIndex"
#define K_cityKey           @"cityKey"              //城市Key
#define K_cityPiece         @"cityPiece"            //城市编码
#define K_co                @"co"                   //气体微粒
#define K_comment           @"comment"              //评论
#define K_content           @"content"              //内容
#define K_source            @"source"
#define K_fileSuffix        @"fileSuffix"
#define K_county            @"county"               //县
#define K_station           @"station"
#define K_userLoactionInfo  @"K_userLoactionInfo"
#define K_countyCode        @"countyCode"
#define K_total             @"total"
#define K_datas             @"datas"                //数据集
#define K_cityname          @"cityname"
#define K_cityid            @"cityid"
#define K_date              @"date"                 //日期暂定格式yyyy-MM-dd
#define K_down              @"down"                 //日落
#define K_end               @"end"                  //结束时间
#define K_fileType          @"fileType"             //文件后缀名
#define K_high              @"high"                 //高温
#define K_humidity          @"humidity"             //湿度
#define K_id                @"id"                   //id
#define K_latitude          @"latitude"             //纬度
#define K_stationNum        @"stationNum"
#define K_location          @"location"
#define K_longitude         @"longitude"            //经度
#define K_low               @"low"                  //低温
#define K_message           @"message"              //消息
#define K_name              @"name"                 //名称
#define K_no2               @"no2"                  //气体微粒
#define K_o3                @"o3"                   //气体微粒
#define K_oneCode           @"oneCode"              //上午天气现象
#define K_oneCode_cn        @"oneCode_cn"           //上午天气现象中文
#define K_start             @"start"
#define K_pm10              @"pm10"                 //气体微粒
#define K_pm25              @"pm25"                 //气体微粒
#define K_press             @"press"                //气压
#define K_rain              @"rain"                 //降水
#define K_remarks           @"remarks"              //描述
#define K_so2               @"so2"                  //气体微粒
#define K_state             @"state"                //状态
#define K_success           @"success"              //数据下发成功失败
#define K_temp              @"temp"                 //温度
#define K_tigan             @"tigan"
#define K_time              @"time"                 //时间暂定yyyy-MM-ddHH:mm:ss
#define K_expire            @"expire"
#define K_sort              @"sort"
#define K_browse            @"browse"
#define K_title             @"title"                //标题
#define K_titles            @"titles"
#define K_token             @"token"                //令牌
#define K_auth              @"auth"
#define K_twoCode           @"twoCode"              //下午天气现象
#define K_twoCode_cn        @"twoCode_cn"           //下午天气象中文
#define K_exponent          @"exponent"
#define K_up                @"up"                   //日出时间
#define K_index             @"index"
#define K_updown            @"updown"
#define K_scale             @"scale"
#define K_update            @"update"
#define K_url               @"url"                  //http地址
#define K_deviceToken       @"deviceToken"
#define K_pattern           @"pattern"
#define K_user              @"user"                 //用户
#define K_userName          @"userName"             //用户名称
#define K_head              @"head"
#define K_headUrl           @"headUrl"
#define K_height            @"height"
#define K_width             @"width"
#define K_UVI               @"UVI"                  //紫外线指数
#define K_air               @"air"
#define K_UVI_level         @"UVI_level"            //紫外线等级
#define K_value             @"value"                //值
#define K_version           @"version"              //版本号
#define K_warnId            @"warnId"               //预警消息id
#define K_impendings        @"impendings"
#define K_weather           @"weather"              //天气现象
#define K_theme             @"theme"
#define K_weather_cn        @"weather_cn"           //天气现象中文
#define K_flag              @"flag"
#define K_areaCode          @"areaCode"
#define K_scenicLevel       @"scenicLevel"
#define K_tourLevel         @"tourLevel"
#define K_good              @"good"
#define K_focus             @"focus"
#define K_handle            @"handle"
#define K_weatherDay        @"weatherDay"           //天气预报日期yyyy-MM-dd
#define K_tempDay           @"tempDay"
#define K_week              @"week"                 //星期几
#define K_wind              @"wind"                 //风速
#define K_wind_level        @"wind_level"           //风级
#define K_windDirect        @"windDirect"           //风向
#define K_lifeType          @"lifeType"             //生活指数类型
#define K_smallUrl          @"smallUrl"             //小图片地址
#define K_fest              @"fest"                 //节气
#define K_num               @"num"
#define K_routestatus       @"routestatus"
#define K_routename         @"routename"
#define K_routeid           @"routeid"
#define K_routeday          @"routeday"
#define K_routeareanum      @"routeareanum"
#define K_routedistance     @"routedistance"
#define K_data              @"data"
#define K_list              @"list"
#define K_recommend         @"recommend"
#define K_recommendName     @"recommendName"
#define K_recommendCityKey  @"recommendCityKey"
#define K_level             @"level"
#define K_cool              @"cool"
#define K_hot               @"hot"
#define K_hotCity           @"hotCity"
#define K_day               @"day"
#define K_distance          @"distance"
#define K_tour              @"tour"
#define K_warns             @"warns"
#define K_importants        @"importants"
#define K_image             @"image"
#define K_type              @"type"
#define K_right             @"right"
#define K_and               @"and"
#define K_mobile            @"mobile"
#define K_between           @"between"
#define K_guide             @"guide"
#define K_phone                         @"phone"
#define K_code                          @"code"
#define K_secret                        @"secret"
#define K_name                          @"name"
#define K_password                      @"password"
#define K_password2                     @"password2"
#define K_deviceType                    @"deviceType"
#define K_status                        @"status"
#define K_searchparam                   @"searchparam"
#define K_begindate                     @"begindate"
#define K_cityparam                     @"cityparam"
#define K_attachmain                    @"attachmain"
#define K_plan                          @"plan"
#define K_pushCode                      @"pushCode"
#define K_system                        @"system"
#define K_old_password                  @"old_password"
#define K_fail                          @"fail"
#define K_oldToken                      @"oldToken"
#define K_sum                           @"sum"
#define K_fileHeadName                  @"fileHeadName"
#define K_planId                        @"planId"
#define K_startPlanId                   @"startPlanId"
#define K_closePlanId                   @"closePlanId"
#define NUMBERS                         @"0123456789"
#define K_direct                        @"direct"//吉神宜趋
#define K_demon                         @"demon"//凶煞宜忌
#define K_surname                       @"surname"//彭祖百忌
#define K_adapt                         @"adapt"//宜
#define K_nadapt                        @"nadapt"//忌
#define K_opp                           @"opp"//相冲
#define K_halt                          @"halt"//岁煞
#define K_yearn                         @"yearn"//星宿
#define K_mbody                         @"mbody"//本月胎神
#define K_dbody                         @"dbody"//今日胎神
#define K_lunar                         @"lunar"//干支年月日



#endif
