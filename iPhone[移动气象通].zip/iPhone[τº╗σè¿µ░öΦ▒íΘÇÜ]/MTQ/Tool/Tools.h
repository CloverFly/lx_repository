//
//  Tools.h
//  CQDecision
//  工具类
//  Created by apple on 11-10-12.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Tools : NSObject 

/*
 *获取软件版本号
 */
+(NSString*)getVersion;

/*
 *获取软件名字
 */
+(NSString*)getSoftName;

/*
 *获取Keychain
 */
+(NSString *) getKeychain;

//判断是否需要更新
+(BOOL)isCanUpdate:(NSString*)aKeyString;

/*
 *获取mac地址
 */
+(NSString *) getMacAddress;

/*
 *md5加密
 */
+(NSString *) md5: (NSString *) inPutText;

/*
 *保存数据进入默认设置中
*/
+(void)saveUserDefaultsInfo:(id)amessage :(NSString*)aKeyString;//保存
+(id)readUserDefaultsInfo:(NSString*)aKeyString;//读取
+(void)removeUserDefaults:(NSString*)aKeyString;//删除


//获取用户token
+(NSString*)getTokenString;
//是否定制
+(BOOL)isCustomized;


/*
 *皮肤处理
 *
 *皮肤背景图片名称
 */
+(NSString *)SkinBackGround;

/*
 *皮肤处理
 *
 *皮肤判断标示
 */
+(NSString *)SkinName;

/*
 *皮肤处理
 *
 *保存皮肤信息
 */
+(void)saveSkinName:(NSString*)aSkinName;

/*
 *用户名和密码
 *
 *保存用户名和密码
 *用“*”号隔开
 *eg:    name*123456
 */
+(void)saveUserNameAndPassword:(NSString*)aStrings;

/*
 *用户名和密码
 *
 *读取用户名和密码
 */
+(NSString*)readUserNameAndPassword;

/*
 *保存和读取系统默认设置里面的数据
 */
+(BOOL)saveToUserDefaults:(NSString*)aKeyString :(id)aObjects;
+(id)readInfoFromUserDefaults:(NSString*)aKeyString;

/*
 *保存当前显示城市id
 */
+(void)saveCurrentSelectCityKey:(NSString*)aStrings;

/*
 *读取当前显示城市id
 */
+(NSString*)readCurrentSelectKey;

/*
 *天气文本
 *
 *输入one_code  中间字code  two_code
 *返回 完整天气文本
 */
+(NSString *)weatherText:(NSInteger)acode1 midCode:(NSInteger)amidCode setCode2:(NSInteger)acode2;

/*
 *天气文本
 *
 *输入 code 
 *返回 单独天气文本
 */
+(NSString *)weatherText:(NSString*)acode;//蓝色
+(NSString *)weatherText_white:(NSString*)acode;//白色
+(NSString *)weatherText_dark:(NSString*)acode;//灰色


/*
 *风向角度
 *
 *输入风向标示（0-15）
 *返回 风向角度
 *eg:   #define DEGREES_TO_RADIANS(d) (d * M_PI / 180.0)
 *      cell.m_F_View.autoresizingMask = UIViewAutoresizingNone;
 *      cell.m_F_View.transform = CGAffineTransformMakeRotation(DEGREES_TO_RADIANS([Tools getWindAngle:[dic valueForKey:K_direct]]));
 */
+(CGFloat)getWindAngle:(NSString*)aWindString;

/*
 *风向文本
 *
 *输入 code
 *返回 风向文本
 */
+(NSString*)getWindyText:(NSString*)aCode;

/*
 *时间
 *
 *根据字符串得到时间NSDate
 *
 *
 */
+(NSDate*)dateFormString:(NSString*)adateString;

/*
 *星期
 *
 *输入年月日时分秒毫秒的double类型
 *返回星期几  
 *(可以返回 年 月 天 时 分 秒 周 星期几 等)
 */
+(NSString*)GetWeekName:(double)aTimeInterval;
+(NSString*)GetWeekNameFromDate:(NSDate*)adate;
+(NSString*)GetWeekNameFromString:(NSString*)adateString;

/*
 *时间格式化
 *
 *输入 Fromat的格式   和    年月日时分秒毫秒的double类型
 *返回 正常时间
 */
+(NSString*)dateFormatString:(NSString*)afromat formatDate:(double)aTimeInterval;

/*
 *时间格式化
 *输入 Fromat的格式   和    NSDate
 *返回 正常时间
 */
+(NSString*)dateFormatString:(NSString*)afromat setDate:(NSDate*)adate;

/*
 *时间格式化
 *输入 Fromat的格式   和    时间字符(yyyyMMddHHmmss)
 *返回 正常时间
 */
+(NSString*)dateFormatTimeString:(NSString*)afromat setString:(NSString*)atimerString;

/*
 *天气图标
 *
 *根据天气code得到天气图标
 *返回 白天天气图标
 */
+(UIImage*)getDayWeatherImage:(NSString*)aWeatherCode;
+(UIImage*)getDayBlueWeatherImage:(NSString*)aWeatherCode;

+(UIImage*)getNightWeatherImage:(NSString*)aWeatherCode;
+(UIImage*)getNightBlueWeatherImage:(NSString*)aWeatherCode;

/*
 *天气图标
 *
 *输入天气code  当前月份  当前时间
 *返回 晚上天气图标名字
 */
+(NSString*)getWeatherNamePath:(NSString*)aWeatherCode month:(int)monthInt time:(int)timeInt;

/*
 *预警图标
 *
 *输入id
 *返回 预警图标名字
 */
+(NSString*)getWarningNamePath:(NSString*)aWarningKey;

/*
 *pdf文件存读
 *
 *输入pdf文件名字 Data字段
 */
+(void)savePdfFile:(NSString*)aFileName setData:(NSData*)aContent;

/*
 *pdf文件存读
 *
 *输入pdf文件名字
 *返回 pdf名字
 */
+(NSString*)readPdfFile:(NSString*)aFileName;

/*
 *登录用户信息
 *
 *保存用户所有信息（字典）
 */
+(BOOL)saveLogoInfo:(NSDictionary*)aLogoDictionary;


/*
 *登录用户信息
 *
 *读取用户所有信息（字典）
 */
+(NSDictionary*)readLogoInfo;

/*
 *登录用户信息
 *
 *删除用户所有信息
 */
+(void)removedLogoInfo;

/*
 *登录用户信息
 *
 *读取用户名字
 */
+(NSString*)userName;

/*
 *登录用户信息
 *
 *读取用户id
 */
+(NSString*)userId;

/*
 *登录用户信息
 *
 *读取用户权限
 */
+(NSString*)userAuthority;

/*
 *登录用户信息
 *
 *读取用户分类信息
 */
+(NSArray*)userTypes;

/*
 *字段信息存读
 *
 *输入 字段名称 字段内容
 */
+(void)saveString:(NSString*)afilePath data:(NSString*)aContent;

/*
 *字段信息存读
 *
 *输入 字段名称
 *返回 字段内容
 */
+(NSString*)readString:(NSString*)afilePath;

/*
 *判断用户是否登陆
 */
+(BOOL)isLogon;


/*
 *double经纬度转化度分秒
 */
+(NSString *)getLocation:(double)aLocation;

/*
 *压缩图片
 *
 *输入 image  转化大小CGSize  比例  存储名字
 */
+(void)createThumbImage:(UIImage *)image size:(CGSize )thumbSize percent:(float)percent toPath:(NSString *)thumbPath;

/*
 *压缩图片
 *
 *输入 image  转化大小CGSize  比例 
 *截取图片中间正方形进行压缩
 */
+(UIImage*)CutImage:(UIImage*)image newSize:(CGSize)aSize cacheQuality:(float)quality;

/*
 *改变图片
 *
 *输入 image  图片方向
 *对图片进行方向变化
 */
+(UIImage *)image:(UIImage *)image rotation:(UIImageOrientation)orientation;

/*
 *改变图片
 *
 *对图片进行方向变化  最终为横屏
 */
+(UIImage *)fixOrientation:(UIImage *)aImage;

/*
 *输入月份返回当月有几天
 */
+(int)getMonthToDay:(NSString *)aMonth;

/*
 *流量统计
 *
 *输入NSDate
 *返回 流量(单位:M)
 */
+(CGFloat)getNetWorkFlow:(NSDate*)aDate;

/*
 *流量统计
 *
 *输入流量保存
 */
+(void)saveNetWorkFlow:(CGFloat)abty;

/*
 *json格式转化为字典
 */
+(NSDictionary*)JsonParser:(NSString*)aString;


/*
 *函数名称:isFileExitPath
 *函数功能:判断aPath路径下面的文件是否存在
 *参数说明:
 *  输入:aPath--文件路径
 *  输出:是否存在
 */
+(BOOL)isFileExitPath:(NSString*)aPath;


/*
 *nsdate比较时间
 *输入一个可nsdateformatter解析的字符串
 *间隔15分钟
 *返回是否更新
 */
+(BOOL)isDownLoadData:(NSString *)dateStr;

/*
 *函数名称:saveCacheImageData(保存到临时文件路面下面  会自动删除)
 *       saveDocumentsImagData(保存到持久目录下面 不会自动删除)
 *函数功能:保存图片到制定目录下
 *参数说明:
 *  aData--图片数据   afileName--文件保存名称
 */
+(BOOL)saveCacheImageData:(NSData*)aData setFileName:(NSString*)afileName ;
+(BOOL)saveDocumentsImagData:(NSData*)aData setFileName:(NSString*)afileName;

/*
 *函数名称:readCacheImageSavePath(保存到临时文件路面下面  会自动删除)
 *       readDocumentsImageSavePath(保存到持久目录下面 不会自动删除)
 *函数功能:根据名称读取对应的数据
 *参数说明:
 *  输入:afileName--文件保存名称
 *  输出:文件名对应的本地路径
 */
+(NSString*)readCacheImageSavePath:(NSString*)afileName;
+(NSString*)readDocumentsImageSavePath:(NSString*)afileName;


@end
