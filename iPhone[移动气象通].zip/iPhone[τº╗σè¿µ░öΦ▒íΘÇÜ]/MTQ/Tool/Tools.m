//
//  Tools.m
//  CQDecision
//  工具类
//  Created by apple on 11-10-12.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <CommonCrypto/CommonDigest.h>
#import "Tools.h"
#import "KeychainItemWrapper.h"
#import "Security/SecItem.h"

#include <sys/socket.h> // Per msqr
#include <sys/sysctl.h>
#include <net/if.h>
#include <net/if_dl.h>



@implementation Tools

/*
 *获取软件版本号
 */
+(NSString*)getVersion
{
	return [[[NSBundle mainBundle] infoDictionary] objectForKey:(NSString *)kCFBundleVersionKey];
}
/*
 *获取软件名字
 */
+(NSString*)getSoftName
{
    return [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleDisplayName"];
}


/*
 *获取Keychain
 */
+(NSString *) getKeychain
{
    /** 初始化一个保存用户帐号的KeychainItemWrapper */
    KeychainItemWrapper *wrapper = [[KeychainItemWrapper alloc] initWithIdentifier:@"lesogo.com"
                                                                       accessGroup:@"com.Lesogo.scMobileWeather"];
    
    //保存数据
    [wrapper setObject:@"lesogo" forKey:(id)CFBridgingRelease(kSecAttrAccount)];
    
    [wrapper setObject:@"LESOGO2008" forKey:(id)CFBridgingRelease(kSecValueData)];
    
    //从keychain里取出帐号密码
    NSString *password = [wrapper objectForKey:(id)CFBridgingRelease(kSecValueData)];
    //清空设置
    [wrapper resetKeychainItem];
    return password;
}

+(BOOL)isCanUpdate:(NSString*)aKeyString
{
    if (aKeyString)
    {
        NSDate *nowDate = [NSDate date];
        NSDate *saveDate = [Tools readUserDefaultsInfo:aKeyString];
        if (saveDate)
        {
            if ([saveDate compare:nowDate] != NSOrderedAscending)
            {
                return NO;
            }
        }
        NSDate *nextDate = [nowDate addTimeInterval:60*15];
        [Tools saveUserDefaultsInfo:nextDate :aKeyString];
        
        return YES;
    }
    return NO;
}


/*
 *获取mac地址
 */

+(NSString *) getMacAddress
{
    if (ISIOS7)
    {
        return [self md5:[[[UIDevice currentDevice] identifierForVendor] UUIDString]];
    }
    else
    {
        int mib[6];
        size_t len;
        char *buf;
        unsigned char *ptr;
        struct if_msghdr *ifm;
        struct sockaddr_dl *sdl;
        
        mib[0] = CTL_NET;
        mib[1] = AF_ROUTE;
        mib[2] = 0;
        mib[3] = AF_LINK;
        mib[4] = NET_RT_IFLIST;
        
        if ((mib[5] = if_nametoindex("en0")) == 0) {
            printf("Error: if_nametoindex error/n");
            return NULL;
        }
        
        if (sysctl(mib, 6, NULL, &len, NULL, 0) < 0) {
            printf("Error: sysctl, take 1/n");
            return NULL;
        }
        
        if ((buf = malloc(len)) == NULL) {
            printf("Could not allocate memory. error!/n");
            return NULL;
        }
        
        if (sysctl(mib, 6, buf, &len, NULL, 0) < 0) {
            printf("Error: sysctl, take 2");
            return NULL;
        }
        
        ifm = (struct if_msghdr *)buf;
        sdl = (struct sockaddr_dl *)(ifm + 1);
        ptr = (unsigned char *)LLADDR(sdl);
        NSString *outstring = [NSString stringWithFormat:@"%02x:%02x:%02x:%02x:%02x:%02x", *ptr, *(ptr+1), *(ptr+2), *(ptr+3), *(ptr+4), *(ptr+5)];
        free(buf);
        
        return [self md5:[outstring uppercaseString]];
    }
    return @"";
}

/*
 *md5加密
 */

+(NSString *) md5: (NSString *) inPutText
{
    const char *cStr = [inPutText UTF8String];//转换成utf-8
    unsigned char result[16];//开辟一个16字节（128位：md5加密出来就是128位/bit）的空间（一个字节=8字位=8个二进制数）
    CC_MD5( cStr, strlen(cStr), result);
    /*
     extern unsigned char *CC_MD5(const void *data, CC_LONG len, unsigned char *md)官方封装好的加密方法
     把cStr字符串转换成了32位的16进制数列（这个过程不可逆转） 存储到了result这个空间中
     */
    return [NSString stringWithFormat:
            @"%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X",
            result[0], result[1], result[2], result[3],
            result[4], result[5], result[6], result[7],
            result[8], result[9], result[10], result[11],
            result[12], result[13], result[14], result[15]
            ];
}


/*
 *保存数据进入默认设置中
 */
+(void)saveUserDefaultsInfo:(id)amessage :(NSString*)aKeyString
{
    if (amessage && aKeyString)
    {
        NSData *data = [NSKeyedArchiver archivedDataWithRootObject:amessage];
        
        [[NSUserDefaults standardUserDefaults] setObject:data forKey:aKeyString];
        [[NSUserDefaults standardUserDefaults] synchronize];
    }
}

//读取
+(id)readUserDefaultsInfo:(NSString*)aKeyString
{
    if (aKeyString)
    {
        NSData *data = [[NSUserDefaults standardUserDefaults] objectForKey:aKeyString];
        if (data)
        {
            id info = [NSKeyedUnarchiver unarchiveObjectWithData:data];
            if (info)
            {
                return info;
            }
        }
    }
    return nil;
}


//删除
+(void)removeUserDefaults:(NSString*)aKeyString
{
    if (aKeyString)
    {
        [[NSUserDefaults standardUserDefaults] removeObjectForKey:aKeyString];
    }
}

//获取用户token
+(NSString*)getTokenString
{
    NSDictionary *dic = [self readUserDefaultsInfo:K_token];
    if (dic && [dic valueForKey:K_token])
    {
        return [dic valueForKey:K_token];
    }
    return nil;
}

//是否定制
+(BOOL)isCustomized
{
    return YES;
    NSDictionary *dic = [self readUserDefaultsInfo:K_token];
    if (dic && [dic valueForKey:K_auth] && [[dic valueForKey:K_auth] integerValue] == 2)
    {
        return YES;
    }
    return NO;
}

/*
 *皮肤处理
 *
 *皮肤背景图片名称
 */
+(NSString *)SkinBackGround
{
    NSString *background = @"默认背景-1.png";
    if ([[Tools SkinName] isEqualToString:@"1"])
    {
        background = @"默认背景-2.png";
    }
    return background;
}

/*
 *皮肤处理
 *
 *皮肤判断标示
 */
+(NSString *)SkinName
{
    NSString *str = @"";
    NSDictionary *dic = [NSDictionary dictionaryWithContentsOfFile:@""];
    if (dic && dic.count)
    {
        str = [dic objectForKey:@"pifu"];
    }
    return str;
}

/*
 *皮肤处理
 *
 *保存皮肤信息
 */
+(void)saveSkinName:(NSString*)aSkinName
{
    NSDictionary *dic = [NSDictionary dictionaryWithContentsOfFile:@""];
    if (dic && dic.count)
    {
        [dic setValue:aSkinName forKey:@"pifu"];
        [dic writeToFile:@"" atomically:YES];
    }
    return;
}

/*
 *用户名和密码
 *
 *保存用户名和密码
 *用“*”号隔开
 *eg:name*123456
 */
+(void)saveUserNameAndPassword:(NSString*)aStrings
{
	if (aStrings && [aStrings length]>=3)
	{
		[[NSUserDefaults standardUserDefaults] setValue:aStrings forKey:@"UserNameAndPassword"];
		[[NSUserDefaults standardUserDefaults] synchronize];
	}
}

/*
 *用户名和密码
 *
 *读取用户名和密码
 */
+(NSString*)readUserNameAndPassword
{
	NSString *nameAndPassword = [[NSUserDefaults standardUserDefaults] objectForKey:@"UserNameAndPassword"];
	NSArray *arrays = [nameAndPassword componentsSeparatedByString:@"*"];
	if (arrays && [arrays count]==2)
	{
		return nameAndPassword;
	}
	return nil;
}

/*
 *保存和读取系统默认设置里面的数据
 */
+(BOOL)saveToUserDefaults:(NSString*)aKeyString :(id)aObjects
{
    if (aObjects && aKeyString)
    {
        [[NSUserDefaults standardUserDefaults] setValue:aObjects forKey:aKeyString];
		[[NSUserDefaults standardUserDefaults] synchronize];
        return YES;
    }
    return NO;
}

+(id)readInfoFromUserDefaults:(NSString*)aKeyString
{
    if (aKeyString)
    {
        return [[NSUserDefaults standardUserDefaults] objectForKey:aKeyString];
    }
    return nil;
}

/*
 *保存当前显示城市id
 */
+(void)saveCurrentSelectCityKey:(NSString*)aStrings
{
	if (aStrings && [aStrings length])
	{
		[[NSUserDefaults standardUserDefaults] setValue:aStrings forKey:@"currentSelectKey"];
		[[NSUserDefaults standardUserDefaults] synchronize];
	}
}

/*
 *读取当前显示城市id
 */
+(NSString*)readCurrentSelectKey
{
	NSString *keyString = [[NSUserDefaults standardUserDefaults] objectForKey:@"currentSelectKey"];
	if (keyString)
	{
		return keyString;
	}
	return nil;
}


/*
 *天气文本
 *
 *输入one_code  中间字code  two_code
 *返回 完整天气文本
 */
+(NSString *)weatherText:(NSInteger)acode1
				 midCode:(NSInteger)amidCode
				setCode2:(NSInteger)acode2
{
	if (amidCode>=0 && amidCode<8)
	{
		if (acode1 == acode2)
		{
			NSArray *array = [[NSArray alloc] initWithObjects:
                              @"晴",@"多云",@"阴",@"阵雨",@"雷阵雨",
                              @"雷阵雨并伴有冰雹",@"雨夹雪",@"小雨",@"中雨",@"大雨",
                              @"暴雨",@"大暴雨",@"特大暴雨",@"阵雪",@"小雪",@"中雪",
							  @"大雪",@"暴雪",@"雾",@"冻雨",@"沙尘暴",
                              @"小到中雨",@"中到大雨",@"大雨到暴雨",@"暴雨到大暴雨",@"大到特大暴雨",
                              @"小到中雪",@"中到大雪",@"大到暴雪",@"浮尘",@"扬沙",
                              @"强沙尘暴",@"冰雹",@"闪电",nil];
			if (acode1<[array count])
			{
				return [array objectAtIndex:acode1];
			}
			return @"未知";
		}
		else
		{
			NSMutableString *weathertext = [[NSMutableString alloc] init];
			NSArray *array = [[NSArray alloc] initWithObjects:@"晴",@"多云",@"阴",@"阵雨",@"雷阵雨",@"雷阵雨并伴有冰雹",
                              @"雨夹雪",@"小雨",@"中雨",@"大雨",@"暴雨",@"大暴雨",@"特大暴雨",@"阵雪",@"小雪",@"中雪",
                              @"大雪",@"暴雪",@"雾",@"冻雨",@"沙尘暴",@"小到中雨",@"中到大雨",@"大雨到暴雨",@"暴雨到大暴雨",
                              @"大到特大暴雨",@"小到中雪",@"中到大雪",@"大到暴雪",@"浮尘",@"扬沙",@"强沙尘暴",@"冰雹",@"闪电",nil];
			NSArray *array2 = [[NSArray alloc] initWithObjects:@"转",@"有",@"间",@"有短时",@"局部有",@"有间断",@"有零星",@"有分散",nil];
			
			if (acode1<[array count])
			{
				[weathertext appendString:[array objectAtIndex:acode1]];
			}
			
			if (acode2<[array count])
			{
				[weathertext appendString:[array2 objectAtIndex:amidCode]];
				[weathertext appendString:[array objectAtIndex:acode2]];
			}
			
			return weathertext;
		}
	}
	return @"未知";
}

/*
 *天气文本
 *
 *输入 code
 *返回 单独天气文本
 */
+(NSString *)weatherText:(NSString*)acode
{
    if (acode.length)
    {
        NSInteger codes = [acode intValue];
        NSArray *array = [[NSArray alloc] initWithObjects:@"晴",@"多云",@"阴",@"阵雨",@"雷阵雨",@"雷阵雨并伴有冰雹",
                          @"雨夹雪",@"小雨",@"中雨",@"大雨",@"暴雨",@"大暴雨",@"特大暴雨",@"阵雪",@"小雪",@"中雪",
                          @"大雪",@"暴雪",@"雾",@"冻雨",@"沙尘暴",@"小到中雨",@"中到大雨",@"大雨到暴雨",@"暴雨到大暴雨",
                          @"大到特大暴雨",@"小到中雪",@"中到大雪",@"大到暴雪",@"浮尘",@"扬沙",@"强沙尘暴",@"冰雹",@"闪电",nil];
        if (codes<[array count])
        {
            return [array objectAtIndex:codes];
        }
    }
    return @"";
}

+(NSString *)weatherText_dark:(NSString *)acode
{
    if (acode)
    {
        NSInteger codes = [acode intValue];
        NSArray *array = [[NSArray alloc] initWithObjects:@"晴-灰",@"多云-灰",@"阴-灰",@"阵雨-灰",@"雷阵雨-灰",@"雷阵雨并伴有冰雹-灰",
                          @"雨夹雪-灰",@"小雨-灰",@"中雨-灰",@"大雨-灰",@"暴雨-灰",@"大暴雨-灰",@"特大暴雨-灰",@"阵雪-灰",@"小雪-灰",@"中雪-灰",
                          @"大雪-灰",@"暴雪-灰",@"雾-灰",@"冻雨-灰",@"沙尘暴-灰",@"小到中雨-灰",@"中到大雨-灰",@"大雨到暴雨-灰",@"暴雨到大暴雨-灰",
                          @"大到特大暴雨-灰",@"小到中雪-灰",@"中到大雪-灰",@"大到暴雪-灰",@"浮尘-灰",@"扬沙-灰",@"强沙尘暴-灰",@"冰雹-灰",@"闪电-灰",nil];
        if (codes<[array count])
        {
            return [array objectAtIndex:codes];
        }
    }
    return @"";
}

+(NSString *)weatherText_white:(NSString*)acode
{
    if (acode)
    {
        NSInteger codes = [acode intValue];
        NSArray *array = [[NSArray alloc] initWithObjects:@"晴-白",@"多云-白",@"阴-白",@"阵雨-白",@"雷阵雨-白",@"雷阵雨并伴有冰雹-白",
                          @"雨夹雪-白",@"小雨-白",@"中雨-白",@"大雨-白",@"暴雨-白",@"大暴雨-白",@"特大暴雨-白",@"阵雪-白",@"小雪-白",@"中雪-白",
                          @"大雪-白",@"暴雪-白",@"雾-白",@"冻雨-白",@"沙尘暴-白",@"小到中雨-白",@"中到大雨-白",@"大雨到暴雨-白",@"暴雨到大暴雨-白",
                          @"大到特大暴雨-白",@"小到中雪-白",@"中到大雪-白",@"大到暴雪-白",@"浮尘-白",@"扬沙-白",@"强沙尘暴-白",@"冰雹-白",@"闪电-白",nil];
        if (codes<[array count])
        {
            return [array objectAtIndex:codes];
        }
    }
    return @"";
}


/*
 *风向角度
 *
 *输入风向标示（0-15）
 *返回 风向角度
 *eg:   #define DEGREES_TO_RADIANS(d) (d * M_PI / 180.0)
 *      cell.m_F_View.autoresizingMask = UIViewAutoresizingNone;
 *      cell.m_F_View.transform = CGAffineTransformMakeRotation(DEGREES_TO_RADIANS([Tools getWindAngle:[dic valueForKey:K_direct]]));
 */
+(CGFloat)getWindAngle:(NSString*)aWindString
{
    if (aWindString.length)
    {
        NSArray *array = [NSArray arrayWithObjects:@"0",@"1",@"2",@"3",@"4",@"5",@"6",@"7",
                          @"8",@"9",@"10",@"11",@"12",@"13",@"14",@"15",nil];
        
        NSInteger index = 0;
        for (NSString *tempString in array)
        {
            if ([aWindString isEqual:tempString])
            {
                return 22.5*index;
            }
            index++;
        }
    }
    return 0.0;
}

/*
 *风向文本
 *
 *输入 code
 *返回 风向文本
 */
+(NSString*)getWindyText:(NSString*)aCode
{
	if (aCode && [aCode length])
	{
		NSInteger indexs = [aCode intValue];
		if (indexs ==0)
		{
			return @"北风";
		}
		else if(indexs == 1)
		{
			return @"北东北风";
		}
		else if(indexs == 2)
		{
			return @"东北风";
		}
		else if(indexs == 3)
		{
			return @"东东北风";
		}
		else if(indexs == 4)
		{
			return @"东风";
		}
		else if(indexs == 5)
		{
			return @"东东南风";
		}
		else if(indexs == 6)
		{
			return @"东南风";
		}
		else if(indexs == 7)
		{
			return @"南东南风";
		}
		else if(indexs == 8)
		{
			return @"南风";
		}
		else if(indexs == 9)
		{
			return @"南西南风";
		}
		else if(indexs == 10)
		{
			return @"西南风";
		}
		else if(indexs == 11)
		{
			return @"西西南风";
		}
		else if(indexs == 12)
		{
			return @"西风";
		}
		else if(indexs == 13)
		{
			return @"西西北风";
		}
		else if(indexs == 14)
		{
			return @"西北风";
		}
		else if(indexs == 15)
		{
			return @"北西北风";
		}
	}
	return @"静风";
}

/*
 *时间
 *
 *根据字符串得到时间nsdate
 *
 *
 */
+(NSDate*)dateFormString:(NSString*)adateString
{
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat: @"yyyyMMddHHmmss"];
    return   [dateFormatter dateFromString:adateString];
}

/*
 *星期
 *
 *输入年月日时分秒毫秒的double类型
 *返回星期几
 *(可以返回 年 月 天 时 分 秒 周 星期几 等)
 */

+(NSString*)GetWeekName:(double)aTimeInterval
{
    NSDate              *dates = [NSDate dateWithTimeIntervalSince1970:aTimeInterval/1000];
    
    
    NSCalendar          *calendar = [NSCalendar currentCalendar];
    NSDateComponents    *comps;
    comps =[calendar components:(NSWeekCalendarUnit | NSWeekdayCalendarUnit |NSWeekdayOrdinalCalendarUnit)
                       fromDate:dates];
    NSInteger weekday = [comps weekday];
    /*
     comps =[calendar components:(NSHourCalendarUnit | NSMinuteCalendarUnit | NSSecondCalendarUnit | NSDayCalendarUnit | NSMonthCalendarUnit | NSYearCalendarUnit | NSEraCalendarUnit | NSWeekCalendarUnit | NSWeekdayCalendarUnit | NSWeekdayOrdinalCalendarUnit | NSQuarterCalendarUnit) fromDate:dates];
     – era 时代
     – year 年
     – month 月
     – day 天
     – hour 时
     – minute 分
     – second 秒
     – week
     – weekday
     – weekdayOrdinal
     – quarter 季度
     */
    
    NSArray *arrays = [NSArray arrayWithObjects:@"周日",@"周一",@"周二",@"周三",@"周四",@"周五",@"周六", nil];
    
    if (weekday>0 && weekday<=[arrays count])
    {
        return [arrays objectAtIndex:weekday-1];
    }
    return @"";
}

+(NSString*)GetWeekNameFromDate:(NSDate*)adate
{
    NSCalendar          *calendar = [NSCalendar currentCalendar];
    NSDateComponents    *comps;
    comps =[calendar components:(NSWeekCalendarUnit | NSWeekdayCalendarUnit |NSWeekdayOrdinalCalendarUnit)
                       fromDate:adate];
    NSInteger weekday = [comps weekday];
    
    NSArray *arrays = [NSArray arrayWithObjects:@"周日",@"周一",@"周二",@"周三",@"周四",@"周五",@"周六", nil];
    
    if (weekday>0 && weekday<=[arrays count])
    {
        return [arrays objectAtIndex:weekday-1];
    }
    return @"";
}

+(NSString*)GetWeekNameFromString:(NSString*)adateString
{
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat: @"yyyyMMddHHmmss"];
    NSDate *destDate = [dateFormatter dateFromString:adateString];
    return [self GetWeekNameFromDate:destDate];
}

/*
 *时间格式化
 *
 *输入 Fromat的格式   和    年月日时分秒毫秒的double类型
 *返回 正常时间
 */

+(NSString*)dateFormatString:(NSString*)afromat formatDate:(double)aTimeInterval
{
    NSDate *date = [NSDate dateWithTimeIntervalSince1970:aTimeInterval/1000];
    
    NSDateFormatter *dateformat=[[NSDateFormatter  alloc]init];
    [dateformat setDateStyle:NSDateFormatterFullStyle];
    [dateformat setDateFormat:afromat];
    return [dateformat stringFromDate:date];
}


/*
 *时间格式化
 *输入 Fromat的格式   和    NSDate
 *返回 正常时间
 */
+(NSString*)dateFormatString:(NSString*)afromat setDate:(NSDate*)adate
{
    NSDateFormatter *dateformat=[[NSDateFormatter  alloc]init];
    [dateformat setDateFormat:afromat];
    return [dateformat stringFromDate:adate];
}

/*
 *时间格式化
 *输入 Fromat的格式   和    时间字符(yyyyMMddHHmmss)
 *返回 正常时间
 */
+(NSString*)dateFormatTimeString:(NSString*)afromat setString:(NSString*)atimerString
{
    if (atimerString && afromat)
    {
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat: @"yyyyMMddHHmmss"];
        NSDate *destDate = [dateFormatter dateFromString:atimerString];
        return  [self dateFormatString:afromat setDate:destDate];
    }
    return @"";
}

/*
 *天气图标
 *
 *根据天气code得到天气图标
 *返回 白天天气图标
 */
+(UIImage*)getDayWeatherImage:(NSString*)aWeatherCode
{
    UIImage *image = [UIImage imageNamed:[NSString stringWithFormat:@"day_%@.png",aWeatherCode]];
    if (image)
    {
        return image;
    }
    
	return [UIImage imageNamed:@"day_NA.png"];
}

+(UIImage*)getDayBlueWeatherImage:(NSString*)aWeatherCode
{
    UIImage *image = [UIImage imageNamed:[NSString stringWithFormat:@"day_blue_%@.png",aWeatherCode]];
    if (image)
    {
        return image;
    }
    
	return [UIImage imageNamed:@"day_blue_NA.png"];
}

/*
 *天气图标
 *
 *根据天气code得到天气图标
 *返回 晚上天气图标
 */
+(UIImage*)getNightWeatherImage:(NSString*)aWeatherCode
{
    UIImage *image = [UIImage imageNamed:[NSString stringWithFormat:@"night_%@.png",aWeatherCode]];
    if (image)
    {
        return image;
    }
    
	return [UIImage imageNamed:@"night_NA.png"];
}

+(UIImage*)getNightBlueWeatherImage:(NSString*)aWeatherCode
{
    UIImage *image = [UIImage imageNamed:[NSString stringWithFormat:@"night_blue_%@.png",aWeatherCode]];
    if (image)
    {
        return image;
    }
    
	return [UIImage imageNamed:@"night_blue_NA.png"];
}

/*
 *天气图标
 *
 *输入天气code  当前月份  当前时间
 *返回 晚上天气图标名字
 */
+(NSString*)getWeatherNamePath:(NSString*)aWeatherCode month:(int)monthInt time:(int)timeInt
{
	int index = [aWeatherCode intValue];
    if (index>=0 && index<=31)
	{
        switch (monthInt)
        {
            case 1:
            {
                if (timeInt<8 || timeInt>17)
                {
                    return [NSString stringWithFormat:@"n%@.png",aWeatherCode];
                }
                else
                {
                    return [NSString stringWithFormat:@"w%@.png",aWeatherCode];
                }
            }
            case 2:
            {
                if (timeInt<8 || timeInt>18)
                {
                    return [NSString stringWithFormat:@"n%@.png",aWeatherCode];
                }
                else
                {
                    return [NSString stringWithFormat:@"w%@.png",aWeatherCode];
                }
            }
            case 3:
            {
                if (timeInt<7 || timeInt>18)
                {
                    return [NSString stringWithFormat:@"n%@.png",aWeatherCode];
                }
                else
                {
                    return [NSString stringWithFormat:@"w%@.png",aWeatherCode];
                }
            }
            case 4:
            {
                if (timeInt<7 || timeInt>18)
                {
                    return [NSString stringWithFormat:@"n%@.png",aWeatherCode];
                }
                else
                {
                    return [NSString stringWithFormat:@"w%@.png",aWeatherCode];
                }
                
            }
            case 5:
            {
                if (timeInt<6 || timeInt>19)
                {
                    return [NSString stringWithFormat:@"n%@.png",aWeatherCode];
                }
                else
                {
                    return [NSString stringWithFormat:@"w%@.png",aWeatherCode];
                }
            }
            case 6:
            {
                if (timeInt<6 || timeInt>19)
                {
                    return [NSString stringWithFormat:@"n%@.png",aWeatherCode];
                }
                else
                {
                    return [NSString stringWithFormat:@"w%@.png",aWeatherCode];
                }
            }
            case 7:
            {
                if (timeInt<6 || timeInt>19)
                {
                    return [NSString stringWithFormat:@"n%@.png",aWeatherCode];
                }
                else
                {
                    return [NSString stringWithFormat:@"w%@.png",aWeatherCode];
                }
            }
            case 8:
            {
                if (timeInt<6 || timeInt>19)
                {
                    return [NSString stringWithFormat:@"n%@.png",aWeatherCode];
                }
                else
                {
                    return [NSString stringWithFormat:@"w%@.png",aWeatherCode];
                }
            }
            case 9:
            {
                if (timeInt<7 || timeInt>18)
                {
                    return [NSString stringWithFormat:@"n%@.png",aWeatherCode];
                }
                else
                {
                    return [NSString stringWithFormat:@"w%@.png",aWeatherCode];
                }
            }
            case 10:
            {
                if (timeInt<7 || timeInt>18)
                {
                    return [NSString stringWithFormat:@"n%@.png",aWeatherCode];
                }
                else
                {
                    return [NSString stringWithFormat:@"w%@.png",aWeatherCode];
                }
            }
            case 11:
            {
                if (timeInt<7 || timeInt>15)
                {
                    return [NSString stringWithFormat:@"n%@.png",aWeatherCode];
                }
                else
                {
                    return [NSString stringWithFormat:@"w%@.png",aWeatherCode];
                }
            }
            case 12:
            {
                if (timeInt<8 || timeInt>15)
                {
                    return [NSString stringWithFormat:@"n%@.png",aWeatherCode];
                }
                else
                {
                    return [NSString stringWithFormat:@"w%@.png",aWeatherCode];
                }
            }
                break;
                
            default:
                break;
        }
        
	}
	return @"未知.png";
}


/*
 *预警图标
 *
 *输入id
 *返回 预警图标名字
 */
+(NSString*)getWarningNamePath:(NSString*)aWarningKey
{
	int index = [aWarningKey intValue];
	if (index>0 && index<=54)
	{
		return [NSString stringWithFormat:@"%d.png",index];
	}
	return @"0.png";
}

/*
 *pdf文件存读
 *
 *输入pdf文件名字 Data字段
 */
+(void)savePdfFile:(NSString*)aFileName setData:(NSData*)aContent
{
	if (aFileName && [aFileName length]>5 && aContent && [aContent length]>100)
	{
		if (![[NSFileManager defaultManager] fileExistsAtPath:aFileName])
		{
			[[NSFileManager defaultManager] createFileAtPath:aFileName
													contents:aContent
												  attributes:nil];
		}
	}
}

/*
 *pdf文件存读
 *
 *输入pdf文件名字
 *返回 pdf名字
 */
+(NSString*)readPdfFile:(NSString*)aFileName
{
	if (aFileName && [aFileName length]>5)
	{
		if ([[NSFileManager defaultManager] fileExistsAtPath:aFileName])
		{
			return aFileName;
		}
	}
	return nil;
}

/*
 *登录用户信息
 *
 *保存用户所有信息（字典）
 */
+(BOOL)saveLogoInfo:(NSDictionary*)aLogoDictionary
{
    if (aLogoDictionary)
	{
		[[NSUserDefaults standardUserDefaults] setValue:aLogoDictionary forKey:@"LogoInfo"];//单例模式
		[[NSUserDefaults standardUserDefaults] synchronize];
		return YES;
	}
	return NO;
}

/*
 *登录用户信息
 *
 *读取用户所有信息（字典）
 */
+(NSDictionary*)readLogoInfo
{
    return [[NSUserDefaults standardUserDefaults] objectForKey:@"LogoInfo"];
}


/*
 *登录用户信息
 *
 *删除用户所有信息
 */
+(void)removedLogoInfo
{
	[[NSUserDefaults standardUserDefaults] removeObjectForKey:@"LogoInfo"];
}

/*
 *登录用户信息
 *
 *读取用户名字
 */
+(NSString*)userName
{
    NSDictionary *logoDic = [[NSUserDefaults standardUserDefaults] objectForKey:@"LogoInfo"];
    if (logoDic)
    {
        //return [logoDic valueForKey:K_name];
    }
    return @"";
}

/*
 *登录用户信息
 *
 *读取用户id
 */
+(NSString*)userId
{
    NSDictionary *logoDic = [[NSUserDefaults standardUserDefaults] objectForKey:@"LogoInfo"];
    if (logoDic)
    {
        //return [logoDic valueForKey:K_id];
    }
    return @"";
}

/*
 *登录用户信息
 *
 *读取用户权限
 */
+(NSString*)userAuthority
{
    NSDictionary *logoDic = [[NSUserDefaults standardUserDefaults] objectForKey:@"LogoInfo"];
    if (logoDic)
    {
        //return [logoDic valueForKey:K_authority];
    }
    return @"";
}


/*
 *登录用户信息
 *
 *读取用户分类信息
 */
+(NSArray*)userTypes
{
    NSDictionary *logoDic = [[NSUserDefaults standardUserDefaults] objectForKey:@"LogoInfo"];
    if (logoDic)
    {
        //return [logoDic valueForKey:K_types];
    }
    return nil;
}

/*
 *字段信息存读
 *
 *输入 字段名称 字段内容
 */
+(void)saveString:(NSString*)afilePath data:(NSString*)aContent
{
	NSFileManager *filemanager = [NSFileManager defaultManager];
	if ([filemanager fileExistsAtPath:afilePath])
	{
		[filemanager removeItemAtPath:afilePath error:nil];
	}
	[aContent writeToFile:afilePath atomically:YES encoding:NSUTF8StringEncoding error:nil];
}

/*
 *字段信息存读
 *
 *输入 字段名称
 *返回 字段内容
 */
+(NSString*)readString:(NSString*)afilePath
{
	NSFileManager *filemanager = [NSFileManager defaultManager];
	if ([filemanager fileExistsAtPath:afilePath])
	{
		return [NSString stringWithContentsOfFile:afilePath usedEncoding:nil error:nil];
	}
	return nil;
}

/*
 *判断用户是否登陆
 */
+(BOOL)isLogon
{
    if ([[NSUserDefaults standardUserDefaults] objectForKey:@"LogoInfo"])
    {
        return YES;
    }
    
    return NO;
}

/*
 *double经纬度转化度分秒
 */
+(NSString *)getLocation:(double)aLocation
{
    
    NSString *location = @"";
    if (aLocation)
    {
        int x=0;
        double y=0,z=0;
        x = aLocation;
        y = (aLocation-x)*60;
        z = (y-(int)y)*60;
        
        location = [NSString stringWithFormat:@"%d ° %d ′ %d ″",x,(int)y,(int)z];
    }
    return location;
    
}

/*
 *压缩图片
 *
 *输入 image  转化大小CGSize  比例  存储名字
 */
+(void)createThumbImage:(UIImage *)image size:(CGSize )thumbSize percent:(float)percent toPath:(NSString *)thumbPath
{
    CGSize imageSize = image.size;
    CGFloat width = imageSize.width;
    CGFloat height = imageSize.height;
    CGFloat scaleFactor = 0.0;
    CGPoint thumbPoint = CGPointMake(0.0,0.0);
    CGFloat widthFactor = thumbSize.width / width;
    CGFloat heightFactor = thumbSize.height / height;
    
    if (widthFactor > heightFactor)
    {
        scaleFactor = widthFactor;
    }
    else
    {
        scaleFactor = heightFactor;
    }
    
    CGFloat scaledWidth  = width * scaleFactor;
    CGFloat scaledHeight = height * scaleFactor;
    
    if (widthFactor > heightFactor)
    {
        thumbPoint.y = (thumbSize.height - scaledHeight) * 0.5;
    }
    else if (widthFactor < heightFactor)
    {
        thumbPoint.x = (thumbSize.width - scaledWidth) * 0.5;
    }
    
    UIGraphicsBeginImageContext(thumbSize);
    CGRect thumbRect = CGRectZero;
    thumbRect.origin = thumbPoint;
    thumbRect.size.width  = scaledWidth;
    thumbRect.size.height = scaledHeight;
    [image drawInRect:thumbRect];
    
    UIImage *thumbImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    NSData *thumbImageData = UIImageJPEGRepresentation(thumbImage, percent);
    
    [thumbImageData writeToFile:thumbPath atomically:YES];
    
}

/*
 *压缩图片
 *
 *输入 image  转化大小CGSize  比例
 *截取图片中间正方形进行压缩
 */
+(UIImage*)CutImage:(UIImage*)image newSize:(CGSize)aSize cacheQuality:(float)quality
{
    int width = image.size.width;
    int height = image.size.height;
    CGRect rect ;
    if (width>=height)
    {
        rect=CGRectMake((width-height)/2, 0, height, height);
    }
    else
    {
        rect=CGRectMake(0, (height-width)/2, width, width);
    }
    CGImageRef imageRef=CGImageCreateWithImageInRect([image CGImage],rect);
    UIImage* elementImage=[UIImage imageWithCGImage:imageRef];
    //        NSData* _imageData=UIImageJPEGRepresentation(elementImage, quality);
    
    UIGraphicsBeginImageContext(aSize);
    [elementImage drawInRect:CGRectMake(0,0,aSize.width,aSize.height)];
    UIImage* newImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return newImage;
}

/*
 *改变图片
 *
 *输入 image  图片方向
 *对图片进行方向变化
 */
+(UIImage *)image:(UIImage *)image rotation:(UIImageOrientation)orientation
{
    long double rotate = 0.0;
    CGRect rect;
    float translateX = 0;
    float translateY = 0;
    float scaleX = 1.0;
    float scaleY = 1.0;
    
    switch (orientation) {
        case UIImageOrientationLeft:
            rotate = M_PI_2;
            rect = CGRectMake(0, 0, image.size.height, image.size.width);
            translateX = 0;
            translateY = -rect.size.width;
            scaleY = rect.size.width/rect.size.height;
            scaleX = rect.size.height/rect.size.width;
            break;
        case UIImageOrientationRight:
            rotate = 3 * M_PI_2;
            rect = CGRectMake(0, 0, image.size.height, image.size.width);
            translateX = -rect.size.height;
            translateY = 0;
            scaleY = rect.size.width/rect.size.height;
            scaleX = rect.size.height/rect.size.width;
            break;
        case UIImageOrientationDown:
            rotate = M_PI;
            rect = CGRectMake(0, 0, image.size.width, image.size.height);
            translateX = -rect.size.width;
            translateY = -rect.size.height;
            break;
        default:
            rotate = 0.0;
            rect = CGRectMake(0, 0, image.size.width, image.size.height);
            translateX = 0;
            translateY = 0;
            break;
    }
    
    UIGraphicsBeginImageContext(rect.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    //做CTM变换
    CGContextTranslateCTM(context, 0.0, rect.size.height);
    CGContextScaleCTM(context, 1.0, -1.0);
    CGContextRotateCTM(context, rotate);
    CGContextTranslateCTM(context, translateX, translateY);
    
    CGContextScaleCTM(context, scaleX, scaleY);
    //绘制图片
    CGContextDrawImage(context, CGRectMake(0, 0, rect.size.width, rect.size.height), image.CGImage);
    
    UIImage *newPic = UIGraphicsGetImageFromCurrentImageContext();
    
    return newPic;
}

/*
 *改变图片
 *
 *对图片进行方向变化  最终为横屏
 */

+(UIImage *)fixOrientation:(UIImage *)aImage
{
    if (aImage==nil || !aImage)
    {
        return nil;
    }
    // No-op if the orientation is already correct
    if (aImage.imageOrientation == UIImageOrientationUp) return aImage;
    
    // We need to calculate the proper transformation to make the image upright.
    // We do it in 2 steps: Rotate if Left/Right/Down, and then flip if Mirrored.
    CGAffineTransform transform = CGAffineTransformIdentity;
    UIImageOrientation orientation=aImage.imageOrientation;
    int orientation_=orientation;
    switch (orientation_)
    {
        case UIImageOrientationDown:
        case UIImageOrientationDownMirrored:
            transform = CGAffineTransformTranslate(transform, aImage.size.width, aImage.size.height);
            transform = CGAffineTransformRotate(transform, M_PI);
            break;
            
        case UIImageOrientationLeft:
        case UIImageOrientationLeftMirrored:
            transform = CGAffineTransformTranslate(transform, aImage.size.width, 0);
            transform = CGAffineTransformRotate(transform, M_PI_2);
            break;
            
        case UIImageOrientationRight:
        case UIImageOrientationRightMirrored:
            transform = CGAffineTransformTranslate(transform, 0, aImage.size.height);
            transform = CGAffineTransformRotate(transform, -M_PI_2);
            break;
    }
    
    switch (orientation_)
    {
        case UIImageOrientationUpMirrored:
        {
            
        }
        case UIImageOrientationDownMirrored:
            transform = CGAffineTransformTranslate(transform, aImage.size.width, 0);
            transform = CGAffineTransformScale(transform, -1, 1);
            break;
            
        case UIImageOrientationLeftMirrored:
        case UIImageOrientationRightMirrored:
            transform = CGAffineTransformTranslate(transform, aImage.size.height, 0);
            transform = CGAffineTransformScale(transform, -1, 1);
            break;
    }
    
    // Now we draw the underlying CGImage into a new context, applying the transform
    // calculated above.
    CGContextRef ctx = CGBitmapContextCreate(NULL, aImage.size.width, aImage.size.height,
                                             CGImageGetBitsPerComponent(aImage.CGImage), 0,
                                             CGImageGetColorSpace(aImage.CGImage),
                                             CGImageGetBitmapInfo(aImage.CGImage));
    CGContextConcatCTM(ctx, transform);
    switch (aImage.imageOrientation)
    {
        case UIImageOrientationLeft:
        case UIImageOrientationLeftMirrored:
        case UIImageOrientationRight:
        case UIImageOrientationRightMirrored:
            // Grr...
            CGContextDrawImage(ctx, CGRectMake(0,0,aImage.size.height,aImage.size.width), aImage.CGImage);
            break;
            
        default:
            CGContextDrawImage(ctx, CGRectMake(0,0,aImage.size.width,aImage.size.height), aImage.CGImage);
            break;
    }
    
    // And now we just create a new UIImage from the drawing context
    CGImageRef cgimg = CGBitmapContextCreateImage(ctx);
    UIImage *img = [UIImage imageWithCGImage:cgimg];
    CGContextRelease(ctx);
    CGImageRelease(cgimg);
    aImage=img;
    return aImage;
}

/*
 *输入月份返回当月有几天
 */
+(int)getMonthToDay:(NSString *)aMonth
{
    int day = 0;
    
    if (aMonth.length>0)
    {
        int year = [[aMonth substringWithRange:NSMakeRange(0,4)] intValue];
        int month = [[aMonth substringWithRange:NSMakeRange(4,2)] intValue];
        switch (month)
        {
            case 1:
                day = 31;
                break;
            case 2:
                if (year%4 == 0)
                {
                    day = 29;
                }
                else
                {
                    day = 28;
                }
                break;
            case 3:
                day = 31;
                break;
            case 4:
                day = 30;
                break;
            case 5:
                day = 31;
                break;
            case 6:
                day = 30;
                break;
            case 7:
                day = 31;
                break;
            case 8:
                day = 31;
                break;
            case 9:
                day = 30;
                break;
            case 10:
                day = 31;
                break;
            case 11:
                day = 30;
                break;
            case 12:
                day = 31;
                break;
                
            default:
                break;
        }
    }
    
    return day;
}


/*
 *流量统计
 *
 *输入NSDate
 *返回 流量(单位:M)
 */
+(CGFloat)getNetWorkFlow:(NSDate*)aDate
{
    NSDateFormatter *dateformat=[[NSDateFormatter  alloc]init];
    [dateformat setDateFormat:@"yyyyMMdd"];
    NSString *name = [NSString stringWithFormat:@"%@.plist",[dateformat stringFromDate:aDate]];
    NSArray *paths = NSSearchPathForDirectoriesInDomains( NSDocumentDirectory,NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *newPath = [documentsDirectory stringByAppendingPathComponent:name];
    if ([[NSFileManager defaultManager] fileExistsAtPath:newPath])
    {
        NSDictionary *dic = [NSDictionary dictionaryWithContentsOfFile:newPath];
        return ([[dic valueForKey:@"flow"] floatValue]/1024)/1024;
    }
    return 0;
}

/*
 *流量统计
 *
 *输入流量保存
 */
+(void)saveNetWorkFlow:(CGFloat)abty
{
    NSDateFormatter *dateformat=[[NSDateFormatter  alloc]init];
    [dateformat setDateFormat:@"yyyyMMdd"];
    NSString *name = [NSString stringWithFormat:@"%@.plist",[dateformat stringFromDate:[NSDate date]]];
    NSArray *paths = NSSearchPathForDirectoriesInDomains( NSDocumentDirectory,NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *newPath = [documentsDirectory stringByAppendingPathComponent:name];
    CGFloat basicCount = 0;
    if ([[NSFileManager defaultManager] fileExistsAtPath:newPath])
    {
        NSDictionary *dic = [NSDictionary dictionaryWithContentsOfFile:newPath];
        basicCount = [[dic valueForKey:@"flow"] floatValue];
    }
    basicCount += abty;
    
    NSMutableDictionary *newDic = [[NSMutableDictionary alloc] init];
    [newDic setValue:[NSString stringWithFormat:@"%f",basicCount] forKey:@"flow"];
    [newDic writeToFile:newPath atomically:YES];
}

/*
 *json格式转化为字典
 */
+(NSDictionary*)JsonParser:(NSString*)aString
{
    SBJsonParser *jsonpareser = [[SBJsonParser alloc] init];
    NSDictionary *dic = [jsonpareser objectWithString:aString];
    return dic;
}

/*
 *函数名称:isFileExitPath
 *函数功能:判断aPath路径下面的文件是否存在
 *参数说明:
 *  输入:aPath--文件路径
 *  输出:是否存在
 */
+(BOOL)isFileExitPath:(NSString*)aPath
{
    if ([[NSFileManager defaultManager] fileExistsAtPath:aPath])
    {
        return YES;
    }
    return NO;
}

/*
 *nsdate比较时间
 *输入一个可nsdateformatter解析的字符串
 *间隔15分钟
 *返回是否更新
 */
+(BOOL)isDownLoadData:(NSString *)dateStr
{
    if (dateStr.length)
    {
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc]init];
        [dateFormatter setDateFormat:@"yyyyMMddHHmmss"];
        NSDate *date=[dateFormatter dateFromString:dateStr];
        NSDate *date1=[NSDate date];
        NSTimeZone *zone = [NSTimeZone systemTimeZone];
        NSInteger interval = [zone secondsFromGMTForDate: date];
        NSInteger interval1 = [zone secondsFromGMTForDate: date1];
        NSDate *localeDate = [date  dateByAddingTimeInterval: interval];
        
        NSDate *after = [localeDate dateByAddingTimeInterval:15*60];
        NSDate *tempDate = [after laterDate:[date1 dateByAddingTimeInterval:interval1]];
        
        return [tempDate isEqualToDate:[date1 dateByAddingTimeInterval:interval]];
        
    }
    else
    {
        return YES;
    }
}

/*
 *函数名称:saveCacheImageData(保存到临时文件路面下面  会自动删除)
 *函数功能:保存图片到制定目录下
 *参数说明:
 *  aData--图片数据   afileName--文件保存名称
 */
+(BOOL)saveCacheImageData:(NSData*)aData setFileName:(NSString*)afileName
{
    if (afileName && aData)
    {
        NSString *newPath = [NSString stringWithFormat:@"%@/%@",KTmpPath,[self md5:afileName]];
        if ([[NSFileManager defaultManager] fileExistsAtPath:newPath])
        {
            [[NSFileManager defaultManager] removeItemAtPath:newPath error:nil];
        }
        return [aData writeToFile:newPath atomically:YES];
    }
    return NO;
}

/*
 *函数名称:saveDocumentsImagData(保存到持久目录下面 不会自动删除)
 *函数功能:保存图片到制定目录下
 *参数说明:
 *  aData--图片数据   afileName--文件保存名称
 */
+(BOOL)saveDocumentsImagData:(NSData*)aData setFileName:(NSString*)afileName
{
    if (afileName && aData )
    {
        NSString *newPath = [NSString stringWithFormat:@"%@/%@",KDocumentsPath,[self md5:afileName]];
        if ([[NSFileManager defaultManager] fileExistsAtPath:newPath])
        {
            [[NSFileManager defaultManager] removeItemAtPath:newPath error:nil];
        }
        return [aData writeToFile:newPath atomically:YES];
    }
    return NO;
}

/*
 *函数名称:readCacheImageSavePath(保存到临时文件路面下面  会自动删除)
 *函数功能:根据名称读取对应的数据
 *参数说明:
 *  输入:afileName--文件保存名称
 *  输出:文件名对应的本地路径
 */
+(NSString*)readCacheImageSavePath:(NSString*)afileName
{
    if (afileName)
    {
        NSString *newPath = [NSString stringWithFormat:@"%@/%@",KTmpPath,[self md5:afileName]];
        return newPath;
    }
    return nil;
}

/*
 *函数名称:readDocumentsImageSavePath(保存到持久目录下面 不会自动删除)
 *函数功能:根据名称读取对应的数据
 *参数说明:
 *  输入:afileName--文件保存名称
 *  输出:文件名对应的本地路径
 */
+(NSString*)readDocumentsImageSavePath:(NSString*)afileName
{
    if (afileName)
    {
        NSString *newPath = [NSString stringWithFormat:@"%@/%@",KDocumentsPath,[self md5:afileName]];
        return newPath;
    }
    return nil;
}

@end
