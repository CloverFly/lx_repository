//
//  URL.h
//  HN_iphone
//  网络更新地址
//  Created by lesogoMacMini on 13-10-17.
//  Copyright (c) 2013年 lesogoMacMini. All rights reserved.
//

#import <Foundation/Foundation.h>


#define KCurrentVersion    @"1008"

#define KWifiAddress        @"192.168.1.58"      //内网地址
#define KGPSAddress         @"115.28.143.46"      //外网地址
#define PORT                10130
#define PROJECT             @"ydqxt"

@interface URL : NSObject

+(NSString *)GET_IP_ADDRESS;//内外网地址处理
+(NSString *)replaceUrlString:(NSString*)srcUrl;//网络地址替换

//版本监测
+(NSString*)get_VersionCheckUrl;

//天气数据
+(NSString*)get_WeatherDataUrl;

//加密站全部列表
+(NSString*)get_MapStationDataUrl;

//经纬度搜索四川公布的加密站实况
+(NSString*)searchEncryptStation;

//热门城市
+(NSString*)HOTCITY;
//城市同步服务器
+(NSString*)sumbitCityForSevicer;

//设备注册
+(NSString*)sumbitDeviceRegister;

//视频列表下载
+(NSString*)get_VoideUrl;

//  2.5.1	实景列表接口
+(NSString*)get_imagearrayDataUrl;

//	2.5.2	实景上传
+(NSString*)get_LivetouploadDataUrl;

//	2.5.3	实景图评论列表
+(NSString*)get_commentsDataUrl;

//	2.5.5	实景图发布评论
+(NSString*)get_writeDataUrl;

//	2.5.6	实景图列表二级页面
+(NSString*)get_twoimagearrayDataUrl;

//	2.5.7	实景图赞
+(NSString*)get_zhanDataUrl;

//查询景区视频
+(NSString*)QueryScenceVideoUrl;
//查询景区实况
+(NSString*)QueryScenceWeatherUrl;
@end
