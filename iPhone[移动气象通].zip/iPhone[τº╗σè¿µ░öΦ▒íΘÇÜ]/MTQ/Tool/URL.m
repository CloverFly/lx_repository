//
//  URL.m
//  HN_iphone
//  网络更新地址
//  Created by lesogoMacMini on 13-10-17.
//  Copyright (c) 2013年 lesogoMacMini. All rights reserved.
//

#import "URL.h"

@implementation URL

+(NSString *)GET_IP_ADDRESS
{
    if(AppDelegate.isWifiAddress)
    {
        return KWifiAddress;
    }
    return KGPSAddress;
}

+(NSString *)replaceUrlString:(NSString*)srcUrl
{
    if (srcUrl && AppDelegate.isWifiAddress)
    {
        return [srcUrl stringByReplacingOccurrencesOfString:KGPSAddress withString:KWifiAddress];
    }
    return srcUrl;
}

//版本监测
+(NSString*)get_VersionCheckUrl
{
    NSMutableString*urlStr = [[NSMutableString alloc] init];
	[urlStr appendFormat:@"http://%@:%d/%@/mobile/isNewVersion",
	 [self GET_IP_ADDRESS],//ip地址
	 PORT,
     PROJECT];
    
	return urlStr;
}

//城市天气
+(NSString*)get_WeatherDataUrl
{
    NSMutableString*urlStr = [[NSMutableString alloc] init];
	[urlStr appendFormat:@"http://%@:%d/%@/weather/v1",
	 [self GET_IP_ADDRESS],//ip地址
	 PORT,
     PROJECT];
    
	return urlStr;
}

//加密站全部列表
+(NSString*)get_MapStationDataUrl
{
    NSMutableString*urlStr = [[NSMutableString alloc] init];
	[urlStr appendFormat:@"http://%@:%d/%@/weather/queryEncryptStations",
	 [self GET_IP_ADDRESS],//ip地址
	 PORT,
     PROJECT];
    
	return urlStr;
}

//经纬度搜索四川公布的加密站实况
+(NSString*)searchEncryptStation
{
    NSMutableString*urlStr = [[NSMutableString alloc] init];
	[urlStr appendFormat:@"http://%@:%d/%@/weather/searchEncryptStation",
	 [self GET_IP_ADDRESS],//ip地址
	 PORT,
     PROJECT];
    
	return urlStr;
}

//热门城市
+(NSString*)HOTCITY
{
    NSMutableString*urlStr = [[NSMutableString alloc] init];
    [urlStr appendFormat:@"http://%@:%d/%@/sys/queryRecommendCity",
	 [self GET_IP_ADDRESS],//ip地址
	 PORT,
     PROJECT];
    
	return urlStr;
}

//城市列表同步服务器
+(NSString*)sumbitCityForSevicer
{
    NSMutableString*urlStr = [[NSMutableString alloc] init];
	[urlStr appendFormat:@"http://%@:%d/%@/mobile/editCity",
	 [self GET_IP_ADDRESS],//ip地址
	 PORT,
     PROJECT];
    
	return urlStr;
}

//体检设备注册
+(NSString*)sumbitDeviceRegister
{
    NSMutableString*urlStr = [[NSMutableString alloc] init];
	[urlStr appendFormat:@"http://%@:%d/%@/mobile/register",
	 [self GET_IP_ADDRESS],//ip地址
	 PORT,
     PROJECT];
    
	return urlStr;
}

//视频列表下载
+(NSString*)get_VoideUrl
{
    NSMutableString*urlStr = [[NSMutableString alloc] init];
	[urlStr appendFormat:@"http://%@:%d/%@/video/queryVideo",
	 [self GET_IP_ADDRESS],//ip地址
	 PORT,
     PROJECT];
    
	return urlStr;
}


//  2.5.1	实景列表接口
+(NSString*)get_imagearrayDataUrl
{
    NSMutableString*urlStr = [[NSMutableString alloc] init];
	[urlStr appendFormat:@"http://%@:%d/%@/realimage/queryRealImageByArea",
	 [self GET_IP_ADDRESS],//ip地址
	 PORT,
     PROJECT];
    
	return urlStr;
}

//	2.5.2	实景上传
+(NSString*)get_LivetouploadDataUrl
{
    NSMutableString*urlStr = [[NSMutableString alloc] init];
	[urlStr appendFormat:@"http://%@:%d/%@/realimage/upload",
	 [self GET_IP_ADDRESS],//ip地址
	 PORT,
     PROJECT];
    
	return urlStr;
}
//	2.5.3	实景图评论列表
+(NSString*)get_commentsDataUrl
{
    NSMutableString*urlStr = [[NSMutableString alloc] init];
	[urlStr appendFormat:@"http://%@:%d/%@/realimage/queryComment",
	 [self GET_IP_ADDRESS],//ip地址
	 PORT,
     PROJECT];
    
	return urlStr;
}
//	2.5.5	实景图发布评论
+(NSString*)get_writeDataUrl
{
    NSMutableString*urlStr = [[NSMutableString alloc] init];
	[urlStr appendFormat:@"http://%@:%d/%@/realimage/writeComment",
	 [self GET_IP_ADDRESS],//ip地址
	 PORT,
     PROJECT];
    
	return urlStr;
}

//	2.5.6	实景图列表二级页面
+(NSString*)get_twoimagearrayDataUrl
{
    NSMutableString*urlStr = [[NSMutableString alloc] init];
	[urlStr appendFormat:@"http://%@:%d/%@/realimage/realImageDetail",
	 [self GET_IP_ADDRESS],//ip地址
	 PORT,
     PROJECT];
    
	return urlStr;
}

//	2.5.7	实景图赞
+(NSString*)get_zhanDataUrl
{
    NSMutableString*urlStr = [[NSMutableString alloc] init];
	[urlStr appendFormat:@"http://%@:%d/%@/realimage/loveImage",
	 [self GET_IP_ADDRESS],//ip地址
	 PORT,
     PROJECT];
    
	return urlStr;
}

//查询景区视频
+(NSString*)QueryScenceVideoUrl
{
    NSMutableString*urlStr = [[NSMutableString alloc] init];
	[urlStr appendFormat:@"http://%@:%d/%@/scencevideourl/QueryScenceVideoUrl",
	 [self GET_IP_ADDRESS],//ip地址
	 PORT,
     PROJECT];
    
	return urlStr;
}
//查询景区实况
+(NSString*)QueryScenceWeatherUrl
{
    NSMutableString*urlStr = [[NSMutableString alloc] init];
	[urlStr appendFormat:@"http://%@:%d/%@//scencevideourl/QueryTabTimeAreaOrCity",
	 [self GET_IP_ADDRESS],//ip地址
	 PORT,
     PROJECT];
    
	return urlStr;
}
@end
