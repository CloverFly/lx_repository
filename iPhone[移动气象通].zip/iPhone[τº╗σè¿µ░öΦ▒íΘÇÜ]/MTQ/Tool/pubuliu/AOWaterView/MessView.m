//
//  MessView.m
//  AOWaterView
//
//  Created by akria.king on 13-4-10.
//  Copyright (c) 2013年 akria.king. All rights reserved.
//

#import "MessView.h"
#import "UIButton+WebCache.h"
#import "SDWebImageManager.h"

#define WIDTH 320/3
@implementation MessView
@synthesize idelegate;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

-(id)initWithData:(DataInfo *)data yPoint:(float) y
{
    self.dataInfo=data;
    float imgW=data.width;//图片原宽度
    float imgH=data.height;//图片原高度
    float sImgW = WIDTH-4;//缩略图宽带
    float sImgH = sImgW*imgH/imgW;//缩略图高度
    self = [super initWithFrame:CGRectMake(0, y, WIDTH, sImgH+4)];
  
    if (self)
    {
        UIImageView *imageBtn = [[UIImageView alloc]initWithFrame:CGRectMake(2,2, sImgW, sImgH)];//初始化url图片按钮控件
        //设置图片地质
        [imageBtn setImageWithURL:[NSURL URLWithString:data.url]];
        imageBtn.tag = data.index;
        [self addSubview:imageBtn];
        //设置点击用的button
        UIButton *button=[UIButton buttonWithType:UIButtonTypeCustom];
        [button setFrame:CGRectMake(2,2, sImgW, sImgH)];
        [button addTarget:self action:@selector(click:) forControlEvents:UIControlEventTouchUpInside];
        button.tag=data.index;
        [self addSubview:button];
        //下面的背景色；
        UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(2, self.frame.size.height-18, WIDTH-4, 20)];
        label.backgroundColor = [UIColor blackColor];
        label.alpha=0.4;
        [self addSubview:label];
        //名字
        UILabel *nameLable = [[UILabel alloc]initWithFrame:CGRectMake(6, self.frame.size.height-15, 60, 10)];
        nameLable.text=data.title;
        nameLable.backgroundColor=[UIColor clearColor];
        
        nameLable.textColor=[UIColor whiteColor];
        [nameLable setFont:[UIFont systemFontOfSize:8]];
        [self addSubview:nameLable];
        //时间；
        UILabel *timeLable = [[UILabel alloc]initWithFrame:CGRectMake(66, self.frame.size.height-15, 40,10)];
        NSString *timeStr=[Tools dateFormatTimeString:@"MM月dd日" setString:data.time];
        timeLable.text=timeStr;
        timeLable.backgroundColor=[UIColor clearColor];
        
        timeLable.textColor=[UIColor whiteColor];
        [timeLable setFont:[UIFont systemFontOfSize:8]];
        [self addSubview:timeLable];
        
        }
    return self;

}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

//点击图片
-(void)click:(UIButton*)sender
{
    
    if (self.idelegate && [self.idelegate respondsToSelector:@selector(click:data:)])
    {
        [self.idelegate click:self.dataInfo data:sender];
    }
    
}
@end
