//
//  DataAccess.m
//  AOWaterView
//
//  Created by akria.king on 13-4-10.
//  Copyright (c) 2013年 akria.king. All rights reserved.
//

#import "DataAccess.h"
#import "DataInfo.h"
@implementation DataAccess
//-(NSDictionary *)getDicByPlist{
//    NSString *path=[[NSBundle mainBundle] pathForResource:@"dataList" ofType:@"plist"];
//    
//    NSMutableDictionary *dic = [[NSMutableDictionary alloc]initWithContentsOfFile:path];
//    return dic;
//    
//}
//获取基础联系列表
-(NSMutableArray *)getDateArray:(NSDictionary *)dicdateArry
{
    NSMutableArray *imageList = [[NSMutableArray alloc]init];
    NSMutableArray *dicArray = [dicdateArry objectForKey:@"datas"];
    for (NSDictionary *vdic in dicArray)
    {
        if (vdic)
        {
            DataInfo *data=[[DataInfo alloc]init];
            NSNumber *hValue=[vdic objectForKey:@"height"];
            data.height= hValue.floatValue;
            NSNumber *wValue=[vdic objectForKey:@"width"];
            data.width= wValue.floatValue;
            data.url = [vdic objectForKey:@"smallUrl"];
            data.title=[vdic objectForKey:@"address"];
            data.mess=[vdic objectForKey:@"time"];
            data.time=[vdic objectForKey:@"time"];
            data.imageid=[vdic objectForKey:@"id"];
            [imageList addObject:data];
        }
    }
    return imageList;
    
}
@end
