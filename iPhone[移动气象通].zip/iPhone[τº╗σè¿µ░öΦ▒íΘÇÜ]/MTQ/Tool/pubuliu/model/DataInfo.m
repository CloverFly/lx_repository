//
//  DataInfo.m
//  AOWaterView
//
//  Created by akria.king on 13-4-10.
//  Copyright (c) 2013年 akria.king. All rights reserved.
//

#import "DataInfo.h"

@implementation DataInfo


@end
