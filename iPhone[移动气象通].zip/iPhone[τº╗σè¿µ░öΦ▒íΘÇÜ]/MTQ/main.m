//
//  main.m
//  MTQ
//  
//  Created by lesogo on 13-12-9.
//  Copyright (c) 2013年 Lesogo. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "MTQAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool
    {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([MTQAppDelegate class]));
    }
}
