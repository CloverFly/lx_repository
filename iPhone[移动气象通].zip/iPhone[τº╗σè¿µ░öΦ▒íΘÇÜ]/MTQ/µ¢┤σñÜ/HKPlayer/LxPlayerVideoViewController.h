//
//  LxPlayerVideoViewController.h
//  HKRtspPlayer
//
//  Created by Clover on 14-6-13.
//  Copyright (c) 2014年 Clover. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LxPlayerVideoViewController : UIViewController
{
    int x ;
    ASIFormDataRequest  *m_httpFormDataRequest;
    IBOutlet UIView      *m_weathrView;
}

@property (nonatomic, strong) NSDictionary *m_dataDictionary;
@property (strong, nonatomic) IBOutlet UILabel      *m_titleLabel;

@property (strong, nonatomic) IBOutlet UILabel      *m_timeLabel;
@property (strong, nonatomic) IBOutlet UILabel      *m_tempLabel;
@property (strong, nonatomic) IBOutlet UILabel      *m_rainLabel;
@property (strong, nonatomic) IBOutlet UILabel      *m_windLabel;
@property (strong, nonatomic) IBOutlet UILabel      *m_humidityLabel;



@end
