//
//  LxPlayerVideoViewController.m
//  HKRtspPlayer
//
//  Created by Clover on 14-6-13.
//  Copyright (c) 2014年 Clover. All rights reserved.
//

#import "LxPlayerVideoViewController.h"
#import "VideoPlaySDK.h"
#import "VideoPlayInfo.h"
#import "RecordInfo.h"
#import "CaptureInfo.h"
#import "VideoPlayUtility.h"


// 数据回调函数
void DataCallBack(STREAM_DATA_TYPE dataType, unsigned char *pBuffer, unsigned int nBufSize);
void DataCallBack(STREAM_DATA_TYPE dataType, unsigned char *pBuffer, unsigned int nBufSize)
{
    NSLog(@"dataType is %d", dataType);
    NSLog(@"nBufSize is %d", nBufSize);
}



@interface LxPlayerVideoViewController ()
{
    __unsafe_unretained IBOutlet UIView *_playView;
    VP_HANDLE _vpHandle;
    IBOutlet UIActivityIndicatorView *activity;
    RecordInfo *_recordInfo;
}
@property (nonatomic, strong) RecordInfo *recordInfo;

@end

@implementation LxPlayerVideoViewController

@synthesize recordInfo = _recordInfo;

@synthesize m_dataDictionary;
@synthesize m_titleLabel;
@synthesize m_timeLabel;
@synthesize m_tempLabel;
@synthesize m_rainLabel;
@synthesize m_windLabel;
@synthesize m_humidityLabel;


// 状态回调函数
void StatusCallBack(PLAY_STATE playState, VP_HANDLE hLogin, void *pHandl);

void StatusCallBack(PLAY_STATE playState, VP_HANDLE hLogin, void *pHandl)
{
    NSLog(@"playState is %d", playState);
    if (playState==0)
    {
//        [activity startAnimating];
    }
    
}



-(id)init
{
    self = [super init];
    if (self)
    {
        // Custom initialization
        if (iPhone5)
        {
            self = [super initWithNibName:@"LxPlayerVideoViewController_ip5" bundle:nil];
            
        }
        else
        {
            self = [super initWithNibName:@"LxPlayerVideoViewController" bundle:nil];
            
        }
    }
    return self;
}
- (IBAction)m_back_ButtonClick:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    NSThread* myThread = [[NSThread alloc] initWithTarget:self
                                                   selector:@selector(doSomething)
                                                     object:nil];
    [myThread start];
    
    
    
    
    [self updateDate];
    [activity startAnimating];

    
    NSLog(@"%@",m_dataDictionary);
    
    self.m_titleLabel.text = [m_dataDictionary objectForKey:K_name];
    
//    [self playApp:nil];
}
-(void)doSomething
{
    [self playApp:nil];
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(IBAction)playApp:(id)sender
{
    [activity startAnimating];
    // 设置播放信息
    VideoPlayInfo *videoInfo = [[VideoPlayInfo alloc] init];
    
    
    
    videoInfo.strUser   = @"admin";
    videoInfo.strPsw    = @"12345";
//    videoInfo.strPlayUrl    = @"rtsp://221.182.0.112:554/hikvision://20.1.1.6:8000:0:1??username=admin&password=12345";
    videoInfo.strPlayUrl    = [m_dataDictionary objectForKey:K_url];
    videoInfo.protocalType  = PROTOCAL_UDP;
    videoInfo.playType      = REAL_PLAY;
    videoInfo.streamMethod  = STREAM_METHOD_VTDU;
    videoInfo.streamType    = STREAM_MAIN;
    videoInfo.pPlayHandle   = (id)_playView;
    videoInfo.bSystransform = NO;
    
    if (_vpHandle != NULL)
    {
        VP_Logout(_vpHandle);
        _vpHandle = NULL;
    }
    
    // 获取VideoPlaySDK 播放句柄
    if (_vpHandle == NULL)
    {
        _vpHandle = VP_Login(videoInfo);
    }
    
    // 设置状态回调
    if (_vpHandle != NULL)
    {
        VP_SetStatusCallBack(_vpHandle, StatusCallBack, (__bridge void *)self);
    }
    
    // 开始实时预览
    if (_vpHandle != NULL)
    {
        if (!VP_RealPlay(_vpHandle))
        {
            NSLog(@"start VP_RealPlay failed");
            [activity stopAnimating];
            [[[UIAlertView alloc] initWithTitle:nil message:@"视频加载失败[start VP_RealPlay failed]" delegate:nil cancelButtonTitle:@"好" otherButtonTitles: nil] show];
        }
    }
}


// 停止播放实时预览或者远程回放
-(IBAction)pauseApp:(id)sender
{
    if (_vpHandle != NULL)
    {
        // 停止播放
        if (!VP_StopPlay(_vpHandle))
        {
            NSLog(@"VP_StopPlay failed");
        }
    }
}




#pragma mark 加载天气数据
-(void)updateDate
{
    if (m_httpFormDataRequest)
    {
        [m_httpFormDataRequest clearDelegatesAndCancel];
    }
    
    
    NSString *tempStrings = [URL QueryScenceWeatherUrl];
    m_httpFormDataRequest = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:tempStrings]];
    [m_httpFormDataRequest setStringEncoding :NSUTF8StringEncoding];//设置数据类型为utf-8
    [m_httpFormDataRequest setPostValue:[Tools getTokenString] forKey:K_token];
    [m_httpFormDataRequest setPostValue:[m_dataDictionary objectForKey:@"areacode"] forKey:@"areacode"];
    
    NSLog(@"%@:%@\n%@:%@\n%@:%@\n",
          @"url",tempStrings,
          K_token,[Tools getTokenString],
          @"areacode",[m_dataDictionary objectForKey:@"areacode"]);
    
    [m_httpFormDataRequest setDelegate:self];
    [m_httpFormDataRequest setDidFinishSelector : @selector (responseComplete:)];
    [m_httpFormDataRequest setDidFailSelector : @selector (responseFailed:)];
    [m_httpFormDataRequest startAsynchronous];
}
#pragma mark -
#pragma mark ASIFormDataRequest 回调函数

-( void )responseComplete:(ASIFormDataRequest*)request
{
    NSDictionary *dic = [[[request responseString] JSONValue] objectForKey:K_datas];
    if ([[m_dataDictionary objectForKey:@"areacode"] length]>0)
    {
        NSLog(@"%@",[request responseString]);
        self.m_timeLabel.text =[dic objectForKey:@"obstime"];
        self.m_tempLabel.text =[NSString stringWithFormat:@"温度:%@℃",[dic objectForKey:@"temp"]];
        self.m_rainLabel.text =[NSString stringWithFormat:@"降雨量:%@mm",[dic objectForKey:@"rain"]];
        self.m_windLabel.text =[NSString stringWithFormat:@"%@ , %@m/s",[dic objectForKey:@"winddirect"],[dic objectForKey:@"windvelocity"]];
        self.m_humidityLabel.text =[NSString stringWithFormat:@"湿度:%@%@",[dic objectForKey:@"relhumidity"],@"%"];
    }
    else
    {
    }
}

-( void )responseFailed:(ASIFormDataRequest*)request
{
    
}

@end
