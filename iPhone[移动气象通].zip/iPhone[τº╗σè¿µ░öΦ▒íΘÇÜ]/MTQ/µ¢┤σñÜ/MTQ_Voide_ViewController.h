//
//  MTQ_Voide_ViewController.h
//  scMobileWeather
//  气象视频主界面
//  Created by 小呆 on 14-1-3.
//  Copyright (c) 2014年 Lesogo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MTQ_Voide_ViewController : UIViewController
{
    NSMutableArray *m_TableViewArray1;
}

@property(nonatomic,strong) NSMutableArray *m_TableViewArray1;

-(IBAction)nextBtPressed:(UIButton*)sender;

-(IBAction)webViewBtPressed:(id)sender;//生活与健康
-(IBAction)scenicVoideBtPressed:(id)sender;

@end
