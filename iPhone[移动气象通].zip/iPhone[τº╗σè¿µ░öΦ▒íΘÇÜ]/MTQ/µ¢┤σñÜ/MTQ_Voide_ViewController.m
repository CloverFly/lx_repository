//
//  MTQ_Voide_ViewController.m
//  scMobileWeather
//  气象视频主界面
//  Created by 小呆 on 14-1-3.
//  Copyright (c) 2014年 Lesogo. All rights reserved.
//

#import "MTQ_Voide_ViewController.h"

#import "Voide_List_ViewController.h"
#import "More_LiveAndHealth_ViewController.h"
#import "Voide_Scenic_ViewController.h"

@implementation MTQ_Voide_ViewController

@synthesize m_TableViewArray1;

-(id)init
{
    if (iPhone5)
    {
        self = [super initWithNibName:@"MTQ_Voide_ViewController_ip5" bundle:nil];
    }
    else
    {
        self = [super initWithNibName:@"MTQ_Voide_ViewController" bundle:nil];
    }
    return self;
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}


- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib
    
    self.m_TableViewArray1 = [[NSMutableArray alloc] init];
    [m_TableViewArray1 addObject:@"全省天气预报"];
    [m_TableViewArray1 addObject:@"全省交通气象服务"];
    [m_TableViewArray1 addObject:@"全省旅游景区气象服务"];
    [m_TableViewArray1 addObject:@"实时气象新闻"];
    [m_TableViewArray1 addObject:@"气象科普知识"];
}


-(IBAction)nextBtPressed:(UIButton*)sender
{
    int index = sender.tag-500;
    NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
    [dic setObject:[m_TableViewArray1 objectAtIndex:index-1] forKey:K_title];
    [dic setObject:[NSString stringWithFormat:@"%d",index] forKey:K_type];
    
    Voide_List_ViewController *ViewCtr = [[Voide_List_ViewController alloc] init];
    ViewCtr.m_dictionary = dic;
    [self.navigationController pushViewController:ViewCtr animated:YES];
}

-(IBAction)webViewBtPressed:(id)sender
{
    More_LiveAndHealth_ViewController *viewCtr = [[More_LiveAndHealth_ViewController alloc] init];
    [self.navigationController pushViewController:viewCtr animated:YES];
}

-(IBAction)scenicVoideBtPressed:(id)sender
{
    Voide_Scenic_ViewController *viewCtr = [[Voide_Scenic_ViewController alloc] init];
    [self.navigationController pushViewController:viewCtr animated:YES];
}

@end