//
//  Voide_Scenic2_ViewController.m
//  scMobileWeatherIn
//
//  Created by lesogo on 14-5-7.
//  Copyright (c) 2014年 Lesogo. All rights reserved.
//

#import "Voide_Scenic2_ViewController.h"
#import "HN_QXSP_Next_ViewController.h"
#import "VoideListCell.h"
#import "LxPlayerVideoViewController.h"
@implementation Voide_Scenic2_ViewController

@synthesize m_dataDictionary;

-(id)init
{
    if (iPhone5)
    {
        self = [super initWithNibName:@"Voide_Scenic2_ViewController" bundle:nil];
    }
    else
    {
        self = [super initWithNibName:@"Voide_Scenic2_ViewController" bundle:nil];
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    if (iPhone5)
    {
        CGRect rct = self.m_TableView.frame;
        rct.size.height += 88;
        self.m_TableView.frame = rct;
    }
    
    self.m_TableViewArray = [[NSMutableArray alloc] init];
    if (m_dataDictionary)
    {
        if ([m_dataDictionary valueForKey:K_cityname])
        {
            self.m_TitleLabel.text = [NSString stringWithFormat:@"%@",[m_dataDictionary valueForKey:K_cityname]];
        }
        
        self.m_TableViewArray = [m_dataDictionary valueForKey:K_datas];
        [self.m_TableView reloadData];
    }
}

-(IBAction)backBtPressed:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark
#pragma mark UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (self.m_TableViewArray)
    {
        return self.m_TableViewArray.count;
    }
    
    return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *identifier = @"VoideListCell";
    //有标题
    VoideListCell *cell = (VoideListCell*)[tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:identifier owner:self options:nil];
        for (id oneObject in nib)
        {
            if ([oneObject isKindOfClass:[VoideListCell class]])
            {
                cell = (VoideListCell*)oneObject;
                break;
            }
        }
    }
    
    NSDictionary *dic = [self.m_TableViewArray objectAtIndex:indexPath.row];
    if (dic)
    {
        if ([dic valueForKey:K_name])
        {
            cell.m_TitileLabel.text = [NSString stringWithFormat:@"%@",[dic valueForKey:K_name]];
            if ([[dic objectForKey:@"isonline"] intValue]==1)
            {
                cell.m_stateLabel.text = [NSString stringWithFormat:@"%@",@"在线"];
            }
            else
            {
                cell.m_stateLabel.text = [NSString stringWithFormat:@"%@",@"离线"];
            }
            
        }
    }
    
    return cell;
}

#pragma mark
#pragma mark UITableViewDelegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 75;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    NSDictionary *dic = [self.m_TableViewArray objectAtIndex:indexPath.row];
    if (dic)
    {
        LxPlayerVideoViewController *viewCtr = [[LxPlayerVideoViewController alloc] init];
        viewCtr.m_dataDictionary = dic;
        [AppDelegate.navController pushViewController:viewCtr animated:YES];
    }
}

@end
