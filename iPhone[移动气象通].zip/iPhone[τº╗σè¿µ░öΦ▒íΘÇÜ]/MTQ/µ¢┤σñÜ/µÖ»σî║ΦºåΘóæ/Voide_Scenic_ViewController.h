//
//  Voide_Scenic_ViewController.h
//  scMobileWeatherIn
//
//  Created by lesogo on 14-5-7.
//  Copyright (c) 2014年 Lesogo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Voide_Scenic_ViewController : UIViewController
<UITableViewDataSource,UITableViewDelegate>
{
    ASIFormDataRequest  *m_httpFormDataRequest;
}

@property(nonatomic,strong) NSMutableArray          *m_TableViewArray;
@property(nonatomic,strong) IBOutlet UITableView    *m_TableView;

@end
