//
//  Voide_Scenic_ViewController.m
//  scMobileWeatherIn
//
//  Created by lesogo on 14-5-7.
//  Copyright (c) 2014年 Lesogo. All rights reserved.
//

#import "Voide_Scenic_ViewController.h"
#import "Voide_Scenic2_ViewController.h"

@implementation Voide_Scenic_ViewController

-(id)init
{
    if (iPhone5)
    {
        self = [super initWithNibName:@"Voide_Scenic_ViewController" bundle:nil];
    }
    else
    {
        self = [super initWithNibName:@"Voide_Scenic_ViewController" bundle:nil];
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    if (iPhone5)
    {
        CGRect rct = self.m_TableView.frame;
        rct.size.height += 88;
        self.m_TableView.frame = rct;
    }
    
    [self updateDate:nil];
}

-(IBAction)backBtPressed:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}


-(IBAction)updateDate:(id)sender
{
    if (m_httpFormDataRequest)
    {
        [m_httpFormDataRequest clearDelegatesAndCancel];
    }
    
    NSString *tempStrings = [URL QueryScenceVideoUrl];
    m_httpFormDataRequest = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:tempStrings]];
    [m_httpFormDataRequest setStringEncoding :NSUTF8StringEncoding];//设置数据类型为utf-8
    [m_httpFormDataRequest setPostValue:[Tools getTokenString] forKey:K_token];
    [m_httpFormDataRequest setDelegate:self];
    [m_httpFormDataRequest setDidFinishSelector : @selector (responseComplete:)];
    [m_httpFormDataRequest setDidFailSelector : @selector (responseFailed:)];
    [m_httpFormDataRequest startAsynchronous];
}

#pragma mark
#pragma mark UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (self.m_TableViewArray)
    {
        return self.m_TableViewArray.count;
    }
    
    return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    //预报数据
    static NSString *identifier = @"identifiers";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
        cell.backgroundColor = [UIColor clearColor];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        
        CGFloat TopDistance  = 0.0;//间距
        CGFloat tempViewHight = 44.0;//列表子视图高度
        CGFloat cellHight = 44.0;//列表高度
        
        CGRect cellRect = cell.frame;
        cellRect.size.height = cellHight;
        cell.frame = cellRect;
        
        //背景
        UIView *views = [[UIView alloc] initWithFrame:CGRectMake(0, TopDistance, CGRectGetWidth(tableView.frame), tempViewHight)];
        views.backgroundColor = [UIColor clearColor];
        [cell addSubview:views];
        
        /*
         //蒙层
         UIView *tempviews = [[UIView alloc] initWithFrame:CGRectMake(0.0, 0.0, CGRectGetWidth(views.frame), CGRectGetHeight(views.frame))];
         tempviews.backgroundColor = [UIColor blackColor];
         tempviews.alpha = 0.5;
         tempviews.layer.cornerRadius = 5.0;
         [views addSubview:tempviews];
         */
        
        CGFloat leftDistance = 15.0;
        CGSize  rightArrowSize = CGSizeMake(13, 13);
        CGFloat rightDistance = 5.0;
        //名称
        UILabel *nameLabel = [[UILabel alloc] initWithFrame:CGRectMake(leftDistance, 0,
                                                                       CGRectGetWidth(views.frame)-leftDistance-rightArrowSize.width-rightDistance,
                                                                       CGRectGetHeight(views.frame))];
        nameLabel.tag = 0x444;
        nameLabel.textAlignment = NSTextAlignmentLeft;
        nameLabel.backgroundColor = [UIColor clearColor];
        nameLabel.font = [UIFont systemFontOfSize:16];
        nameLabel.textColor = [UIColor blackColor];
        [views addSubview:nameLabel];
        
        //名称
        UILabel *stateLabel = [[UILabel alloc] initWithFrame:CGRectMake(200,0,100,CGRectGetHeight(views.frame))];
        stateLabel.tag = 0x445;
        stateLabel.textAlignment = NSTextAlignmentRight;
        stateLabel.backgroundColor = [UIColor clearColor];
        stateLabel.font = [UIFont systemFontOfSize:12];
        stateLabel.textColor = [UIColor lightGrayColor];
        [views addSubview:stateLabel];
        
        //右箭头
        UIImageView *rightArrowImageView = [[UIImageView alloc] initWithFrame:CGRectMake(CGRectGetWidth(views.frame)-rightArrowSize.width-rightDistance,
                                                                                         CGRectGetHeight(views.frame)/2.0-rightArrowSize.height/2.0,
                                                                                         rightArrowSize.width, rightArrowSize.height)];
        rightArrowImageView.contentMode = UIViewContentModeScaleAspectFit;
        rightArrowImageView.backgroundColor = [UIColor clearColor];
        rightArrowImageView.image = [UIImage imageNamed:@"qxsp_rightRow.png"];
        [views addSubview:rightArrowImageView];
        
        //虚线
        UIImageView *line_ImageView = [[UIImageView alloc] initWithFrame:CGRectMake(0.0, 0,CGRectGetWidth(views.frame), 1)];
        line_ImageView.contentMode = UIViewContentModeScaleToFill;
        line_ImageView.backgroundColor = [UIColor clearColor];
        line_ImageView.image = [UIImage imageNamed:@"qxsp_lineXu.png"];
        [views addSubview:line_ImageView];
    }
    
    UILabel *nameLabel = (UILabel*)[cell viewWithTag:0x444];
    UILabel *stateLabel = (UILabel*)[cell viewWithTag:0x445];
    NSDictionary *dic = [self.m_TableViewArray objectAtIndex:indexPath.row];
    if (dic)
    {
        //最高
        if ([dic valueForKey:K_cityname])
        {
            
            NSDictionary *dic = [NSDictionary dictionaryWithDictionary:[self.m_TableViewArray objectAtIndex:indexPath.row]];
            NSString*tempString = [NSString stringWithFormat:@"在线:%@/%d",[dic valueForKey:@"online"],[[dic valueForKey:K_datas] count]];
            nameLabel.text = [NSString stringWithFormat:@"%@",[dic valueForKey:K_cityname]];
            
            stateLabel.text = tempString;
        }
    }
    return  cell;
}

#pragma mark
#pragma mark UITableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    NSDictionary *dic = [[NSMutableDictionary alloc] initWithDictionary:[self.m_TableViewArray objectAtIndex:indexPath.row]];
    if (dic)
    {
        Voide_Scenic2_ViewController *viewCtr = [[Voide_Scenic2_ViewController alloc] init];
        viewCtr.m_dataDictionary = dic;
        [self.navigationController pushViewController:viewCtr animated:YES];
    }
}


#pragma mark -
#pragma mark ASIFormDataRequest 回调函数

-( void )responseComplete:(ASIFormDataRequest*)request
{
    NSDictionary *dic = [[request responseString] JSONValue];
    if(dic)
    {
        self.m_TableViewArray = [dic valueForKey:K_datas];
	}
    [self.m_TableView reloadData];
}

-( void )responseFailed:(ASIFormDataRequest*)request
{
}


@end
