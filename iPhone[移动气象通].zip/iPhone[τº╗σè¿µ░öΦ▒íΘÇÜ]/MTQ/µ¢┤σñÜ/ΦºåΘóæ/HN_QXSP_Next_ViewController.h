//
//  HN_QXSP_Next_ViewController.h
//  HN_iphone
//
//  Created by lesogoMacMini on 13-10-11.
//  Copyright (c) 2013年 lesogoMacMini. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HN_QXSP_Next_ViewController : UIViewController
<UIWebViewDelegate>

@property (nonatomic, strong) NSDictionary *m_dataDictionary;
@property (strong, nonatomic) IBOutlet UIWebView    *m_webView;
@property (strong, nonatomic) IBOutlet UILabel      *m_titleLabel;

@end
