//
//  HN_QXSP_Next_ViewController.m
//  HN_iphone
//
//  Created by lesogoMacMini on 13-10-11.
//  Copyright (c) 2013年 lesogoMacMini. All rights reserved.
//

#import "HN_QXSP_Next_ViewController.h"
#import "URL.h"
#import "Tools.h"

@implementation HN_QXSP_Next_ViewController


-(id)init
{
    self = [super init];
    if (self)
    {
        // Custom initialization
        if (iPhone5)
        {
            self = [super initWithNibName:@"HN_QXSP_Next_ViewController_ip5" bundle:nil];
            
        }
        else
        {
            self = [super initWithNibName:@"HN_QXSP_Next_ViewController" bundle:nil];
            
        }
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    UISwipeGestureRecognizer *swipe=[[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(swipeGoBack)];
    [self.view addGestureRecognizer:swipe];
}
/*!
 *@brief         手势返回上一个页面
 *@function     swipeGoBack:
 *@return       (void)
 */
-(void)swipeGoBack
{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"UIMoviePlayerControllerDidEnterFullscreenNotification" object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"UIMoviePlayerControllerWillExitFullscreenNotification" object:nil];
    
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    self.m_webView.scrollView.backgroundColor = [UIColor clearColor];
    self.m_webView.scrollView.bounces = NO;
    
    if ([self.m_dataDictionary valueForKey:K_url] && [[self.m_dataDictionary valueForKey:K_url] length]>10)
    {
        [self.m_webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:[self.m_dataDictionary valueForKey:K_url]]]];
    }
     
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(vedioStarted:) name:@"UIMoviePlayerControllerDidEnterFullscreenNotification"object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(vedioFinished:) name:@"UIMoviePlayerControllerWillExitFullscreenNotification"object:nil];
    
    if ([self.m_dataDictionary valueForKey:K_title])
    {
        self.m_titleLabel.text = [NSString stringWithFormat:@"%@",[self.m_dataDictionary valueForKey:K_title]];
    }

}

- (void)vedioStarted:(NSNotification *)notification
{
    AppDelegate.isFull = YES;
}

- (void)vedioFinished:(NSNotification *)notification
{
    AppDelegate.isFull = NO;
    if ([[UIDevice currentDevice] respondsToSelector:@selector(setOrientation:)]) {
        SEL selector = NSSelectorFromString(@"setOrientation:");
        NSInvocation *invocation = [NSInvocation invocationWithMethodSignature:[UIDevice instanceMethodSignatureForSelector:selector]];
        [invocation setSelector:selector];
        [invocation setTarget:[UIDevice currentDevice]];
        int val = UIDeviceOrientationPortrait;
        [invocation setArgument:&val atIndex:2];
        [invocation invoke];
    }
}

- (IBAction)m_back_ButtonClick:(id)sender
{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"UIMoviePlayerControllerDidEnterFullscreenNotification" object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"UIMoviePlayerControllerWillExitFullscreenNotification" object:nil];

    [self.navigationController popViewControllerAnimated:YES];
}



@end
