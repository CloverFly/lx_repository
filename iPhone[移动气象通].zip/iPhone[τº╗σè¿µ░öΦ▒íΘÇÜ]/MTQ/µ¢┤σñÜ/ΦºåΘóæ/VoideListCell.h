//
//  VoideListCell.h
//  scMobileWeather
//  未带标题的视频 cell
//  Created by 小呆 on 14-1-4.
//  Copyright (c) 2014年 Lesogo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface VoideListCell : UITableViewCell

@property(nonatomic,strong) IBOutlet UIImageView    *m_IconImageView;
@property(nonatomic,strong) IBOutlet UILabel        *m_TitileLabel;
@property(nonatomic,strong) IBOutlet UILabel        *m_stateLabel;
@property(nonatomic,strong) IBOutlet UILabel        *m_TimerLabel;
@end
