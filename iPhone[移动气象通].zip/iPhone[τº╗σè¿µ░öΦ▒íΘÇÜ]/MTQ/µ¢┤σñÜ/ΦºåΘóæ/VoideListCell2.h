//
//  VoideListCell2.h
//  scMobileWeather
//  带标题的视频 cell
//  Created by 小呆 on 14-1-4.
//  Copyright (c) 2014年 Lesogo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface VoideListCell2 : UITableViewCell

@property(nonatomic,strong) IBOutlet UIImageView    *m_IconImageView;
@property(nonatomic,strong) IBOutlet UILabel        *m_TitileLabel;
@property(nonatomic,strong) IBOutlet UILabel        *m_TimerLabel;
@property(nonatomic,strong) IBOutlet UITextView     *m_TextView;

@end
