//
//  VoideListCell2.m
//  scMobileWeather
//  带标题的视频 cell
//  Created by 小呆 on 14-1-4.
//  Copyright (c) 2014年 Lesogo. All rights reserved.
//

#import "VoideListCell2.h"

@implementation VoideListCell2

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
