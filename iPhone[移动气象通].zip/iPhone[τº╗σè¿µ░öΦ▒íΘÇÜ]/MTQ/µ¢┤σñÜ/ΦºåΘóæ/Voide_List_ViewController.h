//
//  Voide_List_ViewController.h
//  scMobileWeather
//  视频下载列表试图
//  Created by 小呆 on 14-1-4.
//  Copyright (c) 2014年 Lesogo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Voide_List_ViewController : UIViewController
<UITableViewDataSource,UITableViewDelegate>
{
    NSDictionary *m_dictionary;
    NSInteger    m_types;
    ASIFormDataRequest  *m_httpFormDataRequest;
}

@property(nonatomic,strong) NSDictionary            *m_dictionary;
@property(nonatomic,strong) IBOutlet UILabel        *m_TitleLabel;
@property(nonatomic,strong) IBOutlet UITableView    *m_TableView;
@property(nonatomic,strong) NSMutableArray          *m_TableViewArray;


-(IBAction)updateDate:(id)sender;

@end
