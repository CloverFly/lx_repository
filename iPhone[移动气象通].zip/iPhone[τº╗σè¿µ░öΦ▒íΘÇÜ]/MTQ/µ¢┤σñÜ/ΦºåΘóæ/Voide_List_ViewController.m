//
//  Voide_List_ViewController.m
//  scMobileWeather
//  视频下载列表试图
//  Created by 小呆 on 14-1-4.
//  Copyright (c) 2014年 Lesogo. All rights reserved.
//

#import "Voide_List_ViewController.h"

#import "VoideListCell.h"
#import "VoideListCell2.h"
#import "HN_QXSP_Next_ViewController.h"

@implementation Voide_List_ViewController

@synthesize m_dictionary;

-(id)init
{
    if (iPhone5)
    {
        self = [super initWithNibName:@"Voide_List_ViewController_ip5" bundle:nil];
    }
    else
    {
        self = [super initWithNibName:@"Voide_List_ViewController" bundle:nil];
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewDidDisappear:(BOOL)animated
{
    if (m_httpFormDataRequest)
    {
        [m_httpFormDataRequest clearDelegatesAndCancel];
    }
    [super viewDidDisappear:animated];
}
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    UISwipeGestureRecognizer *swipe=[[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(swipeGoBack)];
    [self.view addGestureRecognizer:swipe];
}
/*!
 *@brief         手势返回上一个页面
 *@function     swipeGoBack:
 *@return       (void)
 */
-(void)swipeGoBack
{
    [self.navigationController popViewControllerAnimated:YES];
}
- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    if (m_dictionary)
    {
        self.m_TitleLabel.text = [NSString stringWithFormat:@"%@",[m_dictionary valueForKey:K_title]];
        m_types = [[m_dictionary valueForKey:K_type] intValue];
    }
    
    self.m_TableViewArray = [[NSMutableArray alloc] init];
    
    [self updateDate:nil];
}


-(IBAction)backBtPressed:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

-(IBAction)updateDate:(id)sender
{
    if (1)
    {
        if (m_httpFormDataRequest)
        {
            [m_httpFormDataRequest clearDelegatesAndCancel];
        }
        
        NSString *tempStrings = [URL get_VoideUrl];
        m_httpFormDataRequest = [ ASIFormDataRequest requestWithURL:[NSURL URLWithString:tempStrings]];
        [m_httpFormDataRequest setStringEncoding :NSUTF8StringEncoding];//设置数据类型为utf-8
        [m_httpFormDataRequest setPostValue:@"1" forKey:K_pageNo];
        [m_httpFormDataRequest setPostValue:@"10000" forKey:K_pageSize];
        [m_httpFormDataRequest setPostValue:[m_dictionary valueForKey:K_type] forKey:K_type];
        [m_httpFormDataRequest setPostValue:[Tools getTokenString] forKey:K_token];
        [m_httpFormDataRequest setDelegate:self];
        [m_httpFormDataRequest setDidFinishSelector : @selector (responseComplete:)];
        [m_httpFormDataRequest setDidFailSelector : @selector (responseFailed:)];
        [m_httpFormDataRequest startAsynchronous];
    }
}


#pragma mark
#pragma mark UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (self.m_TableViewArray)
    {
        return self.m_TableViewArray.count;
    }
    return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    //无标题
    if (m_types<4)
    {
        static NSString *identifier = @"VoideListCell";
        VoideListCell *cell = (VoideListCell*)[tableView dequeueReusableCellWithIdentifier:identifier];
        if (cell == nil)
        {
            NSArray *nib = [[NSBundle mainBundle] loadNibNamed:identifier owner:self options:nil];
            for (id oneObject in nib)
            {
                if ([oneObject isKindOfClass:[VoideListCell class]])
                {
                    cell = (VoideListCell*)oneObject;
                    break;
                }
            }
        }
        
        NSDictionary *dic = [self.m_TableViewArray objectAtIndex:indexPath.row];
        if (dic)
        {
            NSString *timerT = [dic valueForKey:K_time];
            if (timerT && [timerT isKindOfClass:[NSString class]] && [timerT length]>=14)
            {
                NSMutableString *timerString = [[NSMutableString alloc] init];
                [timerString appendString:@"发布时间: "];
                [timerString appendFormat:@"%@-",[timerT substringWithRange:NSMakeRange(0, 4)]];
                [timerString appendFormat:@"%@-",[timerT substringWithRange:NSMakeRange(4, 2)]];
                [timerString appendFormat:@"%@ ",[timerT substringWithRange:NSMakeRange(6, 2)]];
                
                [timerString appendFormat:@"%@:",[timerT substringWithRange:NSMakeRange(8, 2)]];
                [timerString appendFormat:@"%@:",[timerT substringWithRange:NSMakeRange(10, 2)]];
                [timerString appendFormat:@"%@",[timerT substringWithRange:NSMakeRange(12, 2)]];
                
                cell.m_TimerLabel.text = timerString;
            }
        }
        return cell;
    }
    else
    {
        static NSString *identifier = @"VoideListCell2";
        //有标题
        VoideListCell2 *cell = (VoideListCell2*)[tableView dequeueReusableCellWithIdentifier:identifier];
        if (cell == nil)
        {
            NSArray *nib = [[NSBundle mainBundle] loadNibNamed:identifier owner:self options:nil];
            for (id oneObject in nib)
            {
                if ([oneObject isKindOfClass:[VoideListCell2 class]])
                {
                    cell = (VoideListCell2*)oneObject;
                    break;
                }
            }
        }
        
        NSDictionary *dic = [self.m_TableViewArray objectAtIndex:indexPath.row];
        if (dic)
        {
            if ([dic valueForKey:K_title])
            {
                cell.m_TitileLabel.text = [NSString stringWithFormat:@"%@",[dic valueForKey:K_title]];
            }
            NSString *timerT = [dic valueForKey:K_time];
            if (timerT && [timerT isKindOfClass:[NSString class]] && [timerT length]>=14)
            {
                NSMutableString *timerString = [[NSMutableString alloc] init];
                [timerString appendString:@"发布时间: "];
                [timerString appendFormat:@"%@-",[timerT substringWithRange:NSMakeRange(0, 4)]];
                [timerString appendFormat:@"%@-",[timerT substringWithRange:NSMakeRange(4, 2)]];
                [timerString appendFormat:@"%@ ",[timerT substringWithRange:NSMakeRange(6, 2)]];
                
                [timerString appendFormat:@"%@:",[timerT substringWithRange:NSMakeRange(8, 2)]];
                [timerString appendFormat:@"%@:",[timerT substringWithRange:NSMakeRange(10, 2)]];
                [timerString appendFormat:@"%@",[timerT substringWithRange:NSMakeRange(12, 2)]];
                
                cell.m_TimerLabel.text = timerString;
            }
        }
        
        return cell;
    }
    
    return nil;
}

#pragma mark
#pragma mark UITableViewDelegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return m_types>3?95:75;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    NSDictionary *dic = [self.m_TableViewArray objectAtIndex:indexPath.row];
    if (dic)
    {
        HN_QXSP_Next_ViewController *viewCtr = [[HN_QXSP_Next_ViewController alloc] init];
        viewCtr.m_dataDictionary = dic;
        [AppDelegate.navController pushViewController:viewCtr animated:YES];
    }
}

#pragma mark -
#pragma mark ASIFormDataRequest 回调函数

-( void )responseComplete:(ASIFormDataRequest*)request
{
    NSDictionary *dic = [[request responseString] JSONValue];
    if(dic)
    {
        self.m_TableViewArray = [dic valueForKey:K_datas];
	}
    [self.m_TableView reloadData];
}

-( void )responseFailed:(ASIFormDataRequest*)request
{
}


@end
