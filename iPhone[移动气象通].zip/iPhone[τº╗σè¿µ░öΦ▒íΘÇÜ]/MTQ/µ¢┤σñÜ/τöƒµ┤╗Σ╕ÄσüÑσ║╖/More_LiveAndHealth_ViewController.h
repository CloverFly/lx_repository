//
//  More_LiveAndHealth_ViewController.h
//  scMobileWeatherIn
//  生活与健康
//  Created by lesogo on 14-4-24.
//  Copyright (c) 2014年 Lesogo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface More_LiveAndHealth_ViewController : UIViewController
<UIWebViewDelegate>
{
    ASIFormDataRequest  *m_httpFormDataRequest;
}

@property(nonatomic,strong) IBOutlet UILabel    *m_TitleLabel;
@property(nonatomic,strong) IBOutlet UIWebView  *m_WebView;
@property(nonatomic,strong) IBOutlet UIActivityIndicatorView *m_ActivityIndicatorView;

-(IBAction)backBtPressed:(id)sender;

@end
