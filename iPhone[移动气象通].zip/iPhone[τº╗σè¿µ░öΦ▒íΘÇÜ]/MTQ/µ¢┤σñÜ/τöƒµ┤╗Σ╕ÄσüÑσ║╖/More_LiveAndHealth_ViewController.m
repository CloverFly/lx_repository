//
//  More_LiveAndHealth_ViewController.m
//  scMobileWeatherIn
//  生活与健康
//  Created by lesogo on 14-4-24.
//  Copyright (c) 2014年 Lesogo. All rights reserved.
//

#import "More_LiveAndHealth_ViewController.h"


@implementation More_LiveAndHealth_ViewController

-(id)init
{
    if (iPhone5)
    {
        self = [super initWithNibName:@"More_LiveAndHealth_ViewController_ip5" bundle:nil];
    }
    else
    {
        self = [super initWithNibName:@"More_LiveAndHealth_ViewController" bundle:nil];
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    [self updateInterface];
}

-(IBAction)backBtPressed:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)updateInterface
{
    DBMSEngine *engine = [[DBMSEngine alloc] init];
    NSMutableArray *dataArray = [engine querryCityWeather];
    if (dataArray && dataArray.count)
    {
        DB_CityInfo *info = [dataArray objectAtIndex:0];
        if (info && info.db_cityId)
        {
            if (m_httpFormDataRequest)
            {
                [m_httpFormDataRequest clearDelegatesAndCancel];
            }
            [self.m_ActivityIndicatorView startAnimating];
            NSString *tempStrings = [URL get_WeatherDataUrl];
            m_httpFormDataRequest = [ ASIFormDataRequest requestWithURL:[NSURL URLWithString:tempStrings]];
            [m_httpFormDataRequest setStringEncoding :NSUTF8StringEncoding];//设置数据类型为utf-8
            [m_httpFormDataRequest setPostValue:info.db_cityId forKey:K_cityId];
            [m_httpFormDataRequest setPostValue:@"true," forKey:@"mms"];
            [m_httpFormDataRequest setPostValue:iPhone5?@"40x71":@"2x3" forKey:K_scale];
            [m_httpFormDataRequest setPostValue:[Tools getTokenString] forKey:K_token];
            [m_httpFormDataRequest setDelegate:self];
            [m_httpFormDataRequest setDidFinishSelector : @selector (responseComplete:)];
            [m_httpFormDataRequest setDidFailSelector : @selector (responseFailed:)];
            [m_httpFormDataRequest startAsynchronous];
        }
    }
}

#pragma mark --
#pragma mark UIWebViewDelegate

- (void)webViewDidStartLoad:(UIWebView *)webView
{
    [self.m_ActivityIndicatorView startAnimating];
}

- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    [self.m_ActivityIndicatorView stopAnimating];
}

- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error
{
    [self.m_ActivityIndicatorView stopAnimating];
}

#pragma mark -
#pragma mark ASIFormDataRequest回调函数

-( void )responseComplete:(ASIFormDataRequest*)request
{
    [self.m_ActivityIndicatorView stopAnimating];
    NSDictionary *dic = [[request responseString] JSONValue];
    if(dic)
    {
        NSArray *mmsArray = [dic valueForKey:@"mms"];
        if (mmsArray && mmsArray.count)
        {
            NSDictionary *nextDic = [mmsArray objectAtIndex:0];
            if (nextDic)
            {
                if ([nextDic valueForKey:K_title])
                {
                    self.m_TitleLabel.text = [NSString stringWithFormat:@"%@",[nextDic valueForKey:K_title]];
                }
                
                if ([nextDic valueForKey:K_url])
                {
                    NSURL *url =[NSURL URLWithString:[nextDic valueForKey:K_url]];
                    NSURLRequest *request =[NSURLRequest requestWithURL:url];
                    [self.m_WebView loadRequest:request];
                }
            }
        }
	}
}

-( void )responseFailed:(ASIFormDataRequest*)request
{
    [self.m_ActivityIndicatorView stopAnimating];
}

@end
