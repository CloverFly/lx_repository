//
//  MTQ_WebView_ViewController.h
//  MTQ
//  气象预警
//  Created by lesogo on 13-12-20.
//  Copyright (c) 2013年 Lesogo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MTQ_WebView_ViewController : UIViewController
<UIWebViewDelegate>
{
    
}

@property(nonatomic,strong) NSDictionary                      *m_dataDictionary;
@property(nonatomic,strong) IBOutlet UIWebView                *m_WebView;
@property(nonatomic,strong) IBOutlet UILabel                  *m_TitleLabel;
@property(nonatomic,strong) IBOutlet UIActivityIndicatorView  *m_ActivityIndicatorView;

-(IBAction)backBtPressed:(UIButton*)sender;

@end
