//
//  MTQ_WebView_ViewController.m
//  MTQ
//  气象预警
//  Created by lesogo on 13-12-20.
//  Copyright (c) 2013年 Lesogo. All rights reserved.
//

#import "MTQ_WebView_ViewController.h"

@implementation MTQ_WebView_ViewController

@synthesize m_dataDictionary;

-(id)init
{
    if (iPhone5)
    {
        self = [super initWithNibName:@"MTQ_WebView_ViewController_ip5" bundle:nil];
    }
    else
    {
        self = [super initWithNibName:@"MTQ_WebView_ViewController" bundle:nil];
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    if (self.m_dataDictionary)
    {
        if ([m_dataDictionary valueForKey:K_title])
        {
            self.m_TitleLabel.text = [NSString stringWithFormat:@"%@",[m_dataDictionary valueForKey:K_title]];
        }

//        if ([m_dataDictionary valueForKey:K_content])
//        {
//            [self.m_WebView loadHTMLString:[m_dataDictionary valueForKey:K_content] baseURL:nil];
//        }
        
         NSURL *url =[NSURL URLWithString:[m_dataDictionary valueForKey:K_url]];
         NSURLRequest *request =[NSURLRequest requestWithURL:url];
         [self.m_WebView loadRequest:request];
    }
}

-(IBAction)backBtPressed:(UIButton*)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark --
#pragma mark UIWebViewDelegate

- (void)webViewDidStartLoad:(UIWebView *)webView
{
    [self.m_ActivityIndicatorView startAnimating];
}

- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    [self.m_ActivityIndicatorView stopAnimating];
}

- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error
{
    [self.m_ActivityIndicatorView stopAnimating];
}

@end
