//
//  MTQ_QSViewController.h
//  MTQ
//
//  Created by lesogo on 14-2-21.
//  Copyright (c) 2014年 Lesogo. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "QS_CustomInterFaceView.h"


@interface MTQ_QSViewController : UIViewController
<UIScrollViewDelegate>
{
    NSMutableArray  *m_dataArray;
    int             _index;
}

@property(nonatomic,strong) IBOutlet UIScrollView   *m_ScrollView;

-(void)loadInterface;//界面加载


@end
