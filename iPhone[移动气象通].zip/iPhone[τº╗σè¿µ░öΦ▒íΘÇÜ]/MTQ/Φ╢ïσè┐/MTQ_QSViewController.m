//
//  MTQ_QSViewController.m
//  MTQ
//
//  Created by lesogo on 14-2-21.
//  Copyright (c) 2014年 Lesogo. All rights reserved.
//

#import "MTQ_QSViewController.h"


#import "DBMSEngine.h"

@implementation MTQ_QSViewController

-(id)init
{
    if (iPhone5)
    {
        self = [super initWithNibName:@"MTQ_QSViewController_ip5" bundle:nil];
    }
    else
    {
        self = [super initWithNibName:@"MTQ_QSViewController" bundle:nil];
    }
    return self;
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewWillAppear:(BOOL)animated
{
    //[self performSelector:@selector(loadInterface) withObject:nil afterDelay:0.1f];
    [super viewWillAppear:animated];
    [self loadInterface];
}

-(void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    
    m_dataArray = nil;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    m_dataArray = [[NSMutableArray alloc] init];
    _index = 0;
    
}

-(void)loadInterface
{
    self.view.userInteractionEnabled = NO;
    //清除数据
    [m_dataArray removeAllObjects];
    for (QS_CustomInterFaceView *viewss in self.m_ScrollView.subviews)
    {
        if (viewss)
        {
            [viewss removeFromSuperview];
        }
    }
    
    //读取数据
    DBMSEngine *tempDBMSEngine = [[DBMSEngine alloc] init];
    [m_dataArray addObjectsFromArray:[tempDBMSEngine querryCityWeather]];
    tempDBMSEngine = nil;
    
    _index = 0;
    _index = 0;
    NSString *currentKeyString = [Tools readUserDefaultsInfo:K_cityId];
    if (currentKeyString)
    {
        int tempIndex = 0;
        for (DB_CityInfo *nextCityInfos in m_dataArray)
        {
            if (nextCityInfos && nextCityInfos.db_cityId)
            {
                if ([currentKeyString compare:nextCityInfos.db_cityId] == NSOrderedSame)
                {
                    _index = tempIndex;
                }
            }
            tempIndex++;
        }
    }
    
    //设置视图
    self.m_ScrollView.contentSize    = CGSizeMake(CGRectGetWidth(self.m_ScrollView.frame)*(m_dataArray.count>1?3:m_dataArray.count),
                                                  CGRectGetHeight(self.m_ScrollView.frame));
    
    if (m_dataArray && m_dataArray.count>1)
    {
        [self.m_ScrollView setContentOffset:CGPointMake(CGRectGetWidth(self.m_ScrollView.frame), 0) animated:NO];
        //加载界面、数据
        //第一页
        {
            QS_CustomInterFaceView *tempView  = [[QS_CustomInterFaceView alloc] init];
            tempView.frame = CGRectMake(0.0, 0.0,
                                        CGRectGetWidth(self.m_ScrollView.frame), CGRectGetHeight(self.m_ScrollView.frame));
            [self.m_ScrollView addSubview:tempView];
            //数据
            if ((_index-1)>=0)
            {
                tempView.m_PageControl.numberOfPages = m_dataArray.count;
                tempView.m_PageControl.currentPage = _index-1;
                DB_CityInfo *tempInfos = (DB_CityInfo*)[m_dataArray objectAtIndex:_index-1];
                if (tempInfos)
                {
                    tempView.m_CityInfo = tempInfos;
                    [tempView refushInterface];
                }
            }
            else
            {
                tempView.m_PageControl.numberOfPages = m_dataArray.count;
                tempView.m_PageControl.currentPage = m_dataArray.count-1;
                DB_CityInfo *tempInfos = (DB_CityInfo*)[m_dataArray objectAtIndex:m_dataArray.count-1];
                if (tempInfos)
                {
                    tempView.m_CityInfo = tempInfos;
                    [tempView refushInterface];
                }
            }
        }
        
        //第二页
        {
            QS_CustomInterFaceView *tempView  = [[QS_CustomInterFaceView alloc] init];
            tempView.frame = CGRectMake(CGRectGetWidth(self.m_ScrollView.frame), 0.0,
                                        CGRectGetWidth(self.m_ScrollView.frame), CGRectGetHeight(self.m_ScrollView.frame));
            [self.m_ScrollView addSubview:tempView];
            //数据
            if (m_dataArray.count>_index)
            {
                tempView.m_PageControl.numberOfPages = m_dataArray.count;
                tempView.m_PageControl.currentPage = _index;
                
                DB_CityInfo *tempInfos = (DB_CityInfo*)[m_dataArray objectAtIndex:_index];
                if (tempInfos)
                {
                    tempView.m_CityInfo = tempInfos;
                    
                    [tempView refushInterface];
                }
            }
            [tempView updateInterface];
        }
        
        //第三页
        {
            QS_CustomInterFaceView *tempView  = [[QS_CustomInterFaceView alloc] init];
            tempView.frame = CGRectMake(CGRectGetWidth(self.m_ScrollView.frame)*2, 0.0,
                                        CGRectGetWidth(self.m_ScrollView.frame), CGRectGetHeight(self.m_ScrollView.frame));
            [self.m_ScrollView addSubview:tempView];
            //数据
            int nextIndex = (m_dataArray.count>(_index+1))?(_index+1):0;
            tempView.m_PageControl.numberOfPages = m_dataArray.count;
            tempView.m_PageControl.currentPage = nextIndex;
            
            DB_CityInfo *tempInfos = (DB_CityInfo*)[m_dataArray objectAtIndex:nextIndex];
            if (tempInfos)
            {
                tempView.m_CityInfo = tempInfos;
                [tempView refushInterface];
            }
        }
    }
    else if(m_dataArray && m_dataArray.count)
    {
        QS_CustomInterFaceView *tempView  = [[QS_CustomInterFaceView alloc] init];
        tempView.frame = CGRectMake(0.0, 0.0,
                                    CGRectGetWidth(self.m_ScrollView.frame), CGRectGetHeight(self.m_ScrollView.frame));
        [self.m_ScrollView addSubview:tempView];
        //数据
        tempView.m_PageControl.numberOfPages = 1;
        tempView.m_PageControl.currentPage = 0;
        
        DB_CityInfo *tempInfos = (DB_CityInfo*)[m_dataArray objectAtIndex:0];
        if (tempInfos)
        {
            tempView.m_CityInfo = tempInfos;
            
            [tempView refushInterface];
        }
        [tempView updateInterface];
    }
    self.view.userInteractionEnabled = YES;
}

#pragma mark --
#pragma mark UIScrollViewDelegate

- (void)scrollViewWillBeginDecelerating:(UIScrollView *)scrollView
{
    scrollView.userInteractionEnabled = NO;
}

-(void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    CGFloat pageWidth = scrollView.frame.size.width;
    int pageIndex = floor((scrollView.contentOffset.x - pageWidth/2)/pageWidth) + 1;
    
    if (pageIndex == 0)
    {
        //左
        if (m_dataArray && m_dataArray.count)
        {
            _index = _index==0?(m_dataArray.count-1):(_index-1);
        }
        [self layoutCustomViewInterface:YES];
    }
    else if(pageIndex == 1)
    {
        //无变化
    }
    else if(pageIndex == 2)
    {
        //右
        if (m_dataArray && m_dataArray.count)
        {
            _index = (_index<(m_dataArray.count-1))?(_index+1):0;
        }
        [self layoutCustomViewInterface:NO];
    }
    
    [[NSUserDefaults standardUserDefaults] setValue:[NSString stringWithFormat:@"%d",_index] forKey:SKINDEXKEY];
    
    scrollView.userInteractionEnabled = YES;
    
}

//界面数据刷新
-(void)layoutCustomViewInterface:(BOOL)isLeft
{
    //读取数据
    [m_dataArray removeAllObjects];
    DBMSEngine *tempDBMSEngine = [[DBMSEngine alloc] init];
    [m_dataArray addObjectsFromArray:[tempDBMSEngine querryCityWeather]];
    
    QS_CustomInterFaceView *tempView1,*tempView2,*tempView3;
    
    for (id interfaceView in self.m_ScrollView.subviews)
    {
        if (interfaceView && [interfaceView isKindOfClass:[QS_CustomInterFaceView class]])
        {
            QS_CustomInterFaceView *view = (QS_CustomInterFaceView*)interfaceView;
            [view cancelUpdateRequest];
            
            if (CGRectGetMinX(view.frame) == 0)
            {
                tempView1 = view;
            }
            else if (CGRectGetMinX(view.frame) == CGRectGetWidth(self.m_ScrollView.frame))
            {
                tempView2 = view;
            }
            else if (CGRectGetMinX(view.frame) == CGRectGetWidth(self.m_ScrollView.frame)*2)
            {
                tempView3 = view;
            }
        }
    }
    
    if (isLeft)
    {
        //最后一页转至第一页
        tempView3.frame = CGRectMake(0.0, 0, CGRectGetWidth(self.m_ScrollView.frame), CGRectGetHeight(self.m_ScrollView.frame));
        tempView1.frame = CGRectMake(CGRectGetWidth(self.m_ScrollView.frame), 0, CGRectGetWidth(self.m_ScrollView.frame), CGRectGetHeight(self.m_ScrollView.frame));
        tempView2.frame = CGRectMake(CGRectGetWidth(self.m_ScrollView.frame)*2, 0, CGRectGetWidth(self.m_ScrollView.frame), CGRectGetHeight(self.m_ScrollView.frame));
        tempView3.m_PageControl.numberOfPages = m_dataArray.count;
        tempView1.m_PageControl.numberOfPages = m_dataArray.count;
        tempView2.m_PageControl.numberOfPages = m_dataArray.count;
        //数据处理
        [tempView3 JXHYBButton:tempView3.m_JXHYBButton];
        [tempView3 clearnInterface];
        if ((_index-1)>=0)
        {
            if (m_dataArray.count>(_index-1))
            {
                tempView3.m_PageControl.currentPage = _index-1;
                
                DB_CityInfo *tempInfos = (DB_CityInfo*)[m_dataArray objectAtIndex:_index-1];
                if (tempInfos)
                {
                    tempView3.m_CityInfo = tempInfos;
                    [tempView3 refushInterface];
                }
            }
        }
        else
        {
            tempView3.m_PageControl.numberOfPages = m_dataArray.count;
            tempView3.m_PageControl.currentPage   = m_dataArray.count-1;
            
            DB_CityInfo *tempInfos = (DB_CityInfo*)[m_dataArray objectAtIndex:m_dataArray.count-1];
            if (tempInfos)
            {
                tempView3.m_CityInfo = tempInfos;
                [tempView3 refushInterface];
            }
        }
        
        [tempView1 updateInterface];
        [Tools saveUserDefaultsInfo:tempView1.m_CityInfo.db_cityId :K_cityId];
        [[NSUserDefaults standardUserDefaults] setValue:[NSString stringWithFormat:@"%d",_index] forKey:SKINDEXKEY];
    }
    else
    {
        //第一页转至最后一页
        tempView2.frame = CGRectMake(0.0, 0, CGRectGetWidth(self.m_ScrollView.frame), CGRectGetHeight(self.m_ScrollView.frame));
        tempView3.frame = CGRectMake(CGRectGetWidth(self.m_ScrollView.frame), 0, CGRectGetWidth(self.m_ScrollView.frame), CGRectGetHeight(self.m_ScrollView.frame));
        tempView1.frame = CGRectMake(CGRectGetWidth(self.m_ScrollView.frame)*2, 0, CGRectGetWidth(self.m_ScrollView.frame), CGRectGetHeight(self.m_ScrollView.frame));
        tempView2.m_PageControl.numberOfPages = m_dataArray.count;
        tempView3.m_PageControl.numberOfPages = m_dataArray.count;
        tempView1.m_PageControl.numberOfPages = m_dataArray.count;
        //数据处理
        [tempView1 JXHYBButton:tempView1.m_JXHYBButton];
        [tempView1 clearnInterface];
        if (m_dataArray.count>(_index+1))
        {
            tempView1.m_PageControl.currentPage = _index+1;
            
            DB_CityInfo *tempInfos = (DB_CityInfo*)[m_dataArray objectAtIndex:_index+1];
            if (tempInfos)
            {
                tempView1.m_CityInfo = tempInfos;
                [tempView1 refushInterface];
            }
        }
        else
        {
            tempView1.m_PageControl.currentPage = 0;
            
            DB_CityInfo *tempInfos = (DB_CityInfo*)[m_dataArray objectAtIndex:0];
            if (tempInfos)
            {
                tempView1.m_CityInfo = tempInfos;
                [tempView1 refushInterface];
            }
        }
        
        [tempView3 updateInterface];
        [Tools saveUserDefaultsInfo:tempView3.m_CityInfo.db_cityId :K_cityId];
        [[NSUserDefaults standardUserDefaults] setValue:[NSString stringWithFormat:@"%d",_index] forKey:SKINDEXKEY];
    }
    
    [self.m_ScrollView setContentOffset:CGPointMake(CGRectGetWidth(self.m_ScrollView.frame), 0) animated:NO];
}


@end
