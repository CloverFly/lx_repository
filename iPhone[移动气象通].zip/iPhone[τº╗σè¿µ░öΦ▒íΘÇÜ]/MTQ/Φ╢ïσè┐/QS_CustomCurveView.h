//
//  QS_CustomCurveView.h
//  MTQ
//  趋势自定义曲线
//  Created by lesogo on 13-6-28.
//  Copyright (c) 2013年 Lesogo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface QS_CustomCurveView : UIView
{
	CGFloat         counts;//一共绘制的点数
	BOOL            isSameCoordinateSystem;//是否是相同坐标系 默认是NO
	CGFloat         m_maxValues,m_minValues;//当isSameCoordinateSystem为Yes时候生效
    
    NSArray         *groupArray;
}

@property(nonatomic) BOOL	isSameCoordinateSystem;
@property(nonatomic) CGFloat         counts;

@property(nonatomic,strong) NSArray *groupArray;

-(void)setgroupData:(NSArray*)aDataArray;

@end
