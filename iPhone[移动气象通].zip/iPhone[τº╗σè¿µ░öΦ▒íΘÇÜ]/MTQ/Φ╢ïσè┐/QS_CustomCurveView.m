//
//  QS_CustomCurveView.m
//  MTQ
//  趋势自定义曲线
//  Created by lesogo on 13-6-28.
//  Copyright (c) 2013年 Lesogo. All rights reserved.
//

#import "QS_CustomCurveView.h"


#import "KeyHeadString.h"
#import "Tools.h"

@implementation QS_CustomCurveView

@synthesize counts,isSameCoordinateSystem;

@synthesize groupArray;

#pragma mark --
#pragma mark

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
	{
        // Initialization code.
		self.backgroundColor = [UIColor clearColor];
		counts= 0;
		isSameCoordinateSystem = YES;
    }
    return self;
}


#pragma mark --
#pragma mark 绘制

- (void)drawRect:(CGRect)rect
{
	self.backgroundColor = [UIColor clearColor];
    //计算
    [self calcScales];
    
    if (counts && counts>=3)
    {
        CGFloat upDistance = 83.0;
        CGFloat downDistance = 55.0;
        CGFloat midDistance = rect.size.height-upDistance-downDistance;
        
        //绘制上部分数据
        [self drawUp:CGRectMake(0.0, 0.0, rect.size.width, upDistance)];
        //绘制曲线
        [self drawMutileCurves:CGRectMake(0.0, upDistance, rect.size.width, midDistance)];
        //下部分数据
        [self drawDown:CGRectMake(0.0, rect.size.height-downDistance, rect.size.width, downDistance)];
    }
    else
    {
        CGRect BGrects;
        BGrects.size = CGSizeMake(140, 120);
        BGrects.origin.x = rect.size.width/2.0-BGrects.size.width/2.0;
        BGrects.origin.y = rect.size.height/2.0-BGrects.size.height/2.0;
        [[UIImage imageNamed:@"趋势_暂无数据.png"] drawInRect:BGrects];
    }
}

-(void)calcScales
{
    m_maxValues = -10000;
    m_minValues = 100000;
    
    NSInteger groupCount = 0;
    for (NSDictionary*dic in groupArray)
    {
        if (dic)
        {
            CGFloat high = [[dic valueForKey:K_high] floatValue];
            CGFloat low = [[dic valueForKey:K_low] floatValue];
            
            m_maxValues = m_maxValues>high?m_maxValues:high;
            m_minValues = m_minValues<low?m_minValues:low;
        }
        groupCount++;
    }
    
    counts = counts==0?groupCount:counts;
}

//绘制上部分数据
-(void)drawUp:(CGRect)aRect
{
	if (groupArray == nil || [groupArray count]==0)
	{
		return;
	}
    
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGFloat optionW = aRect.size.width/counts;//宽度
    UIFont  *textFont = [UIFont systemFontOfSize:12];//文本字体
    CGFloat fontH = ([@"宽" sizeWithFont:textFont].height);//文本高度
    CGFloat updistance = 0.0;//上面间距
    CGFloat midDistance = (CGRectGetHeight(aRect)-updistance-fontH*2)/3.0;//文本之间的距离
    CGFloat optionH = CGRectGetHeight(aRect)-updistance;//有效区域的高度
    
    NSInteger index = 0;
    for (NSDictionary *dataDic in groupArray)
    {
        if (index>=counts)
            break;
        
        CGContextSetFillColorWithColor(context,[UIColor whiteColor].CGColor);
        if (dataDic)
        {
            //绘制竖线
            if (index)
            {
                CGRect imageRect;
                imageRect.size.width = 1;
                imageRect.size.height = optionH;
                imageRect.origin.x = aRect.origin.x+index*optionW-imageRect.size.width/2.0;
                imageRect.origin.y = aRect.origin.y+updistance;
                [[UIImage imageNamed:@"趋势_bottomline.png"] drawInRect:imageRect];
            }
            //绘制星期
            if ([dataDic valueForKey:K_time])
            {
                NSString *weekString = [Tools GetWeekNameFromString:[dataDic valueForKey:K_time]];
                
                CGPoint vPoint;
                vPoint.x = aRect.origin.x+index*optionW+optionW/2-([weekString sizeWithFont:textFont].width)/2.0;
                vPoint.y = aRect.origin.y+updistance+midDistance;
                [weekString drawAtPoint:vPoint withFont:textFont];
            }
            //绘制横线
            if (index == 0)
            {
                CGFloat lineH = 1.0;
                UIColor *lineColor = [UIColor colorWithRed:200/255.0 green:200/255.0 blue:200/255.0 alpha:0.5];
                CGContextSetStrokeColorWithColor(context,lineColor.CGColor);
                CGContextSetLineDash(context,0,nil,0);
                CGContextSetFillColorWithColor(context, lineColor.CGColor);
                CGContextSetLineWidth(context, lineH);
                CGContextMoveToPoint(context,0,aRect.origin.y+updistance+optionH/2.0-lineH/2.0);
                CGContextAddLineToPoint(context,CGRectGetWidth(aRect),aRect.origin.y+updistance+optionH/2.0-lineH/2.0);
                CGContextStrokePath(context);
                CGContextFillPath(context);
                CGContextSetFillColorWithColor(context,[UIColor whiteColor].CGColor);
            }
            //绘制天气
            if ([dataDic valueForKey:K_oneCode_cn])
            {
                NSString *values = [NSString stringWithFormat:@"%@",[dataDic valueForKey:K_oneCode_cn]];
                CGPoint vPoint;
                vPoint.x = aRect.origin.x+index*optionW+optionW/2-([values sizeWithFont:textFont].width)/2.0;
                vPoint.y = aRect.origin.y+updistance+midDistance*2+fontH;
                [values drawAtPoint:vPoint withFont:textFont];
            }
        }
        index++;
    }
}

//绘制高低温曲线
-(void)drawMutileCurves:(CGRect)aRect
{
	if (groupArray == nil || [groupArray count]==0)
	{
		return;
	}
    
    CGFloat      iconSize = 30.0;//天气图标大小
    CGFloat      pointWith = 6.0;//点的大小
    CGFloat      LineWidth = 2.0;//线宽
    
    UIFont       *textFont = [UIFont systemFontOfSize:10];//文本字体
    CGFloat      optionW = aRect.size.width/counts;//项宽
    CGFloat      fontH = ([@"宽" sizeWithFont:textFont].height);//文本高度
    CGFloat      effectiveArea = aRect.size.height-2*(fontH+iconSize)-pointWith;//有效区域
    CGFloat      pix = effectiveArea/(m_maxValues-m_minValues);//每个值占据的像素
    
    
    
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    UIColor *highColor = [UIColor whiteColor];//[UIColor colorWithRed:244/255.0 green:180.0/255.0 blue:122.0/255.0 alpha:1.0];
    UIColor *lowColor = [UIColor whiteColor];//[UIColor colorWithRed:149/255.0 green:163/255.0 blue:175/255.0 alpha:1.0];
    
    
    NSInteger index = 0;
    for (NSDictionary *dataDic in groupArray)
    {
        if (dataDic)
        {
            //绘制线
            if ((index+1)<[groupArray count])
            {
                CGFloat highValues = [[dataDic valueForKey:K_high] floatValue];
                CGFloat highValues2 = [[[groupArray objectAtIndex:index+1] valueForKey:K_high] floatValue];
                
                //高温
                if (highValues >= m_minValues && highValues <= m_maxValues && highValues2>=m_minValues && highValues2<= m_maxValues)
                {
                    NSDate *nowDate = [NSDate date];
                    double Time = [[[dataDic valueForKey:K_time] substringWithRange:NSMakeRange(0, 8)] intValue];
                    double curretTime = [[Tools dateFormatString:@"yyyyMMdd" setDate:nowDate] intValue];
                    if (Time<curretTime)
                    {
                        //虚线
                        CGContextBeginPath(context);
                        CGContextSetLineWidth(context, 2.0);
                        CGContextSetStrokeColorWithColor(context, [UIColor whiteColor].CGColor);
                        float lengths[] = {4,4};
                        CGContextSetLineDash(context, 0, lengths,2);
                        CGContextMoveToPoint(context,
                                             aRect.origin.x+optionW/2.0+index*optionW,
                                             aRect.origin.y+fontH+iconSize+(effectiveArea-pix*(highValues-m_minValues)));
                        CGContextAddLineToPoint(context,
                                                aRect.origin.x+optionW/2.0+(index+1)*optionW,
                                                aRect.origin.y+fontH+iconSize+(effectiveArea-pix*(highValues2-m_minValues)));
                        CGContextStrokePath(context);
                        CGContextFillPath(context);
                        CGContextClosePath(context);
                        
                    }
                    else
                    {
                        CGContextSetStrokeColorWithColor(context,highColor.CGColor);
                        CGContextSetLineDash(context,0,nil,0);
                        CGContextSetFillColorWithColor(context, highColor.CGColor);
                        CGContextSetLineWidth(context, LineWidth);
                        CGContextMoveToPoint(context,
                                             aRect.origin.x+optionW/2.0+index*optionW,
                                             aRect.origin.y+fontH+iconSize+(effectiveArea-pix*(highValues-m_minValues)));
                        CGContextAddLineToPoint(context,
                                                aRect.origin.x+optionW/2.0+(index+1)*optionW,
                                                aRect.origin.y+fontH+iconSize+(effectiveArea-pix*(highValues2-m_minValues)));
                        CGContextStrokePath(context);
                        CGContextFillPath(context);
                    }
                }
                //低温
                CGFloat lowValues =  [[dataDic valueForKey:K_low] floatValue];
                CGFloat lowValues2 =  [[[groupArray objectAtIndex:index+1] valueForKey:K_low] floatValue];
                if (lowValues >= m_minValues && lowValues <= m_maxValues && lowValues2>=m_minValues && lowValues2<= m_maxValues)
                {
                    NSDate *nowDate = [NSDate date];
                    double Time = [[[dataDic valueForKey:K_time] substringWithRange:NSMakeRange(0, 8)] intValue];
                    double curretTime = [[Tools dateFormatString:@"yyyyMMdd" setDate:nowDate] intValue];
                    if (Time<curretTime)
                    {
                        //虚线
                        CGContextBeginPath(context);
                        CGContextSetLineWidth(context, 2.0);
                        CGContextSetStrokeColorWithColor(context, [UIColor whiteColor].CGColor);
                        float lengths[] = {4,4};
                        CGContextSetLineDash(context, 0, lengths,2);
                        CGContextMoveToPoint(context,
                                             aRect.origin.x+optionW/2.0+index*optionW,
                                             aRect.origin.y+fontH+iconSize+(effectiveArea-pix*(lowValues-m_minValues)));
                        CGContextAddLineToPoint(context,
                                                aRect.origin.x+optionW/2.0+(index+1)*optionW,
                                                aRect.origin.y+fontH+iconSize+(effectiveArea-pix*(lowValues2-m_minValues)));
                        CGContextStrokePath(context);
                        CGContextEndPage(context);
                    }
                    else
                    {
                        CGContextSetStrokeColorWithColor(context,lowColor.CGColor);
                        CGContextSetFillColorWithColor(context, lowColor.CGColor);
                        CGContextSetLineDash(context,0,nil,0);
                        CGContextSetLineWidth(context, LineWidth);
                        CGContextMoveToPoint(context,
                                             aRect.origin.x+optionW/2.0+index*optionW,
                                             aRect.origin.y+fontH+iconSize+(effectiveArea-pix*(lowValues-m_minValues)));
                        CGContextAddLineToPoint(context,
                                                aRect.origin.x+optionW/2.0+(index+1)*optionW,
                                                aRect.origin.y+fontH+iconSize+(effectiveArea-pix*(lowValues2-m_minValues)));
                        CGContextStrokePath(context);
                    }
                }
            }
        }
        index++;
    }
    
    //绘制点和其他元素
    CGContextSetLineDash(context,0,nil,0);
    int pointIndex = 0;
    for (NSDictionary *dataDic in groupArray)
    {
        if (dataDic)
        {
            CGFloat highValues = [[dataDic valueForKey:K_high] floatValue];
            //高温
            UIColor *high_pointColor = [UIColor colorWithRed:244/255.0 green:180.0/255.0 blue:122.0/255.0 alpha:1.0];
            if (highValues >= m_minValues && highValues <= m_maxValues)
            {
				CGRect pointRect;
				pointRect = CGRectMake(aRect.origin.x+optionW/2.0-pointWith/2.0+pointIndex*optionW,
									   aRect.origin.y+fontH+iconSize+(effectiveArea-pix*(highValues-m_minValues))-LineWidth,
                                       pointWith,pointWith);
				//绘制点
				CGContextSetLineWidth(context, 1.0);
				CGContextSetStrokeColorWithColor(context,[UIColor whiteColor].CGColor);
				CGContextSetFillColorWithColor(context, high_pointColor.CGColor);
				CGContextAddEllipseInRect(context,pointRect);
				CGContextDrawPath(context, kCGPathFillStroke);
                //绘制上面的值
				CGContextSetFillColorWithColor(context,[UIColor whiteColor].CGColor);
				NSString *values = [NSString stringWithFormat:@"%@℃",[dataDic valueForKey:K_high]];
				CGPoint vPoint = pointRect.origin;
                vPoint.x = vPoint.x+pointWith/2-([values sizeWithFont:textFont].width)/2.0;
                vPoint.y = vPoint.y-fontH;
				[values drawAtPoint:vPoint withFont:textFont];
                //绘制天气图标
                CGRect iconrect = CGRectMake(0, 0, iconSize, iconSize);
                iconrect.origin.x = pointRect.origin.x+pointRect.size.width/2.0-iconSize/2.0;
                iconrect.origin.y = pointRect.origin.y-fontH-iconSize;
                [[Tools getDayWeatherImage:[dataDic valueForKey:K_oneCode]] drawInRect:iconrect];
            }
            //低温
            CGFloat lowValues =  [[dataDic valueForKey:K_low] floatValue];
            UIColor *low_pointColor = [UIColor blueColor];
            if (lowValues >= m_minValues && lowValues <= m_maxValues)
            {
				CGRect pointRect;
				pointRect = CGRectMake(aRect.origin.x+optionW/2.0-pointWith/2.0+pointIndex*optionW,
									   aRect.origin.y+fontH+iconSize+(effectiveArea-pix*(lowValues-m_minValues))-LineWidth,
                                       pointWith,pointWith);
				//绘制点
				CGContextSetLineWidth(context, 1.0);
				CGContextSetStrokeColorWithColor(context,[UIColor whiteColor].CGColor);
				CGContextSetFillColorWithColor(context, low_pointColor.CGColor);
				CGContextAddEllipseInRect(context,pointRect);
				CGContextDrawPath(context, kCGPathFillStroke);
                //绘制上面的值
				CGContextSetFillColorWithColor(context,[UIColor whiteColor].CGColor);
				NSString *values = [NSString stringWithFormat:@"%@℃",[dataDic valueForKey:K_low]];
				CGPoint vPoint = pointRect.origin;
                vPoint.x = vPoint.x+pointWith/2-([values sizeWithFont:textFont].width)/2.0;
                vPoint.y = vPoint.y+pointWith;
				[values drawAtPoint:vPoint withFont:textFont];
                //绘制天气图标
                CGRect iconrect = CGRectMake(0, 0, iconSize, iconSize);
                iconrect.origin.x = pointRect.origin.x+pointRect.size.width/2.0-iconSize/2.0;
                iconrect.origin.y = pointRect.origin.y+pointWith+fontH;
                [[Tools getDayWeatherImage:[dataDic valueForKey:K_twoCode]] drawInRect:iconrect];
            }
        }
        pointIndex++;
    }
}

//绘制下部分数据
-(void)drawDown:(CGRect)aRect
{
	if (groupArray == nil || [groupArray count]==0)
	{
		return;
	}
    
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGFloat optionW = aRect.size.width/counts;//宽度
    UIFont  *textFont = [UIFont systemFontOfSize:12];//文本字体
    CGFloat fontH = ([@"宽" sizeWithFont:textFont].height);//文本高度
    CGFloat updistance = 0.0;//上面间距
    CGFloat midDistance = (CGRectGetHeight(aRect)-updistance-fontH*2)/3.0;//文本之间的距离
    CGFloat optionH = CGRectGetHeight(aRect)-updistance;//有效区域的高度
    
    NSInteger index = 0;
    for (NSDictionary *dataDic in groupArray)
    {
        if (index>=counts)
            break;
        
        CGContextSetFillColorWithColor(context,[UIColor whiteColor].CGColor);
        if (dataDic)
        {
            //绘制竖线
            if (index)
            {
                CGRect imageRect;
                imageRect.size.width = 1;
                imageRect.size.height = optionH;
                imageRect.origin.x = aRect.origin.x+index*optionW-imageRect.size.width/2.0;
                imageRect.origin.y = aRect.origin.y+updistance;
                [[UIImage imageNamed:@"趋势_bottomline.png"] drawInRect:imageRect];
            }
            //绘制天气
            if ([dataDic valueForKey:K_twoCode_cn])
            {
                NSString *values = [NSString stringWithFormat:@"%@",[dataDic valueForKey:K_twoCode_cn]];
                CGPoint vPoint;
                vPoint.x = aRect.origin.x+index*optionW+optionW/2-([values sizeWithFont:textFont].width)/2.0;
                vPoint.y = aRect.origin.y+updistance+midDistance;
                [values drawAtPoint:vPoint withFont:textFont];
            }
            //绘制横线
            if (index == 0)
            {
                CGFloat lineH = 1.0;
                UIColor *lineColor = [UIColor colorWithRed:200/255.0 green:200/255.0 blue:200/255.0 alpha:0.5];
                CGContextSetStrokeColorWithColor(context,lineColor.CGColor);
                CGContextSetLineDash(context,0,nil,0);
                CGContextSetFillColorWithColor(context, lineColor.CGColor);
                CGContextSetLineWidth(context, lineH);
                CGContextMoveToPoint(context,0,aRect.origin.y+updistance+optionH/2.0-lineH/2.0);
                CGContextAddLineToPoint(context,CGRectGetWidth(aRect),aRect.origin.y+updistance+optionH/2.0-lineH/2.0);
                CGContextStrokePath(context);
                CGContextFillPath(context);
                CGContextSetFillColorWithColor(context,[UIColor whiteColor].CGColor);
            }
            //绘制日期
            if ([dataDic valueForKey:K_time])
            {
                NSString *timerss = [dataDic valueForKey:K_time];
                NSString *mouthString = [NSString stringWithFormat:@"%d",[[timerss substringWithRange:NSMakeRange(4, 2)] intValue]];
                NSString *dayStrings = [NSString stringWithFormat:@"%d",[[timerss substringWithRange:NSMakeRange(6, 2)] intValue]];
                NSString *dateString = [NSString stringWithFormat:@"%@/%@",mouthString,dayStrings];
                CGPoint vPoint;
                vPoint.x = aRect.origin.x+index*optionW+optionW/2-([dateString sizeWithFont:textFont].width)/2.0;
                vPoint.y = aRect.origin.y+updistance+midDistance*2+fontH;
                [dateString drawAtPoint:vPoint withFont:textFont];
            }
        }
        index++;
    }
}

-(void)setgroupData:(NSArray*)aDataArray;
{
    counts = 0;
    self.groupArray = aDataArray;
    [self setNeedsDisplay];
}

@end
