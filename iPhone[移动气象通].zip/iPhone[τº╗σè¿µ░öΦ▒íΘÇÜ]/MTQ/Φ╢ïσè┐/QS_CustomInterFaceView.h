//
//  QS_CustomInterFaceView.h
//  MTQ
//
//  Created by lesogo on 14-2-21.
//  Copyright (c) 2014年 Lesogo. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "QS_CustomCurveView.h"

@interface QS_CustomInterFaceView : UIView
<UITableViewDataSource,UITableViewDelegate>
{
    ASIFormDataRequest  *m_httpFormDataRequest;
    ASIFormDataRequest  *m_httpFormDataRequest_image;
}

@property(nonatomic,strong) DB_CityInfo *m_CityInfo;
@property(nonatomic,strong) IBOutlet UILabel        *m_CityNameLabel;
@property(nonatomic,strong) IBOutlet UIImageView    *m_LocationImageView;
@property(nonatomic,strong) IBOutlet UIImageView    *m_backGroundImageView;
@property(nonatomic,strong) IBOutlet UIButton       *m_CityManageButton;
@property(nonatomic,strong) IBOutlet UIPageControl  *m_PageControl;

@property(nonatomic,strong) IBOutlet UIView             *m_interFaceView;
@property(nonatomic,strong) IBOutlet UITableView        *m_TableView;
@property(nonatomic,strong) IBOutlet QS_CustomCurveView *m_CustomCurveView;
@property(nonatomic,strong) IBOutlet UITextView         *m_TextView;

@property(nonatomic,strong) IBOutlet UIButton       *m_JXHYBButton;
@property(nonatomic,strong) IBOutlet UIButton       *m_QSButton;
@property(nonatomic,strong) IBOutlet UIButton       *m_ZSButton;

@property(nonatomic,strong) IBOutlet UILabel        *m_UpdateTimeLabel;

@property(nonatomic,strong) NSMutableArray *m_TableViewArray;

-(IBAction)cityManagerBtPressed:(UIButton*)sender;//城市管理按钮

//界面数据处理
-(void)clearnInterface;//清空界面
-(void)refushInterface;//刷新界面

-(void)cancelUpdateRequest;//取消更新请求
-(void)updateInterface;//更新数据

-(IBAction)JXHYBButton:(id)sender;
-(IBAction)QSButton:(id)sender;
-(IBAction)ZSButton:(id)sender;

@end
