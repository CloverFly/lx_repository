//
//  QS_CustomInterFaceView.m
//  MTQ
//
//  Created by lesogo on 14-2-21.
//  Copyright (c) 2014年 Lesogo. All rights reserved.
//

#import "QS_CustomInterFaceView.h"

#import "MTQ_CityManager_ViewController.h"
#import "UIImageView+WebCache.h"
#import "Tools.h"

@implementation QS_CustomInterFaceView

@synthesize m_CityInfo;

-(id)init
{
    if (iPhone5)
    {
        NSArray *arrays = [[NSBundle mainBundle] loadNibNamed:@"QS_CustomInterFaceView_ip5" owner:self options:nil];
        self = (QS_CustomInterFaceView*)[arrays objectAtIndex:0];
    }
    else
    {
        NSArray *arrays = [[NSBundle mainBundle] loadNibNamed:@"QS_CustomInterFaceView" owner:self options:nil];
        self = (QS_CustomInterFaceView*)[arrays objectAtIndex:0];
    }
    
    self.m_interFaceView.layer.cornerRadius = 5.0;
    
    return self;
}


-(IBAction)cityManagerBtPressed:(UIButton*)sender
{
    MTQ_CityManager_ViewController *viewCtr = [[MTQ_CityManager_ViewController alloc] init];
    [AppDelegate.navController pushViewController:viewCtr animated:YES];
}

-(void)cancelUpdateRequest//取消更新请求
{
    if (m_httpFormDataRequest)
    {
        [m_httpFormDataRequest clearDelegatesAndCancel];
    }
    if (m_httpFormDataRequest_image)
    {
        [m_httpFormDataRequest_image clearDelegatesAndCancel];
    }
}

-(void)clearnInterface
{
    self.m_ZSButton.hidden = YES;
    self.m_UpdateTimeLabel.text= @"";
    self.m_TextView.text = @"暂无走势数据";
    self.m_backGroundImageView.image = [UIImage imageNamed:@"bg_1.jpg"];
    [self.m_CustomCurveView setgroupData:nil];
    
    self.m_TableViewArray = nil;
    self.m_TableViewArray = [[NSMutableArray alloc] init];
}

-(void)refushInterface
{
    [self clearnInterface];
    
    if (self.m_CityInfo && self.m_CityInfo.db_cityId)
    {
        [self cityNameChange];
        
        NSDictionary *dic = [Tools JsonParser:self.m_CityInfo.db_content];
        if (dic)
        {
            //实况
            NSDictionary *skDic = [dic valueForKey:K_sk];
            if (skDic)
            {
                //发布时间
                if ([skDic valueForKey:K_time] && [[skDic valueForKey:K_time] isKindOfClass:[NSString class]] && [[skDic valueForKey:K_time] length] == 14)
                {
                    NSMutableString *timerString = [[NSMutableString alloc] init];
                    [timerString appendFormat:@"%@:",[[skDic valueForKey:K_time] substringWithRange:NSMakeRange(8, 2)]];
                    [timerString appendFormat:@"%@ 更新",[[skDic valueForKey:K_time] substringWithRange:NSMakeRange(10, 2)]];
                    self.m_UpdateTimeLabel.text = timerString;
                }
            }
            
            //预报
            NSDictionary *ybDict = [dic valueForKey:K_yb];
   
            NSString*zsTitleStr = [[ybDict objectForKey:@"flag"] integerValue]==2?@"全州天气":@"全市天气";
            [self.m_ZSButton setTitle:zsTitleStr forState:0];
            [self.m_ZSButton setTitle:zsTitleStr forState:1];
            [self.m_ZSButton setTitle:zsTitleStr forState:2];
            [self.m_ZSButton setTitle:zsTitleStr forState:3];
            NSArray *ybArray = [ybDict valueForKey:K_datas];
            if (ybArray && ybArray.count)
            {
                [self.m_CustomCurveView setgroupData:ybArray];
            }
            //精细化预报
            if (!self.m_TableViewArray)
            {
                self.m_TableViewArray = [[NSMutableArray alloc] init];
            }
            NSArray *jxhybArray = [dic valueForKey:K_jxhyb];
            for (NSDictionary *jxhybDictionary in jxhybArray)
            {
                if (jxhybDictionary)
                {
                    [self.m_TableViewArray addObject:jxhybDictionary];
                }
            }
            [self.m_TableView reloadData];
            //走势
            if (ybDict)
            {
                NSString *contentString = [ybDict valueForKey:K_content];
                if (contentString)
                {
                    if ([contentString isKindOfClass:[NSString class]] && [contentString length]>1)
                    {
                        self.m_ZSButton.hidden = NO;
                        self.m_TextView.text = [NSString stringWithFormat:@"%@",[ybDict valueForKey:K_content]];
                    }
                }
            }
        }
    }
    
    CGRect rct = self.m_JXHYBButton.frame;
    rct.origin.x = self.frame.size.width/2.0-(rct.size.width*2+(self.m_ZSButton.hidden?0:rct.size.width))/2.0;
    self.m_JXHYBButton.frame = rct;
    
    rct = self.m_QSButton.frame;
    rct.origin.x = CGRectGetMaxX(self.m_JXHYBButton.frame);
    self.m_QSButton.frame = rct;
}

-(void)cityNameChange
{
    if (m_CityInfo)
    {
        NSDictionary *dic = [Tools JsonParser:self.m_CityInfo.db_content];
        if (dic)
        {
            //背景
            NSDictionary *skDic = [dic valueForKey:K_sk];
            if (skDic && [skDic valueForKey:K_url])
            {
                [self downLoadImage:[skDic valueForKey:K_url]];
            }
        }
        
        //名称处理
        self.m_LocationImageView.hidden = YES;
        if (m_CityInfo.db_islocation && [m_CityInfo.db_islocation intValue]==1)
        {
            self.m_LocationImageView.hidden = NO;
        }
        if (m_CityInfo.db_cityName)
        {
            self.m_CityNameLabel.text = [NSString stringWithFormat:@"%@",m_CityInfo.db_cityName];
        }
        
        CGFloat leftButtonW = CGRectGetMaxX(self.m_CityManageButton.frame);//左按钮的最大x点
        CGFloat locationImageW = CGRectGetWidth(self.m_LocationImageView.frame);//定位标示图片的宽度
        CGFloat distance = 5;//间隙
        CGFloat nameW = [self.m_CityNameLabel.text sizeWithFont:self.m_CityNameLabel.font].width;//城市名的宽度
        
        CGFloat currentX =CGRectGetWidth(self.frame)/2.0-(nameW+distance+!self.m_LocationImageView.hidden*locationImageW)/2.0;
        if (currentX>=leftButtonW)
        {
            CGRect rct = self.m_CityNameLabel.frame;
            rct.origin.x = currentX;
            rct.size.width = nameW;
            self.m_CityNameLabel.frame = rct;
            
            rct = self.m_LocationImageView.frame;
            rct.origin.x = CGRectGetMaxX(self.m_CityNameLabel.frame)+distance;
            self.m_LocationImageView.frame = rct;
        }
        else
        {
            if ((nameW+distance+!self.m_LocationImageView.hidden*locationImageW+leftButtonW)<=CGRectGetWidth(self.frame))
            {
                CGRect rct = self.m_CityNameLabel.frame;
                rct.origin.x = leftButtonW;
                rct.size.width = nameW;
                self.m_CityNameLabel.frame = rct;
                
                rct = self.m_LocationImageView.frame;
                rct.origin.x = CGRectGetMaxX(self.m_CityNameLabel.frame)+distance;
                self.m_LocationImageView.frame = rct;
            }
            else
            {
                CGRect rct = self.m_CityNameLabel.frame;
                rct.origin.x = leftButtonW;
                rct.size.width = CGRectGetWidth(self.frame)-leftButtonW-!self.m_LocationImageView.hidden*locationImageW;
                self.m_CityNameLabel.frame = rct;
                
                rct = self.m_LocationImageView.frame;
                rct.origin.x = CGRectGetMaxX(self.m_CityNameLabel.frame)+distance;
                self.m_LocationImageView.frame = rct;
            }
        }
        
    }
}

-(void)updateInterface//更新数据
{
    if (self.m_CityInfo && self.m_CityInfo.db_cityId && [self.m_CityInfo.db_cityId isKindOfClass:[NSString class]])
    {
        if ([Tools isCanUpdate:self.m_CityInfo.db_cityId])
        {
            if (m_httpFormDataRequest)
            {
                [m_httpFormDataRequest clearDelegatesAndCancel];
            }
            
            NSString *tempStrings = [URL get_WeatherDataUrl];
            m_httpFormDataRequest = [ ASIFormDataRequest requestWithURL:[NSURL URLWithString:tempStrings]];
            [m_httpFormDataRequest setStringEncoding :NSUTF8StringEncoding];//设置数据类型为utf-8
            [m_httpFormDataRequest setPostValue:self.m_CityInfo.db_cityId forKey:K_cityId];
            [m_httpFormDataRequest setPostValue:@"true," forKey:K_cityInfo];
            [m_httpFormDataRequest setPostValue:@"true," forKey:K_sk];
            [m_httpFormDataRequest setPostValue:@"true," forKey:K_sk_zd];
            [m_httpFormDataRequest setPostValue:@"true," forKey:K_yb];
            [m_httpFormDataRequest setPostValue:@"true," forKey:K_jxhyb];
            [m_httpFormDataRequest setPostValue:@"true," forKey:K_zh];
            [m_httpFormDataRequest setPostValue:@"true," forKey:K_lifeIndex];
            [m_httpFormDataRequest setPostValue:@"true," forKey:K_fest];
            [m_httpFormDataRequest setPostValue:@"true," forKey:K_air];
            [m_httpFormDataRequest setPostValue:@"true," forKey:K_updown];
            [m_httpFormDataRequest setPostValue:self.m_CityInfo.db_latitude forKey:K_latitude];
            [m_httpFormDataRequest setPostValue:self.m_CityInfo.db_longitude forKey:K_latitude];
            [m_httpFormDataRequest setPostValue:iPhone5?@"40x71":@"2x3" forKey:K_scale];
            [m_httpFormDataRequest setPostValue:[Tools getTokenString] forKey:K_token];
            [m_httpFormDataRequest setDelegate:self];
            [m_httpFormDataRequest setDidFinishSelector : @selector (responseComplete:)];
            [m_httpFormDataRequest setDidFailSelector : @selector (responseFailed:)];
            [m_httpFormDataRequest startAsynchronous];
        }
    }
}

-(void)downLoadImage:(NSString*)aUrl
{
    if (aUrl && [aUrl isKindOfClass:[NSString class]] && [aUrl length]>10)
    {
        NSString *imageSavePath = [Tools readDocumentsImageSavePath:aUrl];
        if ([Tools isFileExitPath:imageSavePath])
        {
            UIImage *imagedata = [UIImage imageWithContentsOfFile:imageSavePath];
            
            if (imagedata)
            {
                self.m_backGroundImageView.image = imagedata;
            }
        }
        else
        {
            if (m_httpFormDataRequest_image)
            {
                [m_httpFormDataRequest_image clearDelegatesAndCancel];
            }
            NSURL *urlss = [NSURL URLWithString:aUrl];
            m_httpFormDataRequest_image = [ ASIFormDataRequest requestWithURL:urlss];
            [m_httpFormDataRequest_image setStringEncoding :NSUTF8StringEncoding];//设置数据类型为utf-8
            m_httpFormDataRequest_image.username = aUrl;
            [m_httpFormDataRequest_image setDelegate:self];
            [m_httpFormDataRequest_image setDidFinishSelector : @selector(responseComplete_image:)];
            [m_httpFormDataRequest_image setDidFailSelector : nil];
            [m_httpFormDataRequest_image startAsynchronous];
        }
    }
}

-(IBAction)JXHYBButton:(id)sender
{
    if (self.m_TableView.hidden)
    {
        self.m_TableView.hidden = NO;
        self.m_CustomCurveView.hidden = YES;
        self.m_TextView.hidden = YES;
        
        [self.m_JXHYBButton setBackgroundImage:[self.m_JXHYBButton backgroundImageForState:UIControlStateHighlighted] forState:0];
        [self.m_QSButton setBackgroundImage:[self.m_QSButton backgroundImageForState:UIControlStateSelected] forState:0];
        [self.m_ZSButton setBackgroundImage:[self.m_ZSButton backgroundImageForState:UIControlStateSelected] forState:0];
    }
}

-(IBAction)QSButton:(id)sender
{
    if (self.m_CustomCurveView.hidden)
    {
        self.m_TableView.hidden = YES;
        self.m_CustomCurveView.hidden = NO;
        self.m_TextView.hidden = YES;
        
        [self.m_JXHYBButton setBackgroundImage:[self.m_JXHYBButton backgroundImageForState:UIControlStateSelected] forState:0];
        [self.m_QSButton setBackgroundImage:[self.m_QSButton backgroundImageForState:UIControlStateHighlighted] forState:0];
        [self.m_ZSButton setBackgroundImage:[self.m_ZSButton backgroundImageForState:UIControlStateSelected] forState:0];
    }
}

-(IBAction)ZSButton:(id)sender
{
    if (self.m_TextView.hidden)
    {
         self.m_TableView.hidden = YES;
        self.m_CustomCurveView.hidden = YES;
        self.m_TextView.hidden = NO;
        
        [self.m_JXHYBButton setBackgroundImage:[self.m_JXHYBButton backgroundImageForState:UIControlStateSelected] forState:0];
        [self.m_QSButton setBackgroundImage:[self.m_QSButton backgroundImageForState:UIControlStateSelected] forState:0];
        [self.m_ZSButton setBackgroundImage:[self.m_ZSButton backgroundImageForState:UIControlStateHighlighted] forState:0];
    }
}


#pragma mark
#pragma mark UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (self.m_TableViewArray)
    {
        return self.m_TableViewArray.count;
    }
    return 0;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    //预报数据
    static NSString *identifier = @"identifiers";

    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell == nil)
    {
        CGFloat tempViewHight = 30.0;
        CGFloat cellHight = 37.0;

        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
        cell.backgroundColor = [UIColor clearColor];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;

        CGRect cellRect = cell.frame;
        cellRect.size.height =cellHight;
        cell.frame = cellRect;

        UIView *views = [[UIView alloc] initWithFrame:CGRectMake(0, cellHight/2.0-tempViewHight/2.0, CGRectGetWidth(tableView.frame), tempViewHight)];
        views.backgroundColor = [UIColor clearColor];
        [cell addSubview:views];

        //时间
        UILabel *weekLabel = [[UILabel alloc] initWithFrame:CGRectMake(20, 0, 90, CGRectGetHeight(views.frame))];
        weekLabel.tag = 0x333;
        weekLabel.textAlignment = NSTextAlignmentLeft;
        weekLabel.backgroundColor = [UIColor clearColor];
        weekLabel.font = [UIFont systemFontOfSize:12];
        weekLabel.textColor = [UIColor whiteColor];
        [views addSubview:weekLabel];
        //天气文本
        UILabel *weatherTextLabel = [[UILabel alloc] initWithFrame:CGRectMake(110, 0, 60, CGRectGetHeight(views.frame))];
        weatherTextLabel.tag = 0x444;
        weatherTextLabel.textAlignment = NSTextAlignmentRight;
        weatherTextLabel.backgroundColor = [UIColor clearColor];
        weatherTextLabel.font = [UIFont systemFontOfSize:12];
        weatherTextLabel.textColor = [UIColor whiteColor];
        [views addSubview:weatherTextLabel];
        //天气图标
        UIImageView *iconImageView = [[UIImageView alloc] initWithFrame:CGRectMake(170, 0, CGRectGetHeight(views.frame), CGRectGetHeight(views.frame))];
        iconImageView.tag = 0x555;
        iconImageView.contentMode = UIViewContentModeScaleAspectFit;
        iconImageView.backgroundColor = [UIColor clearColor];
        [views addSubview:iconImageView];
        //温度
        UILabel *highLabel = [[UILabel alloc] initWithFrame:CGRectMake(CGRectGetWidth(views.frame)-40-19, 0, 40, CGRectGetHeight(views.frame))];
        highLabel.tag = 0x666;
        highLabel.textAlignment = NSTextAlignmentRight;
        highLabel.backgroundColor = [UIColor clearColor];
        highLabel.font = [UIFont systemFontOfSize:12];
        highLabel.textColor = [UIColor whiteColor];
        [views addSubview:highLabel];
    }

    UILabel     *weekLabel          = (UILabel*)[cell viewWithTag:0x333];
    UILabel     *weatherTextLabel   = (UILabel*)[cell viewWithTag:0x444];
    UIImageView *iconImageView      = (UIImageView*)[cell viewWithTag:0x555];
    UILabel     *highLabel          = (UILabel*)[cell viewWithTag:0x666];
    weekLabel.text= @"";
    weatherTextLabel.text= @"";
    iconImageView.image = nil;
    highLabel.text= @"";

    NSDictionary *dic = [self.m_TableViewArray objectAtIndex:indexPath.row];
    if (dic)
    {
        //时间
        if ([dic valueForKey:K_start] && [[dic valueForKey:K_start] isKindOfClass:[NSString class]])
        {
            NSMutableString *tempString = [[NSMutableString alloc] init];
            if (indexPath.row == 0)
            {
                [tempString appendFormat:@"%@",[Tools dateFormatTimeString:@"dd日HH时" setString:[dic valueForKey:K_start]]];
            }
            else
            {
                [tempString appendFormat:@"%@",[Tools dateFormatTimeString:@"HH时" setString:[dic valueForKey:K_start]]];
            }
            
            if ([dic valueForKey:K_end] && [[dic valueForKey:K_end] isKindOfClass:[NSString class]])
            {
                [tempString appendFormat:@"-%@",[Tools dateFormatTimeString:@"HH时" setString:[dic valueForKey:K_end]]];
            }
            weekLabel.text = tempString;
        }
        //天气文本
        if ([dic valueForKey:K_oneCode_cn])
        {
            weatherTextLabel.text = [NSString stringWithFormat:@"%@",[dic valueForKey:K_oneCode_cn]];
        }
        //图标
        if ([dic valueForKey:K_oneCode])
        {
            iconImageView.image = [Tools getDayWeatherImage:[dic valueForKey:K_oneCode]];
        }
        //温度
        if ([dic valueForKey:K_high])
        {
            highLabel.text = [NSString stringWithFormat:@"%@°",[dic valueForKey:K_high]];
        }
    }
    return  cell;
}

#pragma mark
#pragma mark UITableViewDelegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 37.0;
}

#pragma mark -
#pragma mark ASIFormDataRequest 回调函数

-( void )responseComplete:(ASIFormDataRequest*)request
{
    NSDictionary *dic = [[request responseString] JSONValue];
    if(dic)
    {
        if ([dic valueForKey:K_cityInfo])
        {
            NSDictionary *cityInfoDic   = [dic valueForKey:K_cityInfo];
            
            DB_CityInfo *dateBCityInfo  = [[DB_CityInfo alloc] init];
            dateBCityInfo.db_cityId     = [cityInfoDic valueForKey:K_cityId];
            dateBCityInfo.db_cityName   = [cityInfoDic valueForKey:K_cityName];
            dateBCityInfo.db_latitude   = [cityInfoDic valueForKey:K_latitude];
            dateBCityInfo.db_longitude  = [cityInfoDic valueForKey:K_longitude];
            dateBCityInfo.db_content    = [dic JSONRepresentation];
            dateBCityInfo.db_version    = [dic valueForKey:K_version];
            dateBCityInfo.db_updateTimer = [dic valueForKey:K_time];
            
            DBMSEngine *engine = [[DBMSEngine alloc] init];
            
            [engine updateCityWeather:dateBCityInfo];
            self.m_CityInfo = [engine querryCityWeather:[cityInfoDic valueForKey:K_cityId]];
            
            [self clearnInterface];
            [self refushInterface];
        }
	}
}

-( void )responseFailed:(ASIFormDataRequest*)request
{
}

#pragma mark -
#pragma mark ASIFormDataRequest-背景图下载

-( void )responseComplete_image:(ASIFormDataRequest*)request
{
    NSData *imageData = [request responseData];
    UIImage *image = [UIImage imageWithData:imageData];
    if (image)
    {
        [Tools saveDocumentsImagData:imageData setFileName:request.username];
        self.m_backGroundImageView.image = image;
    }
}

@end
