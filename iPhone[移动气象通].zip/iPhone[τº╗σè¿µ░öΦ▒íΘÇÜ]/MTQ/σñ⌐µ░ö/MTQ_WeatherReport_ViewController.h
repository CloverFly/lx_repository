//
//  MTQ_WeatherReport_ViewController.h
//  MTQ
//  天气预报
//  Created by lesogo on 13-12-3.
//  Copyright (c) 2013年 Lesogo. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "WeatherReport_CustomView.h"


@interface MTQ_WeatherReport_ViewController : UIViewController
<UIScrollViewDelegate>
{
    NSMutableArray  *m_dataArray;
    int             _index;
}

@property(nonatomic,strong) IBOutlet UIScrollView   *m_ScrollView;

-(void)loadInterface;//界面加载


@end
