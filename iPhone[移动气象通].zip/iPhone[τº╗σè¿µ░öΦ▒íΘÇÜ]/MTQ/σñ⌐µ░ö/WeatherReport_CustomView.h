//
//  WeatherReport_CustomView.h
//  MTQ
//  天气预报-自定义view
//  Created by lesogo on 13-12-4.
//  Copyright (c) 2013年 Lesogo. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ASIFormDataRequest.h"
#import "DBMSEngine.h"
#import "MJRefresh.h"

@interface WeatherReport_CustomView : UIView
<MJRefreshBaseViewDelegate,UITableViewDataSource,
UITableViewDelegate>
{
    DB_CityInfo *m_CityInfo;
    MJRefreshHeaderView *_header;
    ASIFormDataRequest  *m_httpFormDataRequest;
    ASIFormDataRequest  *m_httpFormDataRequest_image;
    BOOL        isSHow_report;
}

@property(nonatomic,strong) DB_CityInfo *m_CityInfo;
@property(nonatomic,strong) UINavigationController *m_navigation;

@property(nonatomic,strong) IBOutlet UIScrollView *m_RefushScrollView;//更新滑动界面

@property(nonatomic,strong) IBOutlet UILabel        *m_CityNameLabel;
@property(nonatomic,strong) IBOutlet UIImageView    *m_LocationImageView;
@property(nonatomic,strong) IBOutlet UIImageView    *m_backGroundImageView;
@property(nonatomic,strong) IBOutlet UIButton       *m_CityManageButton;
@property(nonatomic,strong) IBOutlet UIPageControl  *m_PageControl;

@property(nonatomic,strong) IBOutlet UILabel        *m_SKTemperatureLabel;
@property(nonatomic,strong) IBOutlet UILabel        *m_SKWeatherTextLabel;
@property(nonatomic,strong) IBOutlet UIImageView    *m_SKWeatherImageView;

@property(nonatomic,strong) IBOutlet UILabel        *m_SKInfoLabel;
@property(nonatomic,strong) IBOutlet UILabel        *m_DateLabel;

@property(nonatomic,strong) IBOutlet UILabel        *m_AQILabel;

@property(nonatomic,strong) IBOutlet UIView         *m_WarningView;
@property(nonatomic,strong) NSMutableDictionary     *m_WarinDictionary;//预警数据

@property(nonatomic,strong) IBOutlet UILabel        *m_UpdateTimeLabel;

@property(nonatomic,strong) IBOutlet UIView         *m_SwipeGestureRecognizerView;
@property(nonatomic,strong) IBOutlet UIView         *m_ReportView;
@property(nonatomic,strong) IBOutlet UIButton       *m_ReportButton;
@property(nonatomic,strong) IBOutlet UITableView    *m_TableView;
@property(nonatomic,strong) NSMutableArray          *m_TableViewArray;

//界面数据处理
-(void)clearnInterface;//清空界面
-(void)refushInterface;//刷新界面

-(void)cancelUpdateRequest;//取消更新请求
-(void)updateInterface:(BOOL)isCanUpdate;//更新数据

-(IBAction)cityManagerBtPressed:(UIButton*)sender;//城市管理按钮
-(IBAction)mapBtPressed:(UIButton*)sender;//地图按钮
-(IBAction)warningBtPressed:(UIButton*)sender;//预警按钮
-(IBAction)reportBtPressed:(UIButton*)sender;//预报展示按钮


@end
