//
//  WeatherReport_CustomView.m
//  MTQ
//  天气预报-自定义view
//  Created by lesogo on 13-12-4.
//  Copyright (c) 2013年 Lesogo. All rights reserved.
//

#import <Accelerate/Accelerate.h>

#import "UIImageView+WebCache.h"
#import "WeatherReport_CustomView.h"

#import "QS_CustomCurveView.h"
#import "DKLiveBlurView.h"

#import "MTQ_CityManager_ViewController.h"
#import "MTQ_LiveMonitoring_ViewController.h"
#import "MTQ_Voide_ViewController.h"
#import "MTQ_WebView_ViewController.h"
#import "Report_MapShow_ViewController.h"
#import "TestMap_ViewController.h"

@implementation WeatherReport_CustomView

@synthesize m_CityInfo;
@synthesize m_navigation;

-(id)init
{
    //self = [super init];
    if (iPhone5)
    {
        NSArray *arrays = [[NSBundle mainBundle] loadNibNamed:@"WeatherReport_CustomView_ip5" owner:self options:nil];
        self = (WeatherReport_CustomView*)[arrays objectAtIndex:0];
    }
    else
    {
        NSArray *arrays = [[NSBundle mainBundle] loadNibNamed:@"WeatherReport_CustomView" owner:self options:nil];
        self = (WeatherReport_CustomView*)[arrays objectAtIndex:0];
    }
    
    self.m_RefushScrollView.contentSize = CGSizeMake(CGRectGetWidth(self.m_RefushScrollView.frame), CGRectGetHeight(self.m_RefushScrollView.frame)+0.5);
    
    // 下拉刷新
    _header = [[MJRefreshHeaderView alloc] init];
    _header.delegate = self;
    _header.scrollView = self.m_RefushScrollView;
    
    //上
    UISwipeGestureRecognizer *swipeGestureRecognizer_Up = [[UISwipeGestureRecognizer alloc] init];
    [swipeGestureRecognizer_Up addTarget:self action:@selector(gestureRecognizerHandle_Up:)];
    [swipeGestureRecognizer_Up setNumberOfTouchesRequired:1];
    [swipeGestureRecognizer_Up setDirection:UISwipeGestureRecognizerDirectionUp];
    [self.m_SwipeGestureRecognizerView addGestureRecognizer:swipeGestureRecognizer_Up];
    
    //下
    UISwipeGestureRecognizer *swipeGestureRecognizer_Down = [[UISwipeGestureRecognizer alloc] init];
    [swipeGestureRecognizer_Down addTarget:self action:@selector(gestureRecognizerHandle_Down:)];
    [swipeGestureRecognizer_Down setNumberOfTouchesRequired:1];
    [swipeGestureRecognizer_Down setDirection:UISwipeGestureRecognizerDirectionDown];
    [self.m_SwipeGestureRecognizerView addGestureRecognizer:swipeGestureRecognizer_Down];
    
    isSHow_report =YES;
    [self gestureRecognizerHandle_Down:nil];
    
    return self;
}

-(IBAction)cityManagerBtPressed:(UIButton*)sender
{
    MTQ_CityManager_ViewController *viewCtr = [[MTQ_CityManager_ViewController alloc] init];
    [self.m_navigation pushViewController:viewCtr animated:YES];
}

-(IBAction)mapBtPressed:(UIButton*)sender//地图按钮
{
    if ([Tools isCustomized])
    {
        Report_MapShow_ViewController *viewCtr = [[Report_MapShow_ViewController alloc] init];
        [self.m_navigation pushViewController:viewCtr animated:YES];
    }
    else
    {
        AppDelegate.window.userInteractionEnabled = NO;
        [AppDelegate DeviceRegister:nil :NO];
    }
}

//预警按钮
-(IBAction)warningBtPressed:(UIButton*)sender
{
    NSString *keyString = [NSString stringWithFormat:@"%d",sender.tag];
    NSDictionary *dic =[self.m_WarinDictionary valueForKey:keyString];
    if (self.m_WarinDictionary && keyString && dic)
    {
        MTQ_WebView_ViewController *viewCtr = [[MTQ_WebView_ViewController alloc] init];
        viewCtr.m_dataDictionary = dic;
        [self.m_navigation pushViewController:viewCtr animated:YES];
    }
}

-(IBAction)reportBtPressed:(UIButton*)sender
{
    if (isSHow_report)
    {
        [self gestureRecognizerHandle_Down:nil];
    }
    else
    {
        [self gestureRecognizerHandle_Up:nil];
    }
}

-(void)clearnInterface
{
    self.m_SKTemperatureLabel.text = @"";
    self.m_SKWeatherTextLabel.text = @"";
    self.m_SKWeatherImageView.image = [UIImage imageNamed:@""];
    self.m_SKInfoLabel.text = @"";
    self.m_AQILabel.text = @"";
    self.m_DateLabel.text = @"";
    self.m_backGroundImageView.image = [UIImage imageNamed:@"bg_1.jpg"];
    
    self.m_WarinDictionary = nil;
    self.m_WarningView.hidden = YES;
    ((UIButton*)[self.m_WarningView viewWithTag:500]).hidden = YES;
    ((UIButton*)[self.m_WarningView viewWithTag:501]).hidden = YES;
    ((UIButton*)[self.m_WarningView viewWithTag:502]).hidden = YES;
    ((UIButton*)[self.m_WarningView viewWithTag:503]).hidden = YES;
    
    self.m_UpdateTimeLabel.text= @"";
    
    
    self.m_ReportView.hidden = YES;
    self.m_SwipeGestureRecognizerView.hidden = YES;
    self.m_TableViewArray = nil;
    [self.m_TableView reloadData];
    isSHow_report =YES;
    [self gestureRecognizerHandle_Down:nil];
}

-(void)refushInterface
{
    [self clearnInterface];
    
    //名称
    [self cityNameChange];
    
    if (self.m_CityInfo && self.m_CityInfo.db_cityId)
    {
        NSDictionary *dic = [Tools JsonParser:self.m_CityInfo.db_content];
        if (dic)
        {
            //实况
            NSDictionary *skDic = [dic valueForKey:K_sk];
            if (skDic)
            {
                //实况温度处理
                if ([skDic valueForKey:K_temp])
                {
                    self.m_SKTemperatureLabel.text = [NSString stringWithFormat:@"%@°",[skDic valueForKey:K_temp]];
                }
                if ([skDic valueForKey:K_weather_cn])
                {
                    self.m_SKWeatherTextLabel.text = [NSString stringWithFormat:@"%@",[skDic valueForKey:K_weather_cn]];
                }
                if ([skDic valueForKey:K_weather])
                {
                    self.m_SKWeatherImageView.image = [Tools getDayWeatherImage:[skDic valueForKey:K_weather]];
                }
                //风 、湿度
                NSMutableString *skInfoString = [[NSMutableString alloc] init];
                if ([skDic valueForKey:K_windDirect])
                {
                    [skInfoString appendFormat:@"%@",[skDic valueForKey:K_windDirect]];
                }
                if ([skDic valueForKey:K_wind_level])
                {
                    [skInfoString appendFormat:@"%@级",[skDic valueForKey:K_wind_level]];
                }
                if ([skDic valueForKey:K_humidity])
                {
                    [skInfoString appendFormat:@"  湿度%@%%",[skDic valueForKey:K_humidity]];
                }
                self.m_SKInfoLabel.text = skInfoString;
                
                //日期
                NSMutableString *dateString = [[NSMutableString alloc] init];
                
                //发布时间
                if ([skDic valueForKey:K_time] && [[skDic valueForKey:K_time] isKindOfClass:[NSString class]] && [[skDic valueForKey:K_time] length] == 14)
                {
                    NSMutableString *timerString = [[NSMutableString alloc] init];
                    [timerString appendFormat:@"%@:",[[skDic valueForKey:K_time] substringWithRange:NSMakeRange(8, 2)]];
                    [timerString appendFormat:@"%@ 更新",[[skDic valueForKey:K_time] substringWithRange:NSMakeRange(10, 2)]];
                    self.m_UpdateTimeLabel.text = timerString;
                    
                    [dateString appendFormat:@"%@/",[[skDic valueForKey:K_time] substringWithRange:NSMakeRange(4, 2)]];
                    [dateString appendFormat:@"%@",[[skDic valueForKey:K_time] substringWithRange:NSMakeRange(6, 2)]];
                }
                
                if ([skDic valueForKey:K_lunar])
                {
                    [dateString appendFormat:@"  %@",[skDic valueForKey:K_lunar]];
                }
                self.m_DateLabel.text = dateString;
            }
            //空气质量
            NSArray *airArray = [dic valueForKey:K_air];
            if (airArray && airArray.count)
            {
                NSDictionary *airDicitionary =[airArray objectAtIndex:0];
                NSDictionary *aqiDictionary =[airDicitionary objectForKey:K_aqi];
                if (aqiDictionary)
                {
                    self.m_AQILabel.text = [NSString stringWithFormat:@"空气质量 %@ %@",[aqiDictionary valueForKey:K_aqi],[self itemLevelArr:[aqiDictionary objectForKey:K_aqi_level]]];
                }
            }
            
            //预警
            NSDictionary *warnDic = [dic valueForKey:K_zh];
            NSArray      *warnArray = [warnDic valueForKey:K_warns];
            self.m_WarinDictionary = nil;
            self.m_WarinDictionary = [[NSMutableDictionary alloc] init];
            int  buttonIndex = 500;
            for (NSDictionary *nextWarnDic in warnArray)
            {
                if (nextWarnDic && buttonIndex<504)
                {
                    if ([nextWarnDic valueForKey:K_warnId])
                    {
                        UIButton *buttons = (UIButton*)[self.m_WarningView viewWithTag:buttonIndex];
                        buttons.hidden = NO;
                        self.m_WarningView.hidden = NO;
                        [self.m_WarinDictionary setObject:nextWarnDic forKey:[NSString stringWithFormat:@"%d",buttonIndex]];
                        
                        UIImage *images = [UIImage imageNamed:[Tools getWarningNamePath:[nextWarnDic valueForKey:K_warnId]]];
                        [buttons setBackgroundImage:images forState:0];
                        
                        buttonIndex++;
                    }
                }
            }
            //短临预报
            if (buttonIndex<504)
            {
                NSArray      *DLArray = [warnDic valueForKey:K_impendings];
                for (NSDictionary *nextWarnDic in DLArray)
                {
                    if (nextWarnDic && buttonIndex<504)
                    {
                        if ([nextWarnDic valueForKey:K_type])
                        {
                            UIButton *buttons = (UIButton*)[self.m_WarningView viewWithTag:buttonIndex];
                            buttons.hidden = NO;
                            self.m_WarningView.hidden = NO;
                            [self.m_WarinDictionary setObject:nextWarnDic forKey:[NSString stringWithFormat:@"%d",buttonIndex]];
                            
                            UIImage *images = [UIImage imageNamed:@"dl_red_2.png"];
                            [buttons setBackgroundImage:images forState:0];
                            
                            buttonIndex++;
                        }
                    }
                }
            }
            //预警信息
            if (buttonIndex<504)
            {
                NSArray      *wInfoArray = [warnDic valueForKey:@""];
                for (NSDictionary *nextWarnDic in wInfoArray)
                {
                    if (nextWarnDic && buttonIndex<504)
                    {
                        if ([nextWarnDic valueForKey:K_type])
                        {
                            UIButton *buttons = (UIButton*)[self.m_WarningView viewWithTag:buttonIndex];
                            buttons.hidden = NO;
                            self.m_WarningView.hidden = NO;
                            [self.m_WarinDictionary setObject:nextWarnDic forKey:[NSString stringWithFormat:@"%d",buttonIndex]];
                            
                            UIImage *images = [UIImage imageNamed:@"warningInfo.png"];
                            [buttons setBackgroundImage:images forState:0];
                            
                            buttonIndex++;
                        }
                    }
                }
            }
            
            //预报
            self.m_TableViewArray = nil;
            self.m_TableViewArray = [[NSMutableArray alloc] init];
            NSDictionary *ybDict = [dic valueForKey:K_yb];
            NSArray *ybArray = [ybDict valueForKey:K_datas];
            for (NSDictionary *nextybDic in ybArray)
            {
                if (nextybDic)
                {
                    [self.m_TableViewArray addObject:nextybDic];
                }
            }
            [self.m_TableView reloadData];
            
            [self AdjustSKInfo];
            [self AdjustWarnAndUpdate];
        }
    }
}

-(NSString*)itemLevelArr:(NSString*)aLevelString
{
    if (aLevelString && [aLevelString isKindOfClass:[NSString class]])
    {
        NSArray*itemNameArr = [[NSArray alloc] initWithObjects:@"优",@"良",@"轻度污染",
                               @"中度污染",@"重度污染",@"严重污染",nil];
        int index = [aLevelString integerValue]-1;
        if (index<itemNameArr.count)
        {
            return [itemNameArr objectAtIndex:index];
        }
    }
    return @"";
}

-(void)cancelUpdateRequest//取消更新请求
{
    if (m_httpFormDataRequest)
    {
        [m_httpFormDataRequest clearDelegatesAndCancel];
    }
    if (m_httpFormDataRequest_image)
    {
        [m_httpFormDataRequest_image clearDelegatesAndCancel];
    }
    [self cancelRefreshing];
}

-(void)updateInterface:(BOOL)isCanUpdate//更新数据
{
    
    if (self.m_CityInfo && self.m_CityInfo.db_cityId && [self.m_CityInfo.db_cityId isKindOfClass:[NSString class]])
    {
        if (isCanUpdate || [Tools isCanUpdate:self.m_CityInfo.db_cityId])
        {
            if (m_httpFormDataRequest)
            {
                [m_httpFormDataRequest clearDelegatesAndCancel];
            }
            
            NSString *tempStrings = [URL get_WeatherDataUrl];
            m_httpFormDataRequest = [ ASIFormDataRequest requestWithURL:[NSURL URLWithString:tempStrings]];
            [m_httpFormDataRequest setStringEncoding :NSUTF8StringEncoding];//设置数据类型为utf-8
            [m_httpFormDataRequest setPostValue:self.m_CityInfo.db_cityId forKey:K_cityId];
            [m_httpFormDataRequest setPostValue:@"true," forKey:K_cityInfo];
            [m_httpFormDataRequest setPostValue:@"true," forKey:K_sk];
            [m_httpFormDataRequest setPostValue:@"true," forKey:K_sk_zd];
            [m_httpFormDataRequest setPostValue:@"true," forKey:K_yb];
            [m_httpFormDataRequest setPostValue:@"true," forKey:K_jxhyb];
            [m_httpFormDataRequest setPostValue:@"true," forKey:K_zh];
            [m_httpFormDataRequest setPostValue:@"true," forKey:K_lifeIndex];
            [m_httpFormDataRequest setPostValue:@"true," forKey:K_fest];
            [m_httpFormDataRequest setPostValue:@"true," forKey:K_air];
            [m_httpFormDataRequest setPostValue:@"true," forKey:K_updown];
            [m_httpFormDataRequest setPostValue:self.m_CityInfo.db_latitude forKey:K_latitude];
            [m_httpFormDataRequest setPostValue:self.m_CityInfo.db_longitude forKey:K_latitude];
            [m_httpFormDataRequest setPostValue:iPhone5?@"40x71":@"2x3" forKey:K_scale];
            [m_httpFormDataRequest setPostValue:[Tools getTokenString] forKey:K_token];
            [m_httpFormDataRequest setDelegate:self];
            [m_httpFormDataRequest setDidFinishSelector : @selector (responseComplete:)];
            [m_httpFormDataRequest setDidFailSelector : @selector (responseFailed:)];
            [m_httpFormDataRequest startAsynchronous];
            return;
        }
    }
    
    [self cancelRefreshing];
}

-(void)downLoadImage:(NSString*)aUrl
{
    if (aUrl && [aUrl isKindOfClass:[NSString class]] && [aUrl length]>10)
    {
        NSString *imageSavePath = [Tools readDocumentsImageSavePath:aUrl];
        if ([Tools isFileExitPath:imageSavePath])
        {
            UIImage *imagedata = [UIImage imageWithContentsOfFile:imageSavePath];
            if (imagedata)
            {
                self.m_backGroundImageView.image = imagedata;
            }
        }
        else
        {
            if (m_httpFormDataRequest_image)
            {
                [m_httpFormDataRequest_image clearDelegatesAndCancel];
            }
            NSURL *urlss = [NSURL URLWithString:aUrl];
            m_httpFormDataRequest_image = [ ASIFormDataRequest requestWithURL:urlss];
            [m_httpFormDataRequest_image setStringEncoding :NSUTF8StringEncoding];//设置数据类型为utf-8
            m_httpFormDataRequest_image.username = aUrl;
            [m_httpFormDataRequest_image setDelegate:self];
            [m_httpFormDataRequest_image setDidFinishSelector : @selector(responseComplete_image:)];
            [m_httpFormDataRequest_image setDidFailSelector : nil];
            [m_httpFormDataRequest_image startAsynchronous];
        }
    }
}

-(void)cancelRefreshing
{
    if (_header)
    {
        [_header performSelector:@selector(endRefreshing) withObject:nil afterDelay:0.2f];
    }
}

-(void)cityNameChange
{
    if (m_CityInfo)
    {
        NSDictionary *dic = [Tools JsonParser:self.m_CityInfo.db_content];
        if (dic)
        {
            //背景
            NSDictionary *skDic = [dic valueForKey:K_sk];
            if (skDic && [skDic valueForKey:K_url])
            {
                [self downLoadImage:[skDic valueForKey:K_url]];
            }
        }
        
        //名称处理
        self.m_LocationImageView.hidden = YES;
        if (m_CityInfo.db_islocation && [m_CityInfo.db_islocation intValue]==1)
        {
            self.m_LocationImageView.hidden = NO;
        }
        if (m_CityInfo.db_cityName)
        {
            self.m_CityNameLabel.text = [NSString stringWithFormat:@"%@",m_CityInfo.db_cityName];
        }
        
        CGFloat leftButtonW = CGRectGetMaxX(self.m_CityManageButton.frame);//左按钮的最大x点
        CGFloat locationImageW = CGRectGetWidth(self.m_LocationImageView.frame);//定位标示图片的宽度
        CGFloat distance = 5;//间隙
        CGFloat nameW = [self.m_CityNameLabel.text sizeWithFont:self.m_CityNameLabel.font].width;//城市名的宽度
        
        CGFloat currentX =CGRectGetWidth(self.frame)/2.0-(nameW+distance+!self.m_LocationImageView.hidden*locationImageW)/2.0;
        if (currentX>=leftButtonW)
        {
            CGRect rct = self.m_CityNameLabel.frame;
            rct.origin.x = currentX;
            rct.size.width = nameW;
            self.m_CityNameLabel.frame = rct;
            
            rct = self.m_LocationImageView.frame;
            rct.origin.x = CGRectGetMaxX(self.m_CityNameLabel.frame)+distance;
            self.m_LocationImageView.frame = rct;
        }
        else
        {
            if ((nameW+distance+!self.m_LocationImageView.hidden*locationImageW+leftButtonW)<=CGRectGetWidth(self.frame))
            {
                CGRect rct = self.m_CityNameLabel.frame;
                rct.origin.x = leftButtonW;
                rct.size.width = nameW;
                self.m_CityNameLabel.frame = rct;
                
                rct = self.m_LocationImageView.frame;
                rct.origin.x = CGRectGetMaxX(self.m_CityNameLabel.frame)+distance;
                self.m_LocationImageView.frame = rct;
            }
            else
            {
                CGRect rct = self.m_CityNameLabel.frame;
                rct.origin.x = leftButtonW;
                rct.size.width = CGRectGetWidth(self.frame)-leftButtonW-!self.m_LocationImageView.hidden*locationImageW;
                self.m_CityNameLabel.frame = rct;
                
                rct = self.m_LocationImageView.frame;
                rct.origin.x = CGRectGetMaxX(self.m_CityNameLabel.frame)+distance;
                self.m_LocationImageView.frame = rct;
            }
        }
    }
}

//调整实况信息位置
-(void)AdjustSKInfo
{
    CGFloat tempW        = [self.m_SKTemperatureLabel.text sizeWithFont:self.m_SKTemperatureLabel.font].width;
    CGFloat weatherTextW = [self.m_SKWeatherTextLabel.text sizeWithFont:self.m_SKWeatherTextLabel.font].width;
    
    CGRect rct = self.m_SKTemperatureLabel.frame;
    rct.size.width = tempW;
    self.m_SKTemperatureLabel.frame = rct;
    
    rct = self.m_SKWeatherTextLabel.frame;
    rct.origin.x = CGRectGetMaxX(self.m_SKTemperatureLabel.frame);
    rct.size.width = weatherTextW;
    self.m_SKWeatherTextLabel.frame = rct;
    
    rct = self.m_SKWeatherImageView.frame;
    rct.origin.x = CGRectGetMaxX(self.m_SKWeatherTextLabel.frame);
    self.m_SKWeatherImageView.frame = rct;
}

//调整预警和时间的位置
-(void)AdjustWarnAndUpdate
{
    CGRect rct = self.m_UpdateTimeLabel.frame;
    rct.origin.y = self.m_WarningView.hidden?(CGRectGetMinY(self.m_WarningView.frame)):(CGRectGetMaxY(self.m_WarningView.frame));
    self.m_UpdateTimeLabel.frame = rct;
}


-(void)gestureRecognizerHandle_Up:(UISwipeGestureRecognizer*) aSwipeGestureRecognizer
{
    if (!isSHow_report && self.m_TableViewArray && self.m_TableViewArray.count>2)
    {
        CGFloat defulatY = iPhone5?282.0:197.0;
        //上
        CGRect rct = self.m_ReportView.frame;
        rct.size.height = CGRectGetHeight(self.m_TableView.frame)+CGRectGetHeight(self.m_ReportButton.frame);
        rct.origin.y = defulatY;
        
        [UIView animateWithDuration:.3 animations:^
         {
             self.m_ReportView.frame = rct;
             
         } completion:^(BOOL finished)
         {
         }];
        
        isSHow_report = YES;
        [self.m_ReportButton setBackgroundImage:[self.m_ReportButton backgroundImageForState:UIControlStateSelected] forState:0];
    }
}

-(void)gestureRecognizerHandle_Down:(UISwipeGestureRecognizer*) aSwipeGestureRecognizer
{
    if (isSHow_report)
    {
        //下
        CGFloat defulatY = (iPhone5?282.0:197.0)+CGRectGetHeight(self.m_TableView.frame)*2/5.0;
        CGRect rct = self.m_ReportView.frame;
        rct.size.height = CGRectGetHeight(self.m_TableView.frame)*2/5.0+CGRectGetHeight(self.m_ReportButton.frame);
        rct.origin.y = defulatY;
        
        [UIView animateWithDuration:.3 animations:^
         {
             self.m_ReportView.frame = rct;
             
         } completion:^(BOOL finished)
         {
         }];
        
        isSHow_report = NO;
        [self.m_ReportButton setBackgroundImage:[self.m_ReportButton backgroundImageForState:UIControlStateHighlighted] forState:0];
    }
}

#pragma mark --
#pragma mark UIScrollViewDelegate

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
}


#pragma mark
#pragma mark MJRefreshBaseViewDelegate

- (void)refreshViewBeginRefreshing:(MJRefreshBaseView *)refreshView
{
    if (_header && _header == refreshView)
    {
        [self updateInterface:YES];
    }
}

#pragma mark
#pragma mark UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (self.m_TableViewArray && self.m_TableViewArray.count)
    {
        self.m_ReportView.hidden = NO;
        self.m_SwipeGestureRecognizerView.hidden = NO;
        return self.m_TableViewArray.count;
    }
    self.m_ReportView.hidden = YES;
    self.m_SwipeGestureRecognizerView.hidden = YES;
    
    return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    //预报数据
    static NSString *identifier = @"identifiers";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
        cell.backgroundColor = [UIColor clearColor];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        
        CGFloat distance  = 2.0;
        CGFloat tempViewHight = CGRectGetHeight(tableView.frame)/5.0-distance;
        CGFloat cellHight = CGRectGetHeight(tableView.frame)/5.0;
        
        CGRect cellRect = cell.frame;
        cellRect.size.height = cellHight;
        cell.frame = cellRect;
        
        //背景
        UIView *views = [[UIView alloc] initWithFrame:CGRectMake(0, distance, CGRectGetWidth(tableView.frame), tempViewHight)];
        views.backgroundColor = [UIColor clearColor];
        [cell addSubview:views];
        
        //蒙层
        UIView *tempviews = [[UIView alloc] initWithFrame:CGRectMake(0.0, 0.0, CGRectGetWidth(views.frame), CGRectGetHeight(views.frame))];
        tempviews.backgroundColor = [UIColor blackColor];
        tempviews.alpha = 0.5;
        tempviews.layer.cornerRadius = 5.0;
        [views addSubview:tempviews];
        
        //天气图标
        UIImageView *iconImageView = [[UIImageView alloc] initWithFrame:CGRectMake(0.0, 0, CGRectGetWidth(views.frame)*2/3.0, CGRectGetHeight(views.frame))];
        iconImageView.tag = 0x333;
        iconImageView.contentMode = UIViewContentModeScaleAspectFit;
        iconImageView.backgroundColor = [UIColor clearColor];
        [views addSubview:iconImageView];
        
        CGFloat labelH = 15.0;
        CGFloat midDistance = (CGRectGetHeight(views.frame)-2*labelH)/3.0;
        CGFloat rightDistancess= 5.0;
        //星期
        UILabel *weekLabel = [[UILabel alloc] initWithFrame:CGRectMake(0.0, midDistance,
                                                                       CGRectGetWidth(views.frame)-rightDistancess, labelH)];
        weekLabel.tag = 0x444;
        weekLabel.textAlignment = NSTextAlignmentRight;
        weekLabel.backgroundColor = [UIColor clearColor];
        weekLabel.font = [UIFont systemFontOfSize:14];
        weekLabel.textColor = [UIColor whiteColor];
        [views addSubview:weekLabel];
        
        //温度
        UILabel *tempertuareLabel       = [[UILabel alloc] initWithFrame:CGRectMake(0.0, 2*midDistance+labelH,
                                                                                    CGRectGetWidth(views.frame)-rightDistancess, labelH)];
        tempertuareLabel.tag            = 0x555;
        tempertuareLabel.textAlignment  = NSTextAlignmentRight;
        tempertuareLabel.font           = [UIFont systemFontOfSize:12];
        tempertuareLabel.textColor      = [UIColor whiteColor];
        tempertuareLabel.backgroundColor = [UIColor clearColor];
        [views addSubview:tempertuareLabel];
        
    }
    
    UIImageView *iconImageView      = (UIImageView*)[cell viewWithTag:0x333];
    UILabel     *weekLabel          = (UILabel*)[cell viewWithTag:0x444];
    UILabel     *tempertuareLabel   = (UILabel*)[cell viewWithTag:0x555];
    
    NSDictionary *dic = [self.m_TableViewArray objectAtIndex:indexPath.row];
    if (dic)
    {
        //时间
        if ([dic valueForKey:K_time])
        {
            weekLabel.text = [Tools GetWeekNameFromString:[dic valueForKey:K_time]];
            if (indexPath.section==0)
            {
                NSString *weekString1 = [Tools GetWeekNameFromString:[dic valueForKey:K_time]];
                NSString *weekString2 = [Tools GetWeekNameFromDate:[NSDate date]];
                if (weekString1 && weekString2 && [weekString1 compare:weekString2] == NSOrderedSame)
                {
                    weekLabel.text = @"今天";
                }
            }
        }
        //图标
        if ([dic valueForKey:K_twoCode])
        {
            iconImageView.image = [Tools getDayWeatherImage:[dic valueForKey:K_twoCode]];
        }
        NSMutableString *temperString = [[NSMutableString alloc] init];
        //最低
        if ([dic valueForKey:K_low])
        {
            [temperString appendString:[dic valueForKey:K_low]];
            //最高
            if ([dic valueForKey:K_high])
            {
                [temperString appendFormat:@"~%@°",[dic valueForKey:K_high]];
            }
        }
        else
        {
            //最高
            if ([dic valueForKey:K_high])
            {
                [temperString appendString:[dic valueForKey:K_high]];
            }
        }
        tempertuareLabel.text = temperString;
    }
    return  cell;
}

#pragma mark
#pragma mark UITableViewDelegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return tableView.frame.size.height/5.0;
    
    UITableViewCell *cell=[self tableView: tableView cellForRowAtIndexPath:indexPath];
    return cell.frame.size.height;
}


#pragma mark -
#pragma mark ASIFormDataRequest回调函数

-( void )responseComplete:(ASIFormDataRequest*)request
{
    NSDictionary *dic = [[request responseString] JSONValue];
    if(dic)
    {
        if ([dic valueForKey:K_cityInfo])
        {
            NSDictionary *cityInfoDic   = [dic valueForKey:K_cityInfo];
            
            DB_CityInfo *dateBCityInfo  = [[DB_CityInfo alloc] init];
            dateBCityInfo.db_cityId     = [cityInfoDic valueForKey:K_cityId];
            dateBCityInfo.db_cityName   = [cityInfoDic valueForKey:K_cityName];
            dateBCityInfo.db_latitude   = [cityInfoDic valueForKey:K_latitude];
            dateBCityInfo.db_longitude  = [cityInfoDic valueForKey:K_longitude];
            dateBCityInfo.db_content    = [dic JSONRepresentation];
            dateBCityInfo.db_version    = [dic valueForKey:K_version];
            dateBCityInfo.db_updateTimer = [dic valueForKey:K_time];
            
            DBMSEngine *engine = [[DBMSEngine alloc] init];
            
            [engine updateCityWeather:dateBCityInfo];
            self.m_CityInfo = [engine querryCityWeather:[cityInfoDic valueForKey:K_cityId]];
            
            [self clearnInterface];
            [self refushInterface];
        }
	}
    
    [self cancelRefreshing];
}

-( void )responseFailed:(ASIFormDataRequest*)request
{
    [self cancelRefreshing];
}

#pragma mark -
#pragma mark ASIFormDataRequest-背景图下载

-( void )responseComplete_image:(ASIFormDataRequest*)request
{
    NSData *imageData = [request responseData];
    UIImage *image = [UIImage imageWithData:imageData];
    if (image)
    {
        [Tools saveDocumentsImagData:imageData setFileName:request.username];
        self.m_backGroundImageView.image = image;
    }
}

@end