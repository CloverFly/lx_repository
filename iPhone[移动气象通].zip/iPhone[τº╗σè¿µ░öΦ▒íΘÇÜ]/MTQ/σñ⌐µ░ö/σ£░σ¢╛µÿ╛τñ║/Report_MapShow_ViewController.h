//
//  Report_MapShow_ViewController.h
//  MTQ
//
//  Created by lesogo on 14-2-21.
//  Copyright (c) 2014年 Lesogo. All rights reserved.
//

#import <UIKit/UIKit.h>

#import <MapKit/MapKit.h>

#import "GetOnlyLocation.h"

@class RouteAnnotation;

@interface Report_MapShow_ViewController : UIViewController
<MKMapViewDelegate,GetOnlyLocationDelegate>
{
    BOOL    isSucces;
    int     level;
    ASIFormDataRequest  *m_httpFormDataRequest;
    RouteAnnotation     *m_SelectRouteAnnotation;
}

@property(nonatomic,strong) IBOutlet MKMapView *m_googleView;

@property(nonatomic,strong) GetOnlyLocation     *m_GetLocation;
@property(nonatomic,strong) NSMutableDictionary *m_dataDictioary;
@property(nonatomic,strong) NSArray             *m_dataArray;
@property(nonatomic,strong) NSMutableArray      *m_DisPlayArray;

-(IBAction)backBtPressed:(UIButton*)sender;

-(IBAction)updateInterface;

@end
