//
//  Report_MapShow_ViewController.m
//  MTQ
//
//  Created by lesogo on 14-2-21.
//  Copyright (c) 2014年 Lesogo. All rights reserved.
//

#import "Report_MapShow_ViewController.h"

#import "SKJC_TQSKViewController.h"


@interface RouteAnnotation : NSObject<MKAnnotation>
{
	CLLocationCoordinate2D coordinate;
	NSString	*title;
	NSString	*subtitle;
    NSDictionary*routeDictionary;
}
@property (nonatomic) int     dataType;
@property (nonatomic,  copy) NSString *title;
@property (nonatomic,  copy) NSString *subtitle;
@property (nonatomic,  strong) NSDictionary*routeDictionary;
@property(nonatomic,readonly)CLLocationCoordinate2D coordinate;
-(id)initWithCoordinate:(CLLocationCoordinate2D)coords;
@end

@implementation RouteAnnotation
@synthesize coordinate;
@synthesize title;
@synthesize subtitle;
@synthesize dataType;
@synthesize routeDictionary;
-(id)initWithCoordinate:(CLLocationCoordinate2D)coords
{
	if (self = [super init])
	{
		coordinate = coords;
	}
	return self;
}
@end

@implementation Report_MapShow_ViewController

-(id)init
{
    if (iPhone5)
    {
        self = [super initWithNibName:@"Report_MapShow_ViewController_ip5" bundle:nil];
    }
    else
    {
        self = [super initWithNibName:@"Report_MapShow_ViewController" bundle:nil];
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    isSucces = NO;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    //地图配置
    CLLocationCoordinate2D coorda;
    coorda.latitude = 30.67;
    coorda.longitude = 104.02;
    MKCoordinateSpan theSpan;
    theSpan.latitudeDelta=0.03;
    theSpan.longitudeDelta=0.03;
    MKCoordinateRegion theRegion;
    theRegion.center=coorda;
    theRegion.span=theSpan;
    self.m_googleView.showsUserLocation = YES;
    [self.m_googleView setRegion:theRegion];
    
    level = 3;
    //注册长按事件
    UILongPressGestureRecognizer *lpress = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(longPress:)];
    [self.m_googleView addGestureRecognizer:lpress];
    
    self.m_dataDictioary = [[NSMutableDictionary alloc] init];
    self.m_DisPlayArray = [[NSMutableArray alloc] init];
    self.m_dataArray = [[NSArray alloc] init];
    //定位
    self.m_GetLocation = nil;
    self.m_GetLocation= [[GetOnlyLocation alloc] initWithDelegate:self];
    [self.m_GetLocation startUpdateLocation];
    
    [self updateInterface];
}

-(IBAction)backBtPressed:(UIButton*)sender
{
    if (m_httpFormDataRequest)
    {
        [m_httpFormDataRequest clearDelegatesAndCancel];
    }
    [self.navigationController popViewControllerAnimated:YES];
}


-(IBAction)updateInterface
{
    if (m_httpFormDataRequest)
    {
        [m_httpFormDataRequest clearDelegatesAndCancel];
        m_httpFormDataRequest = nil;
    }
    NSString *tempStrings = [URL get_MapStationDataUrl];
    m_httpFormDataRequest = [ ASIFormDataRequest requestWithURL:[NSURL URLWithString:tempStrings]];
    [m_httpFormDataRequest setStringEncoding :NSUTF8StringEncoding];//设置数据类型为utf-8
    [m_httpFormDataRequest setPostValue:[Tools getTokenString] forKey:K_token];
    [m_httpFormDataRequest setDelegate:self];
    [m_httpFormDataRequest setDidFinishSelector : @selector (responseComplete:)];
    [m_httpFormDataRequest setDidFailSelector : @selector (responseFailed:)];
    [m_httpFormDataRequest startAsynchronous];
}

-(void)refushInterface
{
    m_SelectRouteAnnotation = nil;
    [self.m_dataDictioary removeAllObjects];
    [self.m_googleView removeAnnotations:self.m_googleView.annotations];
    [self.m_DisPlayArray removeAllObjects];
    
    for (NSDictionary *dataDic in self.m_dataArray)
    {
        if (dataDic && [dataDic valueForKey:K_station])
        {
            int tempLevel = [[dataDic valueForKey:K_level] integerValue];
            if (tempLevel <= level)
            {
                [self.m_DisPlayArray addObject:dataDic];
            }
        }
    }
    
    [self loadGisData];
}

-(void)loadGisData
{
    if (!self.m_DisPlayArray || self.m_DisPlayArray.count==0)
    {
        return;
    }
    
    NSDictionary *dataDic = [self.m_DisPlayArray objectAtIndex:0];
    if (dataDic)
    {
        [self.m_dataDictioary setObject:dataDic forKey:[dataDic valueForKey:K_station]];
        
        CLLocationCoordinate2D coordinate2D;
        coordinate2D.latitude = [[dataDic valueForKey:K_latitude] floatValue];
        coordinate2D.longitude = [[dataDic valueForKey:K_longitude] floatValue];
        
        RouteAnnotation *roteAnnotation = [[RouteAnnotation alloc] initWithCoordinate:coordinate2D];
        roteAnnotation.dataType = 0;
        roteAnnotation.routeDictionary = dataDic;
        [self.m_googleView addAnnotation:roteAnnotation];
    }
    
    [self.m_DisPlayArray removeObjectAtIndex:0];
    
    if (self.m_DisPlayArray && self.m_DisPlayArray.count>0)
    {
        [self performSelector:@selector(loadGisData) withObject:nil afterDelay:0.01f];
    }
}

#pragma --
#pragma 长按事件

-(void)longPress:(UIGestureRecognizer*)gestureRecognizer
{
    if (gestureRecognizer.state == UIGestureRecognizerStateEnded)
    {
        return;
    }
    
    if (isSucces)
    {
        return;
    }
    isSucces = YES;
    //坐标转换
    CGPoint touchPoint = [gestureRecognizer locationInView:self.m_googleView];
    CLLocationCoordinate2D touchMapCoordinate = [self.m_googleView convertPoint:touchPoint toCoordinateFromView:self.m_googleView];
    
    NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
    [dic setObject:[NSString stringWithFormat:@"%f",touchMapCoordinate.longitude] forKey:K_longitude];
    [dic setObject:[NSString stringWithFormat:@"%f",touchMapCoordinate.latitude] forKey:K_latitude];
    
    SKJC_TQSKViewController *viewCtr = [[SKJC_TQSKViewController alloc] init];
    viewCtr.m_KeyStringDictionary = dic;
    [self.navigationController pushViewController:viewCtr animated:YES];
}


#pragma mark
#pragma mark MKMapViewDelegate

- (void)mapView:(MKMapView *)mapView regionDidChangeAnimated:(BOOL)animated
{
    MKCoordinateRegion TempRegion = mapView.region;
    MKCoordinateSpan TempSpan = TempRegion.span;
    
    if (TempSpan.longitudeDelta<=6)
    {
        if (level !=3)
        {
            level = 3;
            [self refushInterface];
        }
    }
    else if (TempSpan.longitudeDelta<=28)
    {
        if (level !=2)
        {
            level = 2;
            [self refushInterface];
        }
    }
    else
    {
        if(level !=1)
        {
            level = 1;
            [self refushInterface];
        }
    }
}

- (MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(id <MKAnnotation>)annotation
{
	//   // If it's the user location, just return nil.
    if ([annotation isKindOfClass:[MKUserLocation class]])
        return nil;
	
    static NSString *reuseIdentifier = @"RouteAnnotation";
    // Handle any custom annotations.
    if ([annotation isKindOfClass:[RouteAnnotation class]])
    {
        MKAnnotationView *AnnotationView = nil;//[mapView dequeueReusableAnnotationViewWithIdentifier:reuseIdentifier];
		if (!AnnotationView)
		{
            RouteAnnotation *testAnnotation = (RouteAnnotation*)annotation;
			AnnotationView = [[MKAnnotationView alloc] initWithAnnotation:annotation
                                                          reuseIdentifier:reuseIdentifier];
			AnnotationView.canShowCallout = NO;
			AnnotationView.enabled = YES;
            if (testAnnotation.dataType == 0)
            {
                NSString *fileName = @"mapflag.png";
                CGFloat imageWidth = 17.0;
                CGFloat imageHeight = 19.0;
                UIImageView *imageviews = [[UIImageView alloc] initWithFrame:CGRectMake(0.0, 0.0, imageWidth, imageHeight)];
                imageviews.userInteractionEnabled = YES;
                imageviews.image = [UIImage imageNamed:fileName];
                
                CGRect rct = AnnotationView.frame;
                rct.origin.x = 0.0;
                rct.origin.y = 0.0;
                rct.size = imageviews.frame.size;
                AnnotationView.frame = rct;
                AnnotationView.centerOffset = CGPointMake(rct.size.width/2.0, rct.size.height/2.0);
                
                [AnnotationView addSubview:imageviews];
            }
            else if(testAnnotation.dataType == 1)
            {
                NSString *fileName1 = @"mapflag2.png";
                NSString *fileName2 = @"mapSelected.png";
                
                CGFloat imageWidth1 = 17.0;
                CGFloat imageHeight1 = 19.0;
                
                CGFloat leftDistance = 7.0;
                CGFloat imageWidth2 = 140.0;
                CGFloat imageHeight2 = 65.0;
                
                UIView *bgViews = [[UIView alloc] initWithFrame:CGRectMake(0,0,                                                                           imageWidth1+imageWidth2, imageHeight1+imageHeight2)];
                
                UIImageView *bgImageView1 = [[UIImageView alloc] initWithFrame:CGRectMake(leftDistance, 0.0, imageWidth1, imageHeight1)];
                bgImageView1.userInteractionEnabled = YES;
                bgImageView1.image = [UIImage imageNamed:fileName1];
                [bgViews addSubview:bgImageView1];
                
                UIImageView *bgImageView2 = [[UIImageView alloc] initWithFrame:CGRectMake(0.0, imageHeight1, imageWidth2, imageHeight2)];
                bgImageView2.userInteractionEnabled = YES;
                bgImageView2.image = [UIImage imageNamed:fileName2];
                [bgViews addSubview:bgImageView2];
                
                CGFloat upDistance  = 10.0;
                CGFloat rightDistance  = 30.0;
                CGFloat labelWidth  = imageWidth2-rightDistance;
                CGFloat labelHeight = (imageHeight2-upDistance)/2.0;
                
                //右箭头
                //right-Arrow_Bule.png
                CGSize arrowSize = CGSizeMake(20, 20);
                UIImageView *rightArrow = [[UIImageView alloc] initWithFrame:CGRectMake(imageWidth2-arrowSize.width-5.0,
                                                                                        imageHeight1+imageHeight2/2.0-arrowSize.height/2.0,
                                                                                        arrowSize.width, arrowSize.height)];
                rightArrow.image = [UIImage imageNamed:@"right-Arrow_Bule.png"];
                [bgViews addSubview:rightArrow];
                
                //实况温度
                UILabel* SK_Temperature = [[UILabel alloc] initWithFrame:CGRectMake(0, imageHeight1+upDistance,
                                                                                    labelWidth, labelHeight)];
                SK_Temperature.textAlignment = UITextAlignmentCenter;
                SK_Temperature.font = [UIFont systemFontOfSize:14];
                SK_Temperature.textColor = [UIColor whiteColor];
                SK_Temperature.backgroundColor = [UIColor clearColor];
                SK_Temperature.text = @"";
                SK_Temperature.tag = 0x111;
                [bgViews addSubview:SK_Temperature];
                
                //体感温度
                UILabel* TG_Temperature = [[UILabel alloc] initWithFrame:CGRectMake(0, imageHeight1+upDistance+labelHeight,
                                                                                    labelWidth, labelHeight)];
                TG_Temperature.textAlignment = UITextAlignmentCenter;
                TG_Temperature.font = [UIFont systemFontOfSize:14];
                TG_Temperature.textColor = [UIColor whiteColor];
                TG_Temperature.backgroundColor = [UIColor clearColor];
                TG_Temperature.tag = 0x222;
                TG_Temperature.text = @"";
                [bgViews addSubview:TG_Temperature];
                
                CGRect rct = AnnotationView.frame;
                rct.origin.x = 0.0;
                rct.origin.y = 0.0;
                rct.size = bgViews.frame.size;
                AnnotationView.frame = rct;
                AnnotationView.centerOffset = CGPointMake(rct.size.width/2.0-leftDistance, rct.size.height/2.0);
                
                
                NSDictionary *dic = testAnnotation.routeDictionary;
                if (dic)
                {
                    if ([dic valueForKey:K_temp])
                    {
                        SK_Temperature.text = [NSString stringWithFormat:@"实况温度:%@°",[dic valueForKey:K_temp]];
                    }
                    if ([dic valueForKey:K_tigan])
                    {
                        TG_Temperature.text = [NSString stringWithFormat:@"体感温度:%@°",[dic valueForKey:K_tigan]];
                    }
                }
                [AnnotationView addSubview:bgViews];
            }
		}
        else
        {
            UILabel *label1 = (UILabel*)[AnnotationView viewWithTag:0x111];
            UILabel *label2 = (UILabel*)[AnnotationView viewWithTag:0x222];
            
            RouteAnnotation *testAnnotation = (RouteAnnotation*)annotation;
            NSDictionary *dic = testAnnotation.routeDictionary;
            if (dic && testAnnotation.dataType == 1)
            {
                if ([dic valueForKey:K_temp])
                {
                    label1.text = [NSString stringWithFormat:@"实况温度:%@°",[dic valueForKey:K_temp]];
                }
                if ([dic valueForKey:K_tigan])
                {
                    label2.text = [NSString stringWithFormat:@"体感温度:%@°",[dic valueForKey:K_tigan]];
                }
            }
        }
		return AnnotationView;
    }
	return nil;
}

- (void)mapView:(MKMapView *)mapView didSelectAnnotationView:(MKAnnotationView *)view
{
    
    [mapView deselectAnnotation:view.annotation animated:YES];
    
    if ([view.annotation isKindOfClass:[MKUserLocation class]])
        return;
    
    RouteAnnotation *testAnnotation = (RouteAnnotation*)view.annotation;
    if (testAnnotation.dataType == 0)
    {
        if (m_SelectRouteAnnotation)
        {
            m_SelectRouteAnnotation.dataType = 0;
            [mapView removeAnnotation:m_SelectRouteAnnotation];
            [mapView addAnnotation:m_SelectRouteAnnotation];
        }
        
        testAnnotation.dataType = 1;
        [mapView removeAnnotation:view.annotation];
        [mapView addAnnotation:testAnnotation];
        m_SelectRouteAnnotation = testAnnotation;
    }
    else if(testAnnotation.dataType == 1)
    {
        NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
        [dic setObject:[testAnnotation.routeDictionary valueForKey:K_longitude] forKey:K_longitude];
        [dic setObject:[testAnnotation.routeDictionary valueForKey:K_latitude] forKey:K_latitude];
        [dic setObject:[testAnnotation.routeDictionary valueForKey:K_station] forKey:K_stationNum];
        
        SKJC_TQSKViewController *viewCtr = [[SKJC_TQSKViewController alloc] init];
        viewCtr.m_KeyStringDictionary = dic;
        [self.navigationController pushViewController:viewCtr animated:YES];
    }
}


#pragma mark --
#pragma mark GetOnlyLocationDelegate

-(void)getOnlyLocation:(GetOnlyLocation *)aGetLocation locationInfo:(NSDictionary*)aDictionary
{
    if (aDictionary)
    {
        CLLocationCoordinate2D coorda;
        coorda.latitude = [[aDictionary valueForKey:K_latitude] floatValue];
        coorda.longitude = [[aDictionary valueForKey:K_longitude] floatValue];
        if (coorda.latitude>0 && coorda.longitude>0)
        {
            //地图配置
            MKCoordinateSpan theSpan;
            theSpan.latitudeDelta=0.03;
            theSpan.longitudeDelta=0.03;
            MKCoordinateRegion theRegion;
            theRegion.center=coorda;
            theRegion.span=theSpan;
            self.m_googleView.showsUserLocation = YES;
            [self.m_googleView setRegion:theRegion];
        }
        else
        {
            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"定位失败!"
                                                                message:nil
                                                               delegate:nil
                                                      cancelButtonTitle:nil
                                                      otherButtonTitles:@"确定", nil];
            [alertView show];
        }
    }
    else
    {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"定位失败!"
                                                            message:nil
                                                           delegate:nil
                                                  cancelButtonTitle:nil
                                                  otherButtonTitles:@"确定", nil];
        [alertView show];
    }
}

-(void)locationError
{
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"定位失败!"
                                                        message:nil
                                                       delegate:nil
                                              cancelButtonTitle:nil
                                              otherButtonTitles:@"确定", nil];
    [alertView show];
}

#pragma mark -
#pragma mark ASIFormDataRequest 回调函数

-( void )responseComplete:(ASIFormDataRequest*)request
{
    NSDictionary *dic = [[request responseString] JSONValue];
    if(dic)
    {
        NSArray *dataArray = [dic valueForKey:K_datas];
        if (dataArray && dataArray.count)
        {
            self.m_dataArray = dataArray;
        }
	}
    
    [self refushInterface];
}

-( void )responseFailed:(ASIFormDataRequest*)request
{
    //[self.m_dataDictioary removeAllObjects];
    //[self.m_googleView removeAnnotations:self.m_googleView.annotations];
}

@end
