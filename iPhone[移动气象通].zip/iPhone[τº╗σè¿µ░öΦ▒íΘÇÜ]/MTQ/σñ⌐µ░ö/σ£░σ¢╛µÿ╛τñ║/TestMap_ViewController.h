//
//  TestMap_ViewController.h
//  scMobileWeatherIn
//
//  Created by lesogo on 14-4-11.
//  Copyright (c) 2014年 Lesogo. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>

@interface TestMap_ViewController : UIViewController
<MKMapViewDelegate>

@property(nonatomic,strong) IBOutlet MKMapView *m_googleView;

-(IBAction)backBtPressed:(UIButton*)sender;

@end
