//
//  TestMap_ViewController.m
//  scMobileWeatherIn
//
//  Created by lesogo on 14-4-11.
//  Copyright (c) 2014年 Lesogo. All rights reserved.
//

#import "TestMap_ViewController.h"

@interface RouteAnnotationTest : NSObject<MKAnnotation>
{
	CLLocationCoordinate2D coordinate;
	NSString	*title;
	NSString	*subtitle;
    NSDictionary*routeDictionary;
}
@property (nonatomic) int     dataType;
@property (nonatomic,  copy) NSString *title;
@property (nonatomic,  copy) NSString *subtitle;
@property (nonatomic,  strong) NSDictionary*routeDictionary;
@property(nonatomic,readonly)CLLocationCoordinate2D coordinate;

-(id)initWithCoordinate:(CLLocationCoordinate2D)coords;
@end

@implementation RouteAnnotationTest
@synthesize coordinate;
@synthesize title;
@synthesize subtitle;
@synthesize dataType;
@synthesize routeDictionary;
-(id)initWithCoordinate:(CLLocationCoordinate2D)coords
{
	if (self = [super init])
	{
		coordinate = coords;
	}
	return self;
}
@end

@implementation TestMap_ViewController

-(id)init
{
    if (iPhone5)
    {
        self = [super initWithNibName:@"TestMap_ViewController_ip5" bundle:nil];
    }
    else
    {
        self = [super initWithNibName:@"TestMap_ViewController" bundle:nil];
    }
    return self;
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    NSMutableArray *arrays = [[NSMutableArray alloc] init];
    {
        NSMutableDictionary *nextDic = [[NSMutableDictionary alloc] init];
        [nextDic setObject:@"重庆" forKey:K_name];
        [nextDic setObject:@"29.58" forKey:K_latitude];
        [nextDic setObject:@"106.4" forKey:K_longitude];
        [arrays addObject:nextDic];
    }
    {
        NSMutableDictionary *nextDic = [[NSMutableDictionary alloc] init];
        [nextDic setObject:@"拉萨" forKey:K_name];
        [nextDic setObject:@"29.67" forKey:K_latitude];
        [nextDic setObject:@"91.13" forKey:K_longitude];
        [arrays addObject:nextDic];
    }
    {
        NSMutableDictionary *nextDic = [[NSMutableDictionary alloc] init];
        [nextDic setObject:@"上海" forKey:K_name];
        [nextDic setObject:@"31.2" forKey:K_latitude];
        [nextDic setObject:@"121.43" forKey:K_longitude];
        [arrays addObject:nextDic];
    }
    {
        NSMutableDictionary *nextDic = [[NSMutableDictionary alloc] init];
        [nextDic setObject:@"北京" forKey:K_name];
        [nextDic setObject:@"39.8" forKey:K_latitude];
        [nextDic setObject:@"116.47" forKey:K_longitude];
        [arrays addObject:nextDic];
    }
    
    for (NSDictionary *dic in arrays)
    {
        CLLocationCoordinate2D coordinate2D;
        coordinate2D.latitude = [[dic valueForKey:K_latitude] floatValue];
        coordinate2D.longitude = [[dic valueForKey:K_longitude] floatValue];
        
        RouteAnnotationTest *roteAnnotation = [[RouteAnnotationTest alloc] initWithCoordinate:coordinate2D];
        roteAnnotation.dataType = 1;
        roteAnnotation.title = [dic valueForKey:K_name];
        roteAnnotation.routeDictionary = dic;
        [self.m_googleView addAnnotation:roteAnnotation];
    }
}

-(IBAction)backBtPressed:(UIButton*)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark
#pragma mark MKMapViewDelegate

- (MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(id <MKAnnotation>)annotation
{
	//   // If it's the user location, just return nil.
    if ([annotation isKindOfClass:[MKUserLocation class]])
        return nil;
	
    static NSString *reuseIdentifier = @"RouteAnnotationTest";
    // Handle any custom annotations.
    if ([annotation isKindOfClass:[RouteAnnotationTest class]])
    {
        MKAnnotationView *AnnotationView = [mapView dequeueReusableAnnotationViewWithIdentifier:reuseIdentifier];
		if (!AnnotationView)
		{
            RouteAnnotationTest *testAnnotation = (RouteAnnotationTest*)annotation;
			AnnotationView = [[MKAnnotationView alloc] initWithAnnotation:annotation
                                                          reuseIdentifier:reuseIdentifier];
			AnnotationView.canShowCallout = NO;
			AnnotationView.enabled = YES;
            if (testAnnotation.dataType == 0)
            {
                NSString *fileName = @"mapflag.png";
                CGFloat imageWidth = 17.0;
                CGFloat imageHeight = 19.0;
                UIImageView *imageviews = [[UIImageView alloc] initWithFrame:CGRectMake(0.0, 0.0, imageWidth, imageHeight)];
                imageviews.userInteractionEnabled = YES;
                imageviews.image = [UIImage imageNamed:fileName];
                
                CGRect rct = AnnotationView.frame;
                rct.origin.x = 0.0;
                rct.origin.y = 0.0;
                rct.size = imageviews.frame.size;
                AnnotationView.frame = rct;
                AnnotationView.centerOffset = CGPointMake(rct.size.width/2.0, rct.size.height/2.0);
                
                [AnnotationView addSubview:imageviews];
            }
            else if(testAnnotation.dataType == 1)
            {
                NSString *fileName1 = @"mapflag2.png";
                NSString *fileName2 = @"mapSelected.png";
                
                CGFloat imageWidth1 = 17.0;
                CGFloat imageHeight1 = 19.0;
                
                CGFloat leftDistance = 7.0;
                CGFloat imageWidth2 = 140.0;
                CGFloat imageHeight2 = 65.0;
                
                UIView *bgViews = [[UIView alloc] initWithFrame:CGRectMake(0,0,                                                                           imageWidth1+imageWidth2, imageHeight1+imageHeight2)];
                
                UIImageView *bgImageView1 = [[UIImageView alloc] initWithFrame:CGRectMake(leftDistance, 0.0, imageWidth1, imageHeight1)];
                bgImageView1.userInteractionEnabled = YES;
                bgImageView1.image = [UIImage imageNamed:fileName1];
                [bgViews addSubview:bgImageView1];
                
                UIImageView *bgImageView2 = [[UIImageView alloc] initWithFrame:CGRectMake(0.0, imageHeight1, imageWidth2, imageHeight2)];
                bgImageView2.userInteractionEnabled = YES;
                bgImageView2.image = [UIImage imageNamed:fileName2];
                [bgViews addSubview:bgImageView2];
                
                CGFloat upDistance  = 10.0;
                CGFloat rightDistance  = 30.0;
                CGFloat labelWidth  = imageWidth2-rightDistance;
                CGFloat labelHeight = (imageHeight2-upDistance)/2.0;
                
                //右箭头
                //right-Arrow_Bule.png
                CGSize arrowSize = CGSizeMake(20, 20);
                UIImageView *rightArrow = [[UIImageView alloc] initWithFrame:CGRectMake(imageWidth2-arrowSize.width-5.0,
                                                                                        imageHeight1+imageHeight2/2.0-arrowSize.height/2.0,
                                                                                        arrowSize.width, arrowSize.height)];
                rightArrow.image = [UIImage imageNamed:@"right-Arrow_Bule.png"];
                [bgViews addSubview:rightArrow];
                
                //实况温度
                UILabel* SK_Temperature = [[UILabel alloc] initWithFrame:CGRectMake(0, imageHeight1+upDistance,
                                                                                    labelWidth, labelHeight)];
                SK_Temperature.textAlignment = UITextAlignmentCenter;
                SK_Temperature.font = [UIFont systemFontOfSize:14];
                SK_Temperature.textColor = [UIColor whiteColor];
                SK_Temperature.backgroundColor = [UIColor clearColor];
                SK_Temperature.text = @"";
                SK_Temperature.tag = 0x111;
                [bgViews addSubview:SK_Temperature];
                
                //体感温度
                UILabel* TG_Temperature = [[UILabel alloc] initWithFrame:CGRectMake(0, imageHeight1+upDistance+labelHeight,
                                                                                    labelWidth, labelHeight)];
                TG_Temperature.textAlignment = UITextAlignmentCenter;
                TG_Temperature.font = [UIFont systemFontOfSize:14];
                TG_Temperature.textColor = [UIColor whiteColor];
                TG_Temperature.backgroundColor = [UIColor clearColor];
                TG_Temperature.text = @"";
                TG_Temperature.tag = 0x222;
                [bgViews addSubview:TG_Temperature];
                
                CGRect rct = AnnotationView.frame;
                rct.origin.x = 0.0;
                rct.origin.y = 0.0;
                rct.size = bgViews.frame.size;
                AnnotationView.frame = rct;
                AnnotationView.centerOffset = CGPointMake(rct.size.width/2.0-leftDistance, rct.size.height/2.0);
                
                
                NSDictionary *dic = testAnnotation.routeDictionary;
                if (dic)
                {
                    if ([dic valueForKey:K_name])
                    {
                        SK_Temperature.text = [NSString stringWithFormat:@"实况温度:%@°",[dic valueForKey:K_name]];
                    }
                    if ([dic valueForKey:K_name])
                    {
                        TG_Temperature.text = [NSString stringWithFormat:@"体感温度:%@°",[dic valueForKey:K_name]];
                    }
                }
                
                [AnnotationView addSubview:bgViews];
            }
		}
        else
        {
            //AnnotationView.annotation = annotation;
            UILabel *label1 = (UILabel*)[AnnotationView viewWithTag:0x111];
            UILabel *label2 = (UILabel*)[AnnotationView viewWithTag:0x222];
            
            RouteAnnotationTest *testAnnotation = (RouteAnnotationTest*)annotation;
            NSDictionary *dic = testAnnotation.routeDictionary;
            
            if (dic)
            {
                if ([dic valueForKey:K_name])
                {
                    label1.text = [NSString stringWithFormat:@"实况温度:%@°",[dic valueForKey:K_name]];
                }
                if ([dic valueForKey:K_name])
                {
                    label2.text = [NSString stringWithFormat:@"体感温度:%@°",[dic valueForKey:K_name]];
                }
            }
        }
		return AnnotationView;
    }
	return nil;
}

- (void)mapView:(MKMapView *)mapView didSelectAnnotationView:(MKAnnotationView *)view
{
    [mapView deselectAnnotation:view.annotation animated:YES];
}

@end
