//
//  SKJC_TQSKViewController.h
//  MTQ
//
//  Created by Clover on 13-12-17.
//  Copyright (c) 2013年 Lesogo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SKJC_TQSKViewController : UIViewController
<UITableViewDataSource,UITableViewDelegate>
{
    ASIFormDataRequest      *m_httpFormDataRequest;
}

@property(nonatomic,strong)NSDictionary     *m_dataDictionary;
@property(nonatomic,strong)NSDictionary     *m_KeyStringDictionary;

@property(nonatomic,strong)IBOutlet UITableView *m_tableView;

@property (strong, nonatomic) IBOutlet UILabel  *m_SunUp;
@property (strong, nonatomic) IBOutlet UILabel  *m_SunDown;
@property (strong, nonatomic) IBOutlet UILabel  *m_CityNameLabel;
@property (strong, nonatomic) IBOutlet UILabel  *m_StationNameLabel;
@property (strong, nonatomic) IBOutlet UIActivityIndicatorView  *m_ActivityIndicatorView;

-(IBAction)backBtPressed:(id)sender;

@end
