//
//  SKJC_TQSKViewController.m
//  MTQ
//
//  Created by Clover on 13-12-17.
//  Copyright (c) 2013年 Lesogo. All rights reserved.
//

#import "SKJC_TQSKViewController.h"

#import "TQSKCell.h"


@implementation SKJC_TQSKViewController

@synthesize m_tableView;

@synthesize m_SunUp;
@synthesize m_SunDown;
@synthesize m_KeyStringDictionary;

-(id)init
{
    if (iPhone5)
    {
        self = [super initWithNibName:@"SKJC_TQSKViewController_ip5" bundle:nil];
    }
    else
    {
        self = [super initWithNibName:@"SKJC_TQSKViewController" bundle:nil];
    }
    return self;
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self updateInterface];
}

-(IBAction)backBtPressed:(id)sender
{
    if (m_httpFormDataRequest)
    {
        [m_httpFormDataRequest clearDelegatesAndCancel];
    }
    
    [self.navigationController popViewControllerAnimated:YES];
}

-(NSArray*)itemNameArr
{
    NSArray*itemNameArr = [[NSArray alloc] initWithObjects:@"实况温度",@"体感温度",@"一小时降水",
                           @"湿度",@"风力",@"风向",@"",nil];
    return itemNameArr;
    
    //有气压和紫外线
    NSArray*itemNameArr2 = [[NSArray alloc] initWithObjects:@"实况温度",@"体感温度",@"一小时降水",
                           @"湿度",@"风力",@"风向",@"气压",@"紫外线",@"",nil];
    return itemNameArr2;
}
-(NSArray*)itemUnitArr
{
    NSArray*itemNameArr = [[NSArray alloc] initWithObjects:@"℃",@"℃",@"mm",
                           @"%",@"m/s",@"",@"",nil];
    return itemNameArr;
    
    //有气压和紫外线
    NSArray*itemNameArr2 = [[NSArray alloc] initWithObjects:@"℃",@"℃",@"mm",
                           @"%",@"m/s",@"",@"hPa",@"",@"",nil];
    return itemNameArr2;
}
-(NSArray*)itemKeyArr
{
    NSArray*itemNameArr = [[NSArray alloc] initWithObjects:@"temp",@"tigan",@"rain",
                           @"humidity",@"wind",@"windDirect",nil];
    return itemNameArr;
    
    //有气压和紫外线
    NSArray*itemNameArr2 = [[NSArray alloc] initWithObjects:@"temp",@"tigan",@"rain",
                           @"humidity",@"wind",@"windDirect",@"press",@"uvi",nil];
    return itemNameArr2;
}
-(NSArray*)itemImageArr
{
    NSArray*itemNameArr = [[NSArray alloc] initWithObjects:@"sk_wd.png",@"sk_tgwd.png",@"sk_js.png",
                           @"sk_sd.png",@"sk_fl.png",@"sk_fx.png",@"sk_jjr.png",nil];
    return itemNameArr;
    
    //有气压和紫外线
    NSArray*itemNameArr2 = [[NSArray alloc] initWithObjects:@"sk_wd.png",@"sk_tgwd.png",@"sk_js.png",
                           @"sk_sd.png",@"sk_fl.png",@"sk_fx.png",@"sk_qy.png",@"sk_zwx.png",@"sk_jjr.png",nil];
    return itemNameArr2;
}


-(void)updateInterface
{
    if (m_KeyStringDictionary)
    {
        if (m_httpFormDataRequest)
        {
            [m_httpFormDataRequest clearDelegatesAndCancel];
        }
        
        [self.m_ActivityIndicatorView startAnimating];
        
        NSString *tempStrings = [URL searchEncryptStation];
        m_httpFormDataRequest = [ ASIFormDataRequest requestWithURL:[NSURL URLWithString:tempStrings]];
        [m_httpFormDataRequest setStringEncoding :NSUTF8StringEncoding];//设置数据类型为utf-8
        [m_httpFormDataRequest setPostValue:[m_KeyStringDictionary valueForKey:K_longitude] forKey:K_longitude];
        [m_httpFormDataRequest setPostValue:[m_KeyStringDictionary valueForKey:K_latitude] forKey:K_latitude];
        [m_httpFormDataRequest setPostValue:[m_KeyStringDictionary valueForKey:K_stationNum] forKey:K_stationNum];
        [m_httpFormDataRequest setPostValue:[Tools getTokenString] forKey:K_token];
        [m_httpFormDataRequest setDelegate:self];
        [m_httpFormDataRequest setDidFinishSelector : @selector (responseComplete:)];
        [m_httpFormDataRequest setDidFailSelector : @selector (responseFailed:)];
        [m_httpFormDataRequest startAsynchronous];
    }
}

#pragma mark --
#pragma mark UITableViewDataSource

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [[self itemNameArr] count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *identifier = @"TQSKCell";
    
    TQSKCell *cell = (TQSKCell*)[tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell == nil)
    {
        cell = [[[NSBundle mainBundle] loadNibNamed:@"TQSKCell" owner:self options:nil] objectAtIndex:0];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        
    }
    
    cell.m_iConImage.image = [UIImage imageNamed:[[self itemImageArr] objectAtIndex:indexPath.row]];

   
    //节日
    if (indexPath.row == ([self itemNameArr].count-1))
    {
        cell.m_jjrLabel.hidden = NO;
        NSMutableString*festStr = [[NSMutableString alloc] init];
        
        for (NSDictionary*jjrDic in [self.m_dataDictionary objectForKey:K_fest])
        {
            if ([[jjrDic objectForKey:K_day] integerValue]==0)
            {
                [festStr appendFormat:@"今日%@\t",[jjrDic objectForKey:K_name]];
            }
            else
            {
                [festStr appendFormat:@"距离%@:还有%@天\t",[jjrDic objectForKey:K_name],[jjrDic objectForKey:K_day]];
            }
        }
        cell.m_jjrLabel.text = festStr;
        
        cell.m_nameLabel.hidden = YES;
        cell.m_valueLabel.hidden = YES;
        cell.m_unitLabel.hidden = YES;
    }
    else
    {
        //其他实况信息
        cell.m_jjrLabel.hidden = YES;
        
        cell.m_nameLabel.hidden = NO;
        cell.m_nameLabel.text = [[self itemNameArr] objectAtIndex:[indexPath row]];
        
        
        cell.m_valueLabel.hidden = NO;
        cell.m_valueLabel.text = [self.m_dataDictionary objectForKey:[[self itemKeyArr] objectAtIndex:[indexPath row]]];
        
        cell.m_unitLabel.hidden = NO;
        cell.m_unitLabel.text = [[self itemUnitArr] objectAtIndex:[indexPath row]];
    }
    
    return cell;
}

#pragma mark --
#pragma mark UITableViewDelegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 43;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}


#pragma mark -
#pragma mark ASIFormDataRequest 回调函数

-( void )responseComplete:(ASIFormDataRequest*)request
{
    [self.m_ActivityIndicatorView stopAnimating];
    self.m_dataDictionary = nil;
    NSDictionary *dic = [[request responseString] JSONValue];
    if(dic)
    {
        self.m_dataDictionary = dic;
        
        if (self.m_dataDictionary)
        {
            //城市
            if ([self.m_dataDictionary valueForKey:K_city])
            {
                self.m_CityNameLabel.text = [NSString stringWithFormat:@"%@",[self.m_dataDictionary valueForKey:K_city]];
            }
            //最近站点
            if ([self.m_dataDictionary valueForKey:K_name])
            {
                self.m_StationNameLabel.text = [NSString stringWithFormat:@"站点: %@",[self.m_dataDictionary valueForKey:K_name]];
            }
            //日出日落
            NSArray *updownArray = [self.m_dataDictionary valueForKey:K_updown];
            if (updownArray && updownArray.count)
            {
                NSDictionary *updownDic = [updownArray objectAtIndex:0];
                if (updownDic && [updownDic valueForKey:K_up])
                {
                    self.m_SunUp.text = [NSString stringWithFormat:@"%@",[updownDic valueForKey:K_up]];
                }
                if (updownDic && [updownDic valueForKey:K_down])
                {
                    self.m_SunDown.text = [NSString stringWithFormat:@"%@",[updownDic valueForKey:K_down]];
                }
            }
        }
	}
    
    [self.m_tableView reloadData];
}

-( void )responseFailed:(ASIFormDataRequest*)request
{
    [self.m_ActivityIndicatorView stopAnimating];
    self.m_dataDictionary = nil;
    [self.m_tableView reloadData];
}

@end