//
//  TQSKCell.h
//  MTQ
//
//  Created by Clover on 13-12-19.
//  Copyright (c) 2013年 Lesogo. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AttributedLabel.h"
@interface TQSKCell : UITableViewCell


@property (strong, nonatomic) IBOutlet UIImageView*m_iConImage;
@property (strong, nonatomic) IBOutlet UILabel*m_nameLabel;
@property (strong, nonatomic) IBOutlet UILabel*m_valueLabel;
@property (strong, nonatomic) IBOutlet UILabel*m_unitLabel;

@property (strong, nonatomic) IBOutlet UILabel*m_jjrLabel;

@end
