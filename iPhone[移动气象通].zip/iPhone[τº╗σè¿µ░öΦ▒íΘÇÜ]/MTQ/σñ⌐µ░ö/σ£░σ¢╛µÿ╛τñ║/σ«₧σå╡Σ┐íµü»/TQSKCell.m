//
//  TQSKCell.m
//  MTQ
//
//  Created by Clover on 13-12-19.
//  Copyright (c) 2013年 Lesogo. All rights reserved.
//

#import "TQSKCell.h"
@implementation TQSKCell

@synthesize m_iConImage;
@synthesize m_nameLabel;
@synthesize m_valueLabel;
@synthesize m_unitLabel;

@synthesize m_jjrLabel;


- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
