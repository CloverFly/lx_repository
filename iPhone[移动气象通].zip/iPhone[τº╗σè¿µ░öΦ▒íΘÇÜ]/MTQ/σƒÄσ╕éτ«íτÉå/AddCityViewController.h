//
//  AddCityViewController
//  TestAdd
//  城市添加
//  Created by  on 13-07-16.
//  Copyright (c) 2013年 . All rights reserved.
//

#import <QuartzCore/QuartzCore.h>
#import <UIKit/UIKit.h>

#import "MTQ_CityManager_ViewController.h"
#import "DBMSEngine.h"
#import "ASIHTTPRequest.h"
#import "JSON.h"
#import "URL.h"

@protocol AddCityViewControllerDelegate;

@interface AddCityViewController : UIViewController
<UITableViewDelegate, UITableViewDataSource,
UISearchBarDelegate,UIAlertViewDelegate>
{
    NSDictionary    *m_selectedPickerCityDic;
    ASIFormDataRequest *httpPostRequest;
    BOOL            isHaveLocation;//是否有定位城市
}

@property(nonatomic) id<AddCityViewControllerDelegate> delegate;

@property (strong, nonatomic) IBOutlet UITableView  *m_tableView;
@property (strong, nonatomic) IBOutlet UIView       *m_addTableView;
@property (strong, nonatomic) IBOutlet UIImageView  *m_LocationImageView;
@property (strong, nonatomic) IBOutlet UIView       *m_hot_View;
@property (strong, nonatomic) IBOutlet UISearchBar  *m_SearchBar;

@property(nonatomic,strong)NSArray              *m_ListDataArray;
@property(nonatomic,strong)NSDictionary         *m_CityDataDictionary;
@property(nonatomic,strong)NSMutableDictionary  *m_SelectedCityDic;
@property(nonatomic,strong)UIViewController     *m_viewController;

-(IBAction)backBtPressed:(id)sender;

@end

@protocol AddCityViewControllerDelegate <NSObject>

-(void)viewController:(AddCityViewController *)aAddCityViewController reCityInfo:(NSDictionary*)aCityInfo;
-(void)viewController:(AddCityViewController *)aAddCityViewController reCityCode:(NSString*)aCityCode reCityName:(NSString*)aCityName;

@end


