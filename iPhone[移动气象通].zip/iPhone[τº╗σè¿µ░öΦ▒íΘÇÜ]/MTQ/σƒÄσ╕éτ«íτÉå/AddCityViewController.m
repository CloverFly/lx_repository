//
//  AddCityViewController
//  TestAdd
//  城市添加
//  Created by  on 13-07-16.
//  Copyright (c) 2013年 . All rights reserved.
//


#import "AddCityViewController.h"
#import "Tools.h"
#import "KeyHeadString.h"
#import "MTQ_CityManager_ViewController.h"

#define RGBS(r,g,b) [UIColor colorWithRed:r/255.0 green:g/255.0 blue:b/255.0 alpha:1.0]


#define KhotCitySavePath    


@implementation AddCityViewController

@synthesize delegate;
@synthesize m_CityDataDictionary;
@synthesize m_ListDataArray;
@synthesize m_SelectedCityDic;
@synthesize m_viewController;

-(id)init
{
    self = [super init];
    if (self)
    {
        // Custom initialization
        if (iPhone5)
        {
            self = [super initWithNibName:@"AddCityViewController_ip5" bundle:nil];
        }
        else
        {
            self = [super initWithNibName:@"AddCityViewController" bundle:nil];
        }
    }
    return self;
}

-(void)viewWillDisappear:(BOOL)animated
{
    if (httpPostRequest)
    {
        [httpPostRequest clearDelegatesAndCancel];
        httpPostRequest = nil;
    }
    [super viewWillDisappear:animated];
}


- (void)viewDidUnload
{
    self.m_addTableView = nil;
    self.m_tableView = nil;
    
    [super viewDidUnload];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.m_addTableView.frame = CGRectMake(0, CGRectGetMaxY(self.m_SearchBar.frame), self.m_addTableView.frame.size.width,
                                           self.m_addTableView.frame.size.height);
    [self.m_SearchBar.superview addSubview:self.m_addTableView];
    self.m_addTableView.hidden = YES;
    
    //去掉背景 让背景透明
    if (!iPhone5 && !ISIOS7)
    {
        for(id cc in [self.m_SearchBar subviews])
        {
            if ([cc isKindOfClass:[UIImageView class]])
            {
                UIImageView *imageview = (UIImageView *)cc;
                [imageview removeFromSuperview];
            }
        }
    }
    
    //热门城市
    [self downHotCity];
    
    //读取定位城市
    DBMSEngine *tempDBMSEngine = [[DBMSEngine alloc] init];
    NSMutableArray *tempArray = [tempDBMSEngine querryCityWeather];
    if (tempArray && tempArray.count)
    {
        DB_CityInfo *info = (DB_CityInfo*)[tempArray objectAtIndex:0];
        if (info && info.db_islocation && [info.db_islocation intValue]==1)
        {
            isHaveLocation = YES;
            
            UIButton *buttons = (UIButton*)[self.m_hot_View viewWithTag:100];
            [buttons setTitle:[NSString stringWithFormat:@"%@",info.db_cityName] forState:UIControlStateNormal];
            [buttons setBackgroundImage:[UIImage imageNamed:@"addcity_gou.png"]  forState:UIControlStateNormal];
            self.m_LocationImageView.hidden = NO;
        }
    }
    tempDBMSEngine = nil;
    
    
    //查询相关
    m_SelectedCityDic = [[NSMutableDictionary alloc] init];
    
	NSString *plistPath = [[NSBundle mainBundle] pathForResource:@"GetLocation" ofType:@"plist"];
	m_CityDataDictionary = [[NSDictionary alloc] initWithContentsOfFile:plistPath];
    
    self.m_ListDataArray = [m_CityDataDictionary allKeys];
}

-(void)downHotCity
{
    if (httpPostRequest)
    {
        [httpPostRequest clearDelegatesAndCancel];
        httpPostRequest = nil;
    }
    
    NSURL *urlss = [NSURL URLWithString:[URL HOTCITY]];
    httpPostRequest = [ ASIFormDataRequest requestWithURL:urlss];
    [httpPostRequest setStringEncoding :NSUTF8StringEncoding];//设置数据类型为utf-8
    [httpPostRequest setPostValue:[Tools getTokenString] forKey:K_token];
    [httpPostRequest setDelegate:self];
    [httpPostRequest setDidFinishSelector : @selector(responseComplete_hot:)];
    [httpPostRequest setDidFailSelector : @selector(requestFailed_hot:)];
    [httpPostRequest startAsynchronous];
}

-(void)showHotCity_View
{
    NSDictionary *dataDic = [Tools readUserDefaultsInfo:K_hotCity];
    
    if (dataDic)
    {
        NSString *locationKeyString = @"";
        NSMutableArray *array = [[NSMutableArray alloc] initWithArray:[dataDic valueForKey:K_datas]];
        DBMSEngine *tempDBMSEngine = [[DBMSEngine alloc] init];
        NSMutableArray *tempArray = [tempDBMSEngine querryCityWeather];
        if (tempArray && tempArray.count)
        {
            DB_CityInfo *info = (DB_CityInfo*)[tempArray objectAtIndex:0];
            if (info && info.db_islocation && [info.db_islocation intValue]==1)
            {
                locationKeyString = info.db_cityId;
            }
        }
        
        
        int i = isHaveLocation?101:100;
        for (NSDictionary *dic in array)
        {
            if (dic && [dic valueForKey:K_city] && ![[dic valueForKey:K_cityCode] isEqual:locationKeyString])
            {
                UIButton *buttons = (UIButton*)[self.m_hot_View viewWithTag:i];
                buttons.hidden = NO;
                
                [buttons setTitle:[NSString stringWithFormat:@"%@",[dic valueForKey:K_city]] forState:UIControlStateNormal];
                [buttons setTitle:[NSString stringWithFormat:@"%@",[dic valueForKey:K_cityCode]] forState:UIControlStateSelected];
                [buttons addTarget:self action:@selector(hotCityAddCityBtPressed:) forControlEvents:UIControlEventTouchUpInside];
                if ([tempDBMSEngine querryCityWeather:[dic valueForKey:K_cityCode]])
                {
                    [buttons setBackgroundImage:[UIImage imageNamed:@"addcity_gou.png"]forState:UIControlStateNormal];
                }
                else
                {
                    [buttons setBackgroundImage:[UIImage imageNamed:@""]forState:UIControlStateNormal];
                }
                
                i++;
                if (i >= 115)
                {
                    break;
                }
            }
        }
        tempDBMSEngine = nil;
    }
}

-(void)hotCitySelected:(NSString*)aKeyString
{
    if (aKeyString && [aKeyString isKindOfClass:[NSString class]])
    {
        for (id but in self.m_hot_View.subviews)
        {
            if ([but isKindOfClass:[UIButton class]])
            {
                UIButton *bt = (UIButton*)but;
                NSString *currentKeys = [bt titleForState:UIControlStateSelected];
                
                if ([currentKeys isEqual:aKeyString])
                {
                    [bt setBackgroundImage:[UIImage imageNamed:@"addcity_gou.png"] forState:UIControlStateNormal];
                }
            }
        }
    }
}

-(IBAction)backBtPressed:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)hotCityAddCityBtPressed:(UIButton*)sender
{
    NSString *currentSelectKeyString = [NSString stringWithFormat:@"%@",[sender titleForState:UIControlStateSelected]];
    
    //实况查询返回
    if (delegate)
    {
        [delegate viewController:self reCityCode:currentSelectKeyString reCityName:[sender titleForState:0]];
        [self.navigationController popViewControllerAnimated:YES];
        return ;
    }
    
    DBMSEngine *tempDBMSEngine = [[DBMSEngine alloc] init];
    
    if ([tempDBMSEngine querryCityWeather:currentSelectKeyString])
    {
        tempDBMSEngine = nil;
        return;
    }
    else
    {
        NSArray *dataArray = [tempDBMSEngine querryCityWeather];
        if (dataArray && dataArray.count>=9)
        {
            tempDBMSEngine = nil;
            UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:@"城市已满,请删除后再添加!"
                                                               message:nil
                                                              delegate:nil
                                                     cancelButtonTitle:@"确定"
                                                     otherButtonTitles: nil];
            [alertView show];
            return;
        }
        
        //更新数据库
        DB_CityInfo *tempWeather = [[DB_CityInfo alloc] init];
        tempWeather.db_cityId = currentSelectKeyString;
        tempWeather.db_cityName = [sender titleForState:0];
        [tempDBMSEngine updateCityWeather:tempWeather];
        
        [self hotCitySelected:currentSelectKeyString];
        [self showM_alertView:[sender titleForState:0]];//提示
    }
    
    tempDBMSEngine = nil;
}

-(void)showM_alertView:(NSString*)aNameString
{
    if (aNameString)
    {
        UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:[NSString stringWithFormat:@"添加%@",aNameString]
                                                message:nil
                                               delegate:nil
                                      cancelButtonTitle:@"确定"
                                      otherButtonTitles: nil];
        [alertView show];
    }
}


#pragma mark -
#pragma mark UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return [[self.m_SelectedCityDic allKeys] count];
}
- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    NSString *key = [[self.m_SelectedCityDic allKeys] objectAtIndex:section];
    return key;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    NSString *key = [[self.m_SelectedCityDic allKeys] objectAtIndex:section];
    NSArray *allCitys = [self.m_SelectedCityDic objectForKey:key];
    return [allCitys count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSUInteger section = [indexPath section];
    NSUInteger row = [indexPath row];
    NSString *key = [[self.m_SelectedCityDic allKeys] objectAtIndex:section];
    NSArray *allCitys = [self.m_SelectedCityDic objectForKey:key];
    
    static NSString *GroupedTableIdentifier = @"GroupedTableIdentifier";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:GroupedTableIdentifier];
    if (YES)
    {
        cell = [[UITableViewCell alloc]
                initWithStyle:UITableViewCellStyleDefault
                reuseIdentifier:GroupedTableIdentifier];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.backgroundColor = [UIColor colorWithRed:89/255.0 green:116/255.0 blue:152/255.0 alpha:1.0];
    cell.backgroundColor = [UIColor whiteColor];
    //设置内容
    UILabel *item = [[UILabel alloc] initWithFrame:CGRectMake(10.0, 8.0, 300, 25)];
    item.tag = 0x11;
    item.backgroundColor=[UIColor clearColor];
    item.textColor = [UIColor blackColor];
    item.textAlignment = UITextAlignmentLeft;
    item.font=[UIFont boldSystemFontOfSize:20];
    [cell addSubview:item];
    
    if ([[[allCitys objectAtIndex:row] objectForKey:K_city] isEqualToString:[[allCitys objectAtIndex:row] objectForKey:K_county]])
    {
        item.text = [[allCitys objectAtIndex:row] objectForKey:K_county];
    }
    else
    {
        item.text = [NSString stringWithFormat:@"%@·%@",
                     [[allCitys objectAtIndex:row] objectForKey:K_city],
                     [[allCitys objectAtIndex:row] objectForKey:K_county]];
    }
    
    return cell;
}


#pragma mark -
#pragma mark UITableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSUInteger section = [indexPath section];
    NSUInteger row = [indexPath row];
    NSString *key =     [[self.m_SelectedCityDic allKeys] objectAtIndex:section];
    NSArray  *allCitys = [self.m_SelectedCityDic objectForKey:key];
    if (row<[allCitys count])
    {        
        NSDictionary *dic = [allCitys objectAtIndex:row];
                
        if (dic!=nil && [dic valueForKey:K_station])
        {
            //===========================//
            //实况查询返回
            if (delegate)
            {
                if ([delegate respondsToSelector:@selector(viewController: reCityInfo:)])
                {
                    [delegate viewController:self reCityInfo:dic];
                }
                [self.navigationController popViewControllerAnimated:YES];
                return ;
            }
            //===========================//
            
            DBMSEngine *tempDBMSEngine = [[DBMSEngine alloc] init];
            
            NSString *KeyString = [dic valueForKey:K_station];
            if ([tempDBMSEngine querryCityWeather:KeyString])
            {
                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"温馨提示"
                                                                message:@"该城市已经存在!"
                                                               delegate:nil
                                                      cancelButtonTitle:nil
                                                      otherButtonTitles:@"确定", nil];
                [alert show];
            }
            else
            {
                if ([tempDBMSEngine querryCityWeather] && [tempDBMSEngine querryCityWeather].count>=9)
                {
                    tempDBMSEngine = nil;
                    UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:@"城市已满,请删除后再添加!"
                                                                       message:nil
                                                                      delegate:nil
                                                             cancelButtonTitle:@"确定"
                                                             otherButtonTitles: nil];
                    [alertView show];
                    return;
                }
                
                //更新数据库
                DB_CityInfo *weatherInfo = [[DB_CityInfo alloc] init];
                weatherInfo.db_cityId = KeyString;
                weatherInfo.db_cityName = [dic valueForKey:K_county];
                [tempDBMSEngine updateCityWeather:weatherInfo];
                
                //提示
                [self showM_alertView:[dic valueForKey:K_county]];
            }
            tempDBMSEngine = nil;
        }
    }
}

#pragma mark -
#pragma mark    UISearchBarDelegate

- (BOOL)searchBarShouldBeginEditing:(UISearchBar *)searchBar
{
    self.m_addTableView.hidden = NO;
    [self.m_SearchBar setShowsCancelButton:YES];
    
    return YES;
}

- (void)searchBarTextDidBeginEditing:(UISearchBar *)hsearchBar
{
    for(id cc in [hsearchBar subviews])
    {
        if([cc isKindOfClass:[UIButton class]])
        {
            UIButton *btn = (UIButton *)cc;
            [btn setTitle:@"取消"  forState:UIControlStateNormal];
        }
    }
}

- (void)searchBarCancelButtonClicked:(UISearchBar *) searchBar
{
    [self.m_SearchBar resignFirstResponder];
    [self.m_SearchBar setShowsCancelButton:NO];
    self.m_SearchBar.text = @"";
    
    self.m_addTableView.hidden = YES;
}

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar
{
    [self.m_SearchBar resignFirstResponder];
}

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
{
    
    [self.m_SelectedCityDic removeAllObjects];
    for (NSString*key in self.m_ListDataArray)
    {
        NSMutableArray *provinceCityArray = [[NSMutableArray alloc] init] ;
        
        NSArray*allTempCityArr = [self.m_CityDataDictionary objectForKey:key];
        for (NSDictionary * tempDic in allTempCityArr)
        {
            if ([[[tempDic objectForKey:K_small] uppercaseString] rangeOfString:[searchBar.text uppercaseString]].length!=0
                || [[tempDic objectForKey:K_city] rangeOfString:searchBar.text].length!=0)
            {
                if (tempDic)
                {
                    if ([[tempDic objectForKey:K_county] isKindOfClass:[NSArray class]])
                    {
                        NSArray *countyArray =[tempDic objectForKey:K_county];
                        if (countyArray && countyArray.count)
                        {
                            [provinceCityArray addObjectsFromArray:[tempDic objectForKey:K_county]];
                        }
                    }
                    else
                    {
                        [provinceCityArray addObject:tempDic];
                    }
                }
            }
            else
            {
                id allTempCountryArr = [tempDic objectForKey:K_county];
                if ([allTempCountryArr isKindOfClass:[NSArray class]])
                {
                    for (NSDictionary * tempOneCountryDic in allTempCountryArr)
                    {
                        if (tempOneCountryDic)
                        {
                            if ([[[tempOneCountryDic objectForKey:K_small] uppercaseString] rangeOfString:[searchBar.text uppercaseString]].length!=0
                                ||[[tempOneCountryDic objectForKey:K_city] rangeOfString:searchBar.text].length!=0
                                ||[[tempOneCountryDic objectForKey:K_county] rangeOfString:searchBar.text].length!=0)
                            {
                                [provinceCityArray addObject:tempOneCountryDic];
                            }
                        }
                    }
                }
            }
            
        }
        
        if ([provinceCityArray count]>0)
        {
            [self.m_SelectedCityDic setObject:[provinceCityArray copy] forKey:key];
        }
    }
    
    [self.m_tableView reloadData];
    
}


#pragma mark -
#pragma mark ASIFormDataRequest-热门城市

-( void )responseComplete_hot:(ASIFormDataRequest*)request
{
    NSDictionary *dic = [[request responseString] JSONValue];
    if (dic)
    {
        [Tools saveUserDefaultsInfo:dic :K_hotCity];
    }
    
    [self showHotCity_View];
}


-( void )requestFailed_hot:(ASIFormDataRequest*)request
{
    [self showHotCity_View];
}

@end
