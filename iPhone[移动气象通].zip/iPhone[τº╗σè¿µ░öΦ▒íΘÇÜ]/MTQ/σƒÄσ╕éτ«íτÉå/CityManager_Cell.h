//
//  CityManager_Cell.h
//  MTQ
//  城市管理 cell
//  Created by lesogo on 13-12-23.
//  Copyright (c) 2013年 Lesogo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CityManager_Cell : UITableViewCell

@property(nonatomic,strong) IBOutlet UILabel        *m_NameLabel;
@property(nonatomic,strong) IBOutlet UIImageView    *m_isLocationImageView;

@end
