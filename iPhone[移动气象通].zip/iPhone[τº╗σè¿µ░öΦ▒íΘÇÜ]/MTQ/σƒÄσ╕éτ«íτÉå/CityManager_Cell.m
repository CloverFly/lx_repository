//
//  CityManager_Cell.m
//  MTQ
//  城市管理 cell
//  Created by lesogo on 13-12-23.
//  Copyright (c) 2013年 Lesogo. All rights reserved.
//

#import "CityManager_Cell.h"

@implementation CityManager_Cell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
