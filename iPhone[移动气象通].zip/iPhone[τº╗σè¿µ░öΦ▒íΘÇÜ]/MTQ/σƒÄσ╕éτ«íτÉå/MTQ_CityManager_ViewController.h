//
//  MTQ_CityManager_ViewController.h
//  MTQ
//  城市管理
//  Created by lesogo on 13-12-20.
//  Copyright (c) 2013年 Lesogo. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "ASIFormDataRequest.h"

@interface MTQ_CityManager_ViewController : UIViewController
<UITableViewDataSource,UITableViewDelegate>
{
    NSMutableArray      *m_RequestArray;
}

@property(nonatomic,strong) IBOutlet UIView         *m_NotDataView;

@property(nonatomic,strong) IBOutlet UIView         *m_timeTitleView;

@property(nonatomic,strong) IBOutlet UITableView    *m_TableView;
@property(nonatomic,strong) NSMutableArray          *m_TableViewArray;

-(IBAction)backBtPressed:(UIButton*)sender;
-(IBAction)updateBtPressed:(id)sender;
-(IBAction)editBtPressed:(UIButton*)sender;
-(IBAction)addBtPressed:(UIButton*)sender;

-(void)updateCityInfo:(NSString*)aKeyString;

@end
