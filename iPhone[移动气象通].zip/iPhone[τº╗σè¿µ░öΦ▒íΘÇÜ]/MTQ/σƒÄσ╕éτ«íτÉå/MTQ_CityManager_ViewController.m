//
//  MTQ_CityManager_ViewController.m
//  MTQ
//
//  Created by lesogo on 13-12-20.
//  Copyright (c) 2013年 Lesogo. All rights reserved.
//

#import "MTQ_CityManager_ViewController.h"

#import "Tools.h"
#import "JSON.h"
#import "CityManager_Cell.h"
#import "AddCityViewController.h"


@implementation MTQ_CityManager_ViewController

-(id)init
{
    if (iPhone5)
    {
        self = [super initWithNibName:@"MTQ_CityManager_ViewController_ip5" bundle:nil];
    }
    else
    {
        self = [super initWithNibName:@"MTQ_CityManager_ViewController" bundle:nil];
    }
    return self;
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewDidUnload
{
    [super viewDidUnload];
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    [self loadInterface:YES];
}

-(void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
    [AppDelegate sumbitCityList];
    for (ASIFormDataRequest *tempRequest in m_RequestArray)
    {
        if (tempRequest)
        {
            [tempRequest clearDelegatesAndCancel];
        }
    }
}


- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    //时间标题处理
    for (int i=1; i<3; i++)
    {
        NSDate *tempDate = [[NSDate date] dateByAddingTimeInterval:60*60*24*i];
        UILabel *labels  = (UILabel*)[self.m_timeTitleView viewWithTag:200+i];
        labels.text      = [Tools GetWeekNameFromDate:tempDate];
    }
    
    self.m_TableViewArray = [[NSMutableArray alloc] init];
    m_RequestArray = [[NSMutableArray alloc] init];
}

-(IBAction)backBtPressed:(UIButton*)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

-(IBAction)updateBtPressed:(id)sender
{
    [self loadInterface:YES];
}

-(IBAction)editBtPressed:(UIButton*)sender
{
    self.m_TableView.editing = !self.m_TableView.editing;
}

-(IBAction)addBtPressed:(UIButton*)sender
{
    if (self.m_TableViewArray && self.m_TableViewArray.count>=9)
    {
        UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:@"城市已满,请删除后再添加!"
                                                           message:nil
                                                          delegate:nil
                                                 cancelButtonTitle:@"确定"
                                                 otherButtonTitles: nil];
        [alertView show];
        return;
    }
    
    AddCityViewController *viewCtr = [[AddCityViewController alloc] init];
    [self.navigationController pushViewController:viewCtr animated:YES];
}

-(void)loadInterface:(BOOL)isUpdate
{
    //数据读取
    DBMSEngine *tempDBMSEngine = [[DBMSEngine alloc] init];
    
    self.m_TableViewArray = [tempDBMSEngine querryCityWeather];
    [self.m_TableView reloadData];
    
    if (isUpdate)
    {
        for (DB_CityInfo* cityinfos in self.m_TableViewArray)
        {
            if (cityinfos && cityinfos.db_cityId)
            {
                [self updateCityInfo:cityinfos.db_cityId];
            }
        }
    }
}

-(void)updateCityInfo:(NSString*)aKeyString
{
    if (aKeyString)
    {
        NSURL *urlss = [NSURL URLWithString:[URL get_WeatherDataUrl]];
        ASIFormDataRequest *httpPostRequest = [ ASIFormDataRequest requestWithURL:urlss];
        [httpPostRequest setStringEncoding :NSUTF8StringEncoding];//设置数据类型为utf-8
        [httpPostRequest setPostValue:aKeyString forKey:K_cityId];
        [httpPostRequest setPostValue:@"true," forKey:K_cityInfo];
        [httpPostRequest setPostValue:@"true," forKey:K_sk];
        [httpPostRequest setPostValue:@"true," forKey:K_sk_zd];
        [httpPostRequest setPostValue:@"true," forKey:K_yb];
        [httpPostRequest setPostValue:@"true," forKey:K_jxhyb];
        [httpPostRequest setPostValue:@"true," forKey:K_zh];
        [httpPostRequest setPostValue:@"true," forKey:K_lifeIndex];
        [httpPostRequest setPostValue:@"true," forKey:K_fest];
        [httpPostRequest setPostValue:@"true," forKey:K_air];
        [httpPostRequest setPostValue:@"true," forKey:K_updown];
        [httpPostRequest setPostValue:iPhone5?@"40x71":@"2x3" forKey:K_scale];
        [httpPostRequest setPostValue:[Tools getTokenString] forKey:K_token];
        [httpPostRequest setDelegate:self];
        [httpPostRequest setDidFinishSelector : @selector (responseComplete:)];
        [httpPostRequest setDidFailSelector : @selector (responseFailed:)];
        [httpPostRequest startAsynchronous];
        [m_RequestArray addObject:httpPostRequest];
    }
}


#pragma mark --
#pragma mark UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (self.m_TableViewArray)
    {
        self.m_NotDataView.hidden = YES;
        return self.m_TableViewArray.count;
    }
    
    self.m_NotDataView.hidden = NO;
    return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *identifier = @"CityManager_Cell";
    CityManager_Cell *cell = (CityManager_Cell*)[tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:identifier owner:self options:nil];
        for (id oneObject in nib)
        {
            if ([oneObject isKindOfClass:[CityManager_Cell class]])
            {
                cell = (CityManager_Cell*)oneObject;
                break;
            }
        }
    }
    
    DB_CityInfo *infos = (DB_CityInfo*)[self.m_TableViewArray objectAtIndex:indexPath.row];
    if (infos)
    {
        if (infos.db_cityName)
        {
            cell.m_NameLabel.text = [NSString stringWithFormat:@"%@",infos.db_cityName];
        }
        if (infos.db_islocation && [infos.db_islocation intValue] ==1 && indexPath.row == 0)
        {
            cell.m_isLocationImageView.hidden = NO;
        }
        
        //数据
        NSDictionary *dic = [Tools JsonParser:infos.db_content];
        if (dic)
        {
            NSDictionary *ybDict = [dic valueForKey:K_yb];
            if (ybDict)
            {
                NSArray *ybArray = [ybDict valueForKey:K_datas];
                
                int index = 0;
                for (NSDictionary *nextDic in ybArray)
                {
                    if (index>=3)
                        break;
                    if (nextDic)
                    {
                        NSString *timerString = [nextDic valueForKey:K_time];
                        if (timerString && [timerString isKindOfClass:[NSString class]] && [timerString length]==14)
                        {
                            timerString = [timerString substringWithRange:NSMakeRange(0, 8)];
                            NSDate *tempDatess = [[NSDate date] dateByAddingTimeInterval:60*60*24*index];
                            NSString *nextTimer = [Tools dateFormatString:@"yyyyMMdd" setDate:tempDatess];
                            if ([timerString isEqual:nextTimer])
                            {
                                UIImageView *iconView = (UIImageView*)[cell viewWithTag:300+index*100];
                                UILabel     *labels   = (UILabel*)[cell viewWithTag:301+index*100];
                                
                                //图标
                                iconView.image = [Tools getDayBlueWeatherImage:[nextDic valueForKey:K_oneCode]];
                                
                                //温度
                                NSMutableString *temperatureStr = [[NSMutableString alloc] init];
                                if ([nextDic valueForKey:K_low])
                                {
                                    [temperatureStr appendString:[nextDic valueForKey:K_low]];
                                    if ([nextDic valueForKey:K_high])
                                    {
                                        [temperatureStr appendString:@"~"];
                                    }
                                }
                                if ([nextDic valueForKey:K_high])
                                {
                                    [temperatureStr appendString:[nextDic valueForKey:K_high]];
                                }
                                [temperatureStr appendString:@"°"];
                                labels.text = temperatureStr;
                                
                                index++;
                            }
                        }
                    }
                }
            }
        }
    }
    
    return cell;
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row==0)
    {
        return NO;
    }
    return YES;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
	if ([self.m_TableViewArray count]==1)
	{
		UIAlertView *alerts = [[UIAlertView alloc] initWithTitle:@"温馨提示"
														 message:@"最后一个不能删除,谢谢!"
														delegate:nil
											   cancelButtonTitle:@"好"
											   otherButtonTitles:nil];
		
		[alerts show];
		return;
	}
    
    //数据库删除
    DB_CityInfo *infos = (DB_CityInfo*)[self.m_TableViewArray objectAtIndex:indexPath.row];
    if (infos)
    {
        DBMSEngine *tempEngine = [[DBMSEngine alloc] init];
        [tempEngine deleteCityWeatherForObject:infos];
        
        [Tools removeUserDefaults:infos.db_cityId];
        
        //删除当前选中城市
        NSString *currentKeyString = [Tools readUserDefaultsInfo:K_cityId];
        if (currentKeyString && [currentKeyString isKindOfClass:[NSString class]])
        {
            if ([currentKeyString compare:infos.db_cityId] == NSOrderedSame)
            {
                [Tools removeUserDefaults:K_cityId];
            }
        }
    }
    
    //界面删除
    [self.m_TableViewArray removeObjectAtIndex:[indexPath row]];
    [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
}

#pragma mark --
#pragma mark UITableViewDelegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 44.0;
}

- (NSString *)tableView:(UITableView *)tableView titleForDeleteConfirmationButtonForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return @"删除";
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    DB_CityInfo *infos = (DB_CityInfo*)[self.m_TableViewArray objectAtIndex:indexPath.row];
    if (infos)
    {
        [Tools saveUserDefaultsInfo:infos.db_cityId :K_cityId];
    }
    
    [self backBtPressed:nil];
}

#pragma mark -
#pragma mark ASIFormDataRequest 回调函数

-( void )responseComplete:(ASIFormDataRequest*)request
{
    NSDictionary *dic = [[request responseString] JSONValue];
    if(dic)
    {
        if ([dic valueForKey:K_cityInfo])
        {
            NSDictionary *cityInfoDic = [dic valueForKey:K_cityInfo];
            
            DBMSEngine *engine = [[DBMSEngine alloc] init];
            
            DB_CityInfo *dateBCityInfo = [[DB_CityInfo alloc] init];
            dateBCityInfo.db_cityId = [cityInfoDic valueForKey:K_cityId];
            dateBCityInfo.db_cityName = [cityInfoDic valueForKey:K_cityName];
            dateBCityInfo.db_latitude = [cityInfoDic valueForKey:K_latitude];
            dateBCityInfo.db_longitude = [cityInfoDic valueForKey:K_longitude];
            dateBCityInfo.db_content = [dic JSONRepresentation];
            dateBCityInfo.db_updateTimer = [dic valueForKey:K_time];
            dateBCityInfo.db_version = [dic valueForKey:K_version];
            
            [engine updateCityWeather:dateBCityInfo];
            
            [self loadInterface:NO];
        }
	}
}

-( void )responseFailed:(ASIFormDataRequest*)request
{
}

@end
