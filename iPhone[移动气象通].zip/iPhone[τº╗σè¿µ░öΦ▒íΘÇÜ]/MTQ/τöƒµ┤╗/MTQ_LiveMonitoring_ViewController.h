//
//  MTQ_LiveMonitoring_ViewController.h
//  MTQ
//
//  Created by lesogo on 13-12-3.
//  Copyright (c) 2013年 Lesogo. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SKJC_KQZLViewController.h"
#import "SKJC_SHZSViewController.h"
#import "UIButton+LXButton.h"
#import "AddCityViewController.h"


@interface MTQ_LiveMonitoring_ViewController : UITabBarController
<UITabBarControllerDelegate,AddCityViewControllerDelegate>
{
	NSInteger	oldIndex;
    UIImageView *m_TableBarBackImageView;
    ASIFormDataRequest  *m_httpFormDataRequest;
}

@property(nonatomic)int currIndex;

- (void) hideTabBar:(BOOL) hidden;

-(void)loadDownButton;

-(void)changeViewControllers:(UIButton*)sender;
-(void)updateSearchCityByCityCode:(NSString*)aCityCode;
@end
