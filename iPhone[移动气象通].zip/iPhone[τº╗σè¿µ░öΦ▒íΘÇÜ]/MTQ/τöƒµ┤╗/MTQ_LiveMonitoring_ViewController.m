//
//  MTQ_LiveMonitoring_ViewController.m
//  MTQ
//
//  Created by lesogo on 13-12-3.
//  Copyright (c) 2013年 Lesogo. All rights reserved.
//

#import "MTQ_LiveMonitoring_ViewController.h"
#import "AddCityViewController.h"
#import <QuartzCore/QuartzCore.h>

#define TEMPCITYPATH [NSString stringWithFormat:@"%@/%@/",[NSSearchPathForDirectoriesInDomains( NSDocumentDirectory,NSUserDomainMask, YES) objectAtIndex:0],@"skQueryCity"]


#define ALLOC_BUTTON(OPX,OPY,SW,SH) [[UIButton alloc] initWithFrame:CGRectMake(OPX,OPY,SW,SH)]

@implementation MTQ_LiveMonitoring_ViewController
{
    SKJC_SHZSViewController *viewController1;
    SKJC_KQZLViewController *viewController2;
}

@synthesize currIndex;

#pragma mark --
#pragma mark 内存管理

- (void)didReceiveMemoryWarning
{
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];

	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload
{
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
    m_TableBarBackImageView = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return UIInterfaceOrientationIsPortrait(interfaceOrientation);
}

#pragma mark --
#pragma mark 初始化函数

-(void)viewWillAppear:(BOOL)animated
{
//    [[NSUserDefaults standardUserDefaults] setValue:@"0" forKey:SKINDEXKEY];
 
//    [viewController1 viewWillAppear:YES];
    [super viewWillAppear:animated];
    
}

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    [super viewDidLoad];
    [self CreateFolder:TEMPCITYPATH];
    
    self.navigationController.navigationBarHidden = YES;
	[self hideTabBar:YES];
	
	self.view.backgroundColor = [UIColor blackColor];
    oldIndex = 0x100;
	
	[self loadDownButton];
	
    viewController1 = [[SKJC_SHZSViewController alloc] init];
	UINavigationController *navigation1 = [[UINavigationController alloc] initWithRootViewController:viewController1];
    
    viewController2 = [[SKJC_KQZLViewController alloc] init];
	UINavigationController *navigation2 = [[UINavigationController alloc] initWithRootViewController:viewController2];
    
    NSMutableArray *arrays = [[NSMutableArray alloc] init];
    
	[arrays addObject:navigation1];
	[arrays addObject:navigation2];
	self.viewControllers = arrays;
    
	self.customizableViewControllers = arrays;
	self.selectedIndex = 0;
}

- (void) hideTabBar:(BOOL) hidden
{
	for(UIView *view in self.view.subviews)
	{
		if([view isKindOfClass:[UITabBar class]])
		{
			view.hidden = YES;
		}
		else
		{
			[view setFrame:CGRectMake(view.frame.origin.x, view.frame.origin.y, view.frame.size.width, 1024)];
		}
	}
}

-(void)loadDownButton
{
    /**
     *  加载导航条
     */
    UIView*topView = nil;
    if (ISIOS7)
    {
        topView = [[UIView alloc]initWithFrame:CGRectMake(0, 20, 320, 40)];
    }
    else
    {
        topView = [[UIView alloc]initWithFrame:CGRectMake(0, 20, 320, 40)];
    }
    

    
    [topView setBackgroundColor:[UIColor clearColor]];
    [self.view addSubview:topView];
//    UIButton*backBt = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 50, 40)];
//    [backBt setBackgroundImage:[UIImage imageNamed:@"back.png"] forState:UIControlStateNormal];
    //[backBt addTarget:nil action:@selector(backBtPressed:) forControlEvents:UIControlEventTouchUpInside];
    //[topView addSubview:backBt];
    
    UIButton*searchBt = [[UIButton alloc] initWithFrame:CGRectMake(320-50, 0, 50, 40)];
    [searchBt setBackgroundImage:[UIImage imageNamed:@"search.png"] forState:UIControlStateNormal];
    //[searchBt addTarget:nil action:@selector(searchBtPressed:) forControlEvents:UIControlEventTouchUpInside];
    //[topView addSubview:searchBt];

    
//    UILabel*titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(50, 0, 320-50, 40)];
//    titleLabel.text=@"实况监测";
//    titleLabel.textColor = [UIColor blackColor];
//    titleLabel.backgroundColor = [UIColor clearColor];
//    titleLabel.font = [UIFont boldSystemFontOfSize:TITLEFONTSIZE];
//#if __IPHONE_OS_VERSION_MIN_REQUIRED < __IPHONE_6_0
//    titleLabel.textAlignment = UITextAlignmentLeft;
//#else
//    titleLabel.textAlignment = NSTextAlignmentLeft;
//#endif
//    [topView addSubview:titleLabel];
    
    
    
    /**
     *  加载TAB
     */
    CGFloat barHeight = 35.0f;//整个bar栏的高度
	CGSize buttonsize = CGSizeMake(150.0f,barHeight);
    
    if (ISIOS7)
    {
        m_TableBarBackImageView = [[UIImageView alloc] initWithFrame:CGRectMake(10.0, 57+10, 300, barHeight)];
    }
    else
    {
        m_TableBarBackImageView = [[UIImageView alloc] initWithFrame:CGRectMake(10.0, 57+10, 300, barHeight)];
    }
	[m_TableBarBackImageView setBackgroundColor:[UIColor clearColor]];
    m_TableBarBackImageView.userInteractionEnabled = YES;
    m_TableBarBackImageView.backgroundColor = [UIColor clearColor];
    m_TableBarBackImageView.layer.cornerRadius = 4;//设置那个圆角的有多圆
    m_TableBarBackImageView.layer.borderWidth = 1.5;//设置边框的宽度，当然可以不要
    m_TableBarBackImageView.layer.borderColor = [RGBCOLOR(54.0f,89.0f,114.0f) CGColor];//设置边框的颜色
    m_TableBarBackImageView.layer.masksToBounds = YES;//设为NO去试试
	[self.view addSubview:m_TableBarBackImageView];
    for (int index=0; index<2; index++)
    {
        UIButton *buttons = ALLOC_BUTTON(index*buttonsize.width, 0,buttonsize.width,buttonsize.height);
        if (index==0)
        {
            [buttons setTitle:@"生活资讯" forState:0];
        }
        else
        {
            [buttons setTitle:@"空气质量" forState:0];
        }
        [buttons setTitleColor:[UIColor redColor] forState:0];
        if (index==0)
        {
            
            [buttons CustomStyleByColor:RGBCOLOR(54.0f,89.0f,114.0f) HighLightColor:RGBCOLOR(54.0f,89.0f,114.0f)];
        }
        else
        {
            [buttons CustomStyleByColor:RGBCOLOR(6.0f,48.0f,79.0f) HighLightColor:RGBCOLOR(6.0f,48.0f,79.0f)];
        }
        buttons.tag = 0x100+index;
        
        [buttons addTarget:nil
                    action:@selector(changeViewControllers:)
          forControlEvents:UIControlEventTouchUpInside];
        [m_TableBarBackImageView addSubview:buttons];
    }

}

-(void)changeViewControllers:(UIButton*)sender
{
    UIColor*aColor =RGBCOLOR(6.0f,48.0f,79.0f);
    UIColor*bColor =RGBCOLOR(54.0f,89.0f,114.0f);
    for (int tag = 0x100; tag<0x100+2; tag++)
    {
        UIButton*tempBt= ((UIButton*)[m_TableBarBackImageView viewWithTag:tag]);
        [tempBt CustomStyleByColor:aColor HighLightColor:aColor];
    }
    [sender CustomStyleByColor:bColor HighLightColor:bColor];
    self.selectedIndex = sender.tag-0x100;
}

-(void)backBtPressed:(UIButton*)sender
{
    NSArray*pathArr = [self selectFileType:@"plist" setPath:TEMPCITYPATH];
    for (NSString*filePath in pathArr)
    {
        [self deleteFile:filePath];
    }
    [[NSUserDefaults standardUserDefaults] setValue:[NSString stringWithFormat:@"%d",0] forKey:SKINDEXKEY];
    
    [AppDelegate.navController popViewControllerAnimated:YES];
}
-(void)searchBtPressed:(UIButton*)sender
{
    AddCityViewController*nextViewController = [[AddCityViewController alloc] init];
    nextViewController.delegate = self;
    [AppDelegate.navController pushViewController:nextViewController animated:YES];
}


#pragma mark 文件操作
-(BOOL)isFileExistAtPath:(NSString*)fileFullPath
{
    BOOL isExist = NO;
    isExist = [[NSFileManager defaultManager] fileExistsAtPath:fileFullPath];
    return isExist;
}
-(void)saveDictionaryToFile:(NSDictionary*)aDictionary withFilename:(NSString*)aFileName
{
	if (aDictionary)
	{
        NSString *newPath = [NSString stringWithFormat:@"%@%@.plist",TEMPCITYPATH,aFileName];
        if ([self isFileExistAtPath:newPath])
        {
            [[NSFileManager defaultManager] removeItemAtPath:newPath error:nil];
        }
        [aDictionary writeToFile:newPath atomically:YES];
	}
}

-(NSDictionary*)readDictionaryToFile:(NSString*)aFileName
{
    NSString *newPath = [NSString stringWithFormat:@"%@%@.plist",TEMPCITYPATH,aFileName];
    if (![self isFileExistAtPath:newPath])
    {
        return nil;
    }
    NSDictionary*dic = [[NSDictionary alloc] initWithContentsOfFile:newPath];
    return dic;
}
#pragma mark 遍历指定类型文件

-(NSArray*)selectFileType:(NSString*)fileType setPath:(NSString*)aFolderPath
{
    NSFileManager *fileManager = [[NSFileManager defaultManager] init];
    NSMutableArray*files = [[NSMutableArray alloc] init];
    NSDirectoryEnumerator *direnum = [fileManager enumeratorAtPath:aFolderPath];
    NSString *fileName;
    while ((fileName = [direnum nextObject]))
    {
        if([[fileName pathExtension] isEqualToString:fileType])
        {
            [files addObject:[NSString stringWithFormat:@"%@%@",aFolderPath,fileName]];
        }
    }
    return files;
}
#pragma mark 删除文件
-(void)deleteFile:(NSString*)aFilePath
{
    NSFileManager *fileManager = [NSFileManager defaultManager];
    BOOL existed = [fileManager fileExistsAtPath:aFilePath];
    if (existed)
    {
        [fileManager removeItemAtPath:aFilePath error:nil];
    }
}
#pragma mark 创建文件夹
-(void)CreateFolder:(NSString*)aFolderName
{
    NSFileManager *fileManager = [NSFileManager defaultManager];
    BOOL isDir = NO;
    BOOL existed = [fileManager fileExistsAtPath:aFolderName isDirectory:&isDir];
    if (!existed)
    {
        [fileManager createDirectoryAtPath:aFolderName withIntermediateDirectories:YES attributes:nil error:nil];
    }
}
#pragma mark 增加城市的委托
-(void)viewController:(AddCityViewController *)aAddCityViewController reCityInfo:(NSDictionary*)aCityInfo
{
    [self updateSearchCityByCityCode:[aCityInfo objectForKey:K_station]];
}
-(void)viewController:(AddCityViewController *)aAddCityViewController reCityCode:(NSString*)aCityCode reCityName:(NSString*)aCityName
{
    [self updateSearchCityByCityCode:aCityCode];
}

#pragma mark 更新查询的实况数据
-(void)cancelUpdateRequest//取消更新请求
{
    if (m_httpFormDataRequest)
    {
        [m_httpFormDataRequest clearDelegatesAndCancel];
    }
}

-(void)updateSearchCityByCityCode:(NSString*)aCityCode
{
    if (m_httpFormDataRequest)
    {
        [m_httpFormDataRequest clearDelegatesAndCancel];
    }
    
    NSString *tempStrings = [URL get_WeatherDataUrl];
    m_httpFormDataRequest = [ ASIFormDataRequest requestWithURL:[NSURL URLWithString:tempStrings]];
    [m_httpFormDataRequest setStringEncoding :NSUTF8StringEncoding];//设置数据类型为utf-8
    [m_httpFormDataRequest setPostValue:aCityCode forKey:K_cityId];
    [m_httpFormDataRequest setPostValue:@"true," forKey:K_cityInfo];
    [m_httpFormDataRequest setPostValue:@"true," forKey:K_sk];
    [m_httpFormDataRequest setPostValue:@"true," forKey:K_sk_zd];
    [m_httpFormDataRequest setPostValue:@"true," forKey:K_yb];
    [m_httpFormDataRequest setPostValue:@"true," forKey:K_jxhyb];
    [m_httpFormDataRequest setPostValue:@"true," forKey:K_zh];
    [m_httpFormDataRequest setPostValue:@"true," forKey:K_lifeIndex];
    [m_httpFormDataRequest setPostValue:@"true," forKey:K_fest];
    [m_httpFormDataRequest setPostValue:@"true," forKey:K_air];
    [m_httpFormDataRequest setPostValue:@"true," forKey:K_updown];
    [m_httpFormDataRequest setPostValue:[Tools getTokenString] forKey:K_token];
    [m_httpFormDataRequest setDelegate:self];
    [m_httpFormDataRequest setDidFinishSelector : @selector (responseComplete:)];
    [m_httpFormDataRequest setDidFailSelector : @selector (responseFailed:)];
    [m_httpFormDataRequest startAsynchronous];
}

#pragma mark -
#pragma mark ASIFormDataRequest 回调函数

-( void )responseComplete:(ASIFormDataRequest*)request
{
    NSDictionary *dic = [[request responseString] JSONValue];
    [self saveDictionaryToFile:dic withFilename:@"tempSK"];
    
    [viewController1 addSearchPage:YES];
    [viewController2 addSearchPage:YES];
    viewController1.isHaveSearchCity = YES;
    viewController2.isHaveSearchCity = YES;
}

-( void )responseFailed:(ASIFormDataRequest*)request
{
  
}
@end