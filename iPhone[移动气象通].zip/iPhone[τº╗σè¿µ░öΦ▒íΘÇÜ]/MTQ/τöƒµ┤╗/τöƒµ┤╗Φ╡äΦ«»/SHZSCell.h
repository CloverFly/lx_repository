//
//  SHZSCell.h
//  MTQ
//
//  Created by Clover on 13-12-19.
//  Copyright (c) 2013年 Lesogo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SHZSCell : UITableViewCell

@property (strong, nonatomic) IBOutlet UIImageView  *m_iConImage;
@property (strong, nonatomic) IBOutlet UIImageView  *m_ADImage;
@property (strong, nonatomic) IBOutlet UILabel      *m_nameLabel;
@property (strong, nonatomic) IBOutlet UILabel      *m_contentLabel;

@property(nonatomic,strong)NSString                 *m_adImageUrl;

-(void)loadImageViews;

@end
