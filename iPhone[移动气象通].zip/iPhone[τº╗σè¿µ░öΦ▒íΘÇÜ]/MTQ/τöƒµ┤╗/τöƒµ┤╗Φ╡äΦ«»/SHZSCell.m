//
//  SHZSCell.m
//  MTQ
//
//  Created by Clover on 13-12-19.
//  Copyright (c) 2013年 Lesogo. All rights reserved.
//

#import "SHZSCell.h"
#import "SDWebImageManager.h"
#import <QuartzCore/QuartzCore.h>
@implementation SHZSCell


@synthesize m_iConImage;
@synthesize m_ADImage;
@synthesize m_nameLabel;
@synthesize m_contentLabel;

@synthesize m_adImageUrl;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

-(void)layoutSubviews
{
    if (m_adImageUrl.length>15)
    {
        NSURL*url = [NSURL URLWithString:m_adImageUrl];
        [[SDWebImageManager sharedManager]
         downloadWithURL:url
         options:SDWebImageProgressiveDownload
         progress:^(NSUInteger receivedSize, long long expectedSize)
         {
         }
         completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, BOOL finished)
         {
             m_ADImage.image = [self CutImage:image newSize:CGSizeMake(466, 104) cacheQuality:1.0];
         }
         ];
    }
    
}


-(void)loadImageViews
{
    if (m_adImageUrl && [m_adImageUrl isKindOfClass:[NSString class]] && [m_adImageUrl length]>10)
    {
        NSURL*url = [NSURL URLWithString:m_adImageUrl];
        [[SDWebImageManager sharedManager]
         downloadWithURL:url
         options:SDWebImageProgressiveDownload
         progress:^(NSUInteger receivedSize, long long expectedSize)
         {
         }
         completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, BOOL finished)
         {
             m_ADImage.image = image;
             //m_ADImage.image = [self CutImage:image newSize:CGSizeMake(466, 104) cacheQuality:1.0];
         }
         ];
    }
}


-(UIImage*)CutImage:(UIImage*)image newSize:(CGSize)aSize cacheQuality:(float)quality
{
    int width = image.size.width;
    int height = image.size.height;
    CGRect rect ;
    float px =width*1.0/height;
    float targetPx = 4.6;
    if (px>targetPx)
    {
        rect=CGRectMake((width-height*targetPx)/2,0,height*targetPx,height);
    }
    else
    {
        rect=CGRectMake(0,(height-width/targetPx)/2,width,width/targetPx);
    }
    CGImageRef imageRef=CGImageCreateWithImageInRect([image CGImage],rect);
    UIImage* elementImage=[UIImage imageWithCGImage:imageRef];
  
    
    UIGraphicsBeginImageContext(aSize);
    [elementImage drawInRect:CGRectMake(0,0,aSize.width,aSize.height)];
    UIImage* newImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return newImage;
}

@end
