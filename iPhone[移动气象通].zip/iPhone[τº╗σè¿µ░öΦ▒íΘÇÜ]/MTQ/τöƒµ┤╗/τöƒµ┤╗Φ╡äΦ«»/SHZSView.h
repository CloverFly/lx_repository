//
//  SHZS.h
//  MTQ
//
//  Created by Clover on 13-12-18.
//  Copyright (c) 2013年 Lesogo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SHZSView : UIView
<UITableViewDataSource,UITableViewDelegate>

@property(nonatomic,strong)id m_ListData;
@property(nonatomic,strong)IBOutlet UITableView *m_tableView;
@property (strong, nonatomic) IBOutlet UILabel  *m_NOContentLabel;
@end
