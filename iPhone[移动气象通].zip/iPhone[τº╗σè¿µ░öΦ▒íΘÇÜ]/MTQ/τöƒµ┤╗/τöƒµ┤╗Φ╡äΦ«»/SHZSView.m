//
//  SHZS.m
//  MTQ
//
//  Created by Clover on 13-12-18.
//  Copyright (c) 2013年 Lesogo. All rights reserved.
//

#import "SHZSView.h"
#import "SHZSCell.h"
@implementation SHZSView

@synthesize m_ListData;
@synthesize m_tableView;
@synthesize m_NOContentLabel;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

-(NSString*)itemIconName:(NSString*)type
{
    if (type)
    {
        return [NSString stringWithFormat:@"z%@.png",type];
    }
    return @"";
}

-(void)layoutSubviews
{
    m_NOContentLabel.hidden = YES;
    [self.m_tableView reloadData];
}


#pragma mark    UITableViewDataSource

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if ([self.m_ListData count]==0)
    {
        m_NOContentLabel.hidden = NO;
    }
    return [self.m_ListData count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *identifier = @"SHZSCell";
    
    
    SHZSCell *cell = (SHZSCell*)[tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell == nil)
    {
        cell = [[[NSBundle mainBundle] loadNibNamed:@"SHZSCell" owner:self options:nil] objectAtIndex:0];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    
    NSDictionary*tempIndexDic = [self.m_ListData objectAtIndex:[indexPath row]];
    if (tempIndexDic)
    {
        if ([tempIndexDic objectForKey:K_url] && [[tempIndexDic objectForKey:K_url] isKindOfClass:[NSString class]] && [[tempIndexDic objectForKey:K_url] length]>10)
        {
            cell.m_adImageUrl       = [tempIndexDic objectForKey:K_url];
            [cell loadImageViews];
        }
        else
        {
            cell.m_ADImage.image = [UIImage imageNamed:[NSString stringWithFormat:@"ad%@.png",[tempIndexDic objectForKey:K_lifeType]]];
        }
        cell.m_iConImage.image  = [UIImage imageNamed:[self itemIconName:[tempIndexDic objectForKey:K_lifeType]]];
        cell.m_nameLabel.text   = [tempIndexDic objectForKey:K_level];
        cell.m_contentLabel.text = [tempIndexDic objectForKey:K_content];
    }
    
    return cell;
}

#pragma mark UITableViewDelegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 120;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

@end
