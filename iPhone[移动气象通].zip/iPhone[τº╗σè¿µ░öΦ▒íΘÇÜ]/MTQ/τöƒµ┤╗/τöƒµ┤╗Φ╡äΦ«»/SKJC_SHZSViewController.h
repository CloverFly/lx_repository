//
//  SKJC_SHZSViewController.h
//  MTQ
//
//  Created by Clover on 13-12-17.
//  Copyright (c) 2013年 Lesogo. All rights reserved.
//

#import <UIKit/UIKit.h>
@interface SKJC_SHZSViewController : UIViewController
<UIScrollViewDelegate>
{
    BOOL isHaveLocationCity;
}


@property(nonatomic,strong)NSMutableArray*m_cityArr;
@property(nonatomic,strong)NSMutableArray*m_DataArr;

@property (strong, nonatomic) IBOutlet UILabel*m_CurrCityNameLabel;
@property (strong, nonatomic) IBOutlet UIImageView*m_LocationImageView;
@property (strong, nonatomic) IBOutlet UIPageControl*m_pageControl;
@property (strong, nonatomic) IBOutlet UIScrollView*m_scrollView;
@property (nonatomic)int m_currIndex;
@property (nonatomic)BOOL isHaveSearchCity;
-(void)addSearchPage:(BOOL)aScroll;
@end
