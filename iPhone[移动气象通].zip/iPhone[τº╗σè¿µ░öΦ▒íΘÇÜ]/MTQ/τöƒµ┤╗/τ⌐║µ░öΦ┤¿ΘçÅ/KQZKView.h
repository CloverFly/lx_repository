//
//  KQZKView.h
//  MTQ
//
//  Created by Clover on 13-12-18.
//  Copyright (c) 2013年 Lesogo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface KQZKView : UIView

@property (strong, nonatomic) IBOutlet UIView   *m_interfaceView;
@property (strong, nonatomic) IBOutlet UILabel  *m_TipsLabel;

@property (strong, nonatomic) IBOutlet UIImageView*m_selectedBackImageView;
@property (strong, nonatomic) IBOutlet UIImageView*m_arrowImageView;
@property (strong, nonatomic) IBOutlet UITextView*m_itemTipsLabel;

@property (strong, nonatomic) IBOutlet UILabel*m_itemNameLabel;
@property (strong, nonatomic) IBOutlet UILabel*m_itemAQILabel;
@property (strong, nonatomic) IBOutlet UILabel*m_itemUnitLabel;

@property (strong, nonatomic) IBOutlet UILabel*m_item0_NDLabel;
@property (strong, nonatomic) IBOutlet UILabel*m_item1_NDLabel;
@property (strong, nonatomic) IBOutlet UILabel*m_item2_NDLabel;
@property (strong, nonatomic) IBOutlet UILabel*m_item3_NDLabel;
@property (strong, nonatomic) IBOutlet UILabel*m_item4_NDLabel;
@property (strong, nonatomic) IBOutlet UILabel*m_item5_NDLabel;
@property (strong, nonatomic) IBOutlet UILabel*m_item6_NDLabel;

@property (strong, nonatomic) NSDictionary*m_AirDataDic;
@property (strong, nonatomic) NSDictionary*m_AirDataDicNext;//空气质量污染物气象扩散条件预报

-(IBAction)kqBtPressed:(UIButton*)sender;

-(void)loadView;

@end
