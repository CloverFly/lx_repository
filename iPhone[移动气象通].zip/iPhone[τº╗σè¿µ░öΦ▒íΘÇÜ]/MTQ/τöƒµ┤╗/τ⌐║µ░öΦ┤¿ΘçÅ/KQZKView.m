//
//  KQZKView.m
//  MTQ
//
//  Created by Clover on 13-12-18.
//  Copyright (c) 2013年 Lesogo. All rights reserved.
//

#import "KQZKView.h"
#import "UIButton+LXButton.h"

/*
 
 */
#define KRGBColor(r,g,b,a) [UIColor colorWithRed:r green:g blue:b alpha:a]

@implementation KQZKView

@synthesize m_selectedBackImageView;
@synthesize m_arrowImageView;
@synthesize m_itemNameLabel;
@synthesize m_itemAQILabel;
@synthesize m_itemUnitLabel;
@synthesize m_itemTipsLabel;
@synthesize m_item0_NDLabel;
@synthesize m_item1_NDLabel;
@synthesize m_item2_NDLabel;
@synthesize m_item3_NDLabel;
@synthesize m_item4_NDLabel;
@synthesize m_item5_NDLabel;
@synthesize m_item6_NDLabel;

@synthesize m_AirDataDic;
@synthesize m_AirDataDicNext;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

-(void)drawRect:(CGRect)rect
{
    /*
    CGRectMake(31, 29, 277, 113);
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetRGBStrokeColor(context, 0, 0, 0, 1.0);//线条颜色
    CGContextMoveToPoint(context, 34, 160);//ip4 110   ip5
    CGContextSetLineWidth(context, 4.0);
    for (int i = 0; i<277; i+=2)
    {
        float xP = i/46.0;
        float x = 34+xP*46;
        float y = 160-0.08*xP*xP*46;//ip4 110  0.05   ip5  160 0.08
        CGContextAddLineToPoint(context, x,y);
    }
    CGContextStrokePath(context);
     */
}

-(void)loadView
{
    if (self.m_AirDataDic)
    {
        NSString*aqiStringss = [[self.m_AirDataDic objectForKey:K_aqi] objectForKey:K_aqi];
        if (aqiStringss && [aqiStringss isKindOfClass:[NSString class]] && aqiStringss.length >1&& [aqiStringss compare:@"-"]!= NSOrderedSame)
        {
            self.m_interfaceView.hidden = NO;
            self.m_TipsLabel.hidden = YES;
        }
        else
        {
            NSString*alertString = [self.m_AirDataDicNext valueForKey:K_alert];
            if (alertString && [alertString isKindOfClass:[NSString class]] && [alertString compare:@"-"]!= NSOrderedSame && alertString.length>1)
            {
                self.m_interfaceView.hidden = YES;
                self.m_TipsLabel.hidden = NO;
                self.m_TipsLabel.text = [NSString stringWithFormat:@"%@",[self.m_AirDataDicNext valueForKey:K_alert]];
                return;
            }
            else
            {
                self.m_interfaceView.hidden = YES;
                self.m_TipsLabel.text = @"暂无该城市的空气质量数据";
                self.m_TipsLabel.hidden = NO;
                return;
            }
        }
    }
    else if(self.m_AirDataDicNext)
    {
        NSString*alertString = [self.m_AirDataDicNext valueForKey:K_alert];
        if (alertString && [alertString isKindOfClass:[NSString class]] && [alertString compare:@"-"]!= NSOrderedSame && alertString.length>1)
        {
            self.m_interfaceView.hidden = YES;
            self.m_TipsLabel.hidden = NO;
            self.m_TipsLabel.text = [NSString stringWithFormat:@"%@",[self.m_AirDataDicNext valueForKey:K_alert]];
            return;
        }
        else
        {
            self.m_interfaceView.hidden = YES;
            self.m_TipsLabel.text = @"暂无该城市的空气质量数据";
            self.m_TipsLabel.hidden = NO;
            return;
        }
    }
    else
    {
        self.m_interfaceView.hidden = YES;
        self.m_TipsLabel.text = @"暂无该城市的空气质量数据";
        self.m_TipsLabel.hidden = NO;
        return;
    }
    
    int index = 0;
    NSString*path = [[NSBundle mainBundle] pathForResource:@"airC" ofType:@"plist"];
    NSDictionary*yDataDic = [NSDictionary dictionaryWithContentsOfFile:path];
    NSArray*tempArr = [yDataDic objectForKey:K_aqi];
    for (int tag = 31; tag<=36; tag++)
    {
        UILabel*yLabel = (UILabel*)[self viewWithTag:tag];
        yLabel.text = [tempArr objectAtIndex:tag-31];
    }
    
    m_item0_NDLabel.text = [[self.m_AirDataDic objectForKey:K_aqi] objectForKey:K_nongdu];
    m_item1_NDLabel.text = [[self.m_AirDataDic objectForKey:K_pm25] objectForKey:K_nongdu];
    m_item2_NDLabel.text = [[self.m_AirDataDic objectForKey:K_pm10] objectForKey:K_nongdu];
    m_item3_NDLabel.text = [[self.m_AirDataDic objectForKey:K_so2] objectForKey:K_nongdu];
    m_item4_NDLabel.text = [[self.m_AirDataDic objectForKey:K_no2] objectForKey:K_nongdu];
    m_item5_NDLabel.text = [[self.m_AirDataDic objectForKey:K_co] objectForKey:K_nongdu];
    m_item6_NDLabel.text = [[self.m_AirDataDic objectForKey:K_o3] objectForKey:K_nongdu];
    
    m_itemNameLabel.text = [[self itemNameArr] objectAtIndex:index];
    m_itemUnitLabel.text = [[self itemUnitArr] objectAtIndex:index];

    NSString*apiLevel = [[self.m_AirDataDic objectForKey:K_aqi] objectForKey:K_aqi_level];
    if ([apiLevel integerValue]<=6&&[apiLevel integerValue]>0)
    {
        apiLevel = [[self itemLevelArr] objectAtIndex:[apiLevel integerValue]-1];
    }
    NSString*apiValue = [[self.m_AirDataDic objectForKey:K_aqi] objectForKey:K_aqi];
    self.m_itemAQILabel.text = [NSString stringWithFormat:@"%@  %@",apiLevel,apiValue];
    self.m_itemTipsLabel.text = [[self.m_AirDataDic objectForKey:K_aqi] objectForKey:K_alert];;
    if (self.m_AirDataDicNext && [self.m_AirDataDicNext valueForKey:K_alert])
    {
        self.m_itemTipsLabel.text = [NSString stringWithFormat:@"%@\n%@",[[self.m_AirDataDic objectForKey:K_aqi] objectForKey:K_alert],[self.m_AirDataDicNext valueForKey:K_alert]];
    }
    
    
    CGPoint pt = CGPointMake([self getYFromAQI:apiValue].x, [self getYFromAQI:apiValue].y);
    m_arrowImageView.frame = CGRectMake(pt.x,pt.y,18,20);
    
    [self adjustDeriction];
}

-(NSArray*)itemNameArr
{
    NSArray*itemNameArr = [[NSArray alloc] initWithObjects:@"AQI",@"PM2.5",@"PM10",
                           @"SO2",@"NO2",@"CO",@"O3",nil];
    return itemNameArr;
}
-(NSArray*)itemLevelArr
{
    NSArray*itemNameArr = [[NSArray alloc] initWithObjects:@"优",@"良",@"轻度污染",
                           @"中度污染",@"重度污染",@"严重污染",nil];
    return itemNameArr;
}
-(NSArray*)itemUnitArr
{
    NSArray*itemNameArr = [[NSArray alloc] initWithObjects:@"",@"单位:μg/m3",@"单位:μg/m3",
                           @"单位:μg/m3",@"单位:μg/m3",@"单位:mg/m3",@"单位:μg/m3",nil];
    return itemNameArr;
}
-(NSArray*)itemKeyArr
{
    NSArray*itemNameArr = [[NSArray alloc] initWithObjects:K_aqi,K_pm25,K_pm10,
                           K_so2,K_no2,K_co,K_o3,nil];
    return itemNameArr;
}

-(IBAction)kqBtPressed:(UIButton*)sender
{
    NSString*path = [[NSBundle mainBundle] pathForResource:@"airC" ofType:@"plist"];
    NSDictionary*yDataDic = [NSDictionary dictionaryWithContentsOfFile:path];
    
    NSArray*tempArr = [yDataDic objectForKey:[[self itemKeyArr] objectAtIndex:sender.tag-20]];
    for (int tag = 31; tag<=36; tag++)
    {
        UILabel*yLabel = (UILabel*)[self viewWithTag:tag];
        yLabel.text = [tempArr objectAtIndex:tag-31];
    }
    for (int tag = 20; tag<=20+6; tag++)
    {
        UIButton*tempBt = (UIButton*)[self viewWithTag:tag];
        [tempBt CustomStyleByColor:[UIColor clearColor] HighLightColor:[UIColor clearColor]];
    }
    [UIView animateWithDuration:0.5 animations:^(void)
     {
         if (IPHONE_HEIGHT>480)
         {
             self.m_selectedBackImageView.frame = CGRectMake(45*(sender.tag-20)+5-2, 236,44,95);
         }
         else
         {
             self.m_selectedBackImageView.frame = CGRectMake(45*(sender.tag-20)+5-2, 165,44,95);
         }
         
     }];
    
    m_itemNameLabel.text = [[self itemNameArr] objectAtIndex:sender.tag-20];
    m_itemUnitLabel.text = [[self itemUnitArr] objectAtIndex:sender.tag-20];
    
    m_itemUnitLabel.hidden = (sender.tag==20)?YES:NO;

    NSString*selectedKey = [[self itemKeyArr] objectAtIndex:sender.tag-20];
    
    NSString*apiLevel = [[self.m_AirDataDic objectForKey:selectedKey] objectForKey:K_aqi_level];
    if ([apiLevel integerValue]<=6&&[apiLevel integerValue]>0)
    {
        apiLevel = [[self itemLevelArr] objectAtIndex:[apiLevel integerValue]-1];
    }
    NSString*apiValue = [[self.m_AirDataDic objectForKey:selectedKey] objectForKey:K_aqi];
    self.m_itemAQILabel.text = [NSString stringWithFormat:@"%@  %@",apiLevel,apiValue];
    self.m_itemTipsLabel.text = @"";
    self.m_itemTipsLabel.text = [NSString stringWithFormat:@"%@",[[self.m_AirDataDic objectForKey:selectedKey] objectForKey:K_alert]];
    if (self.m_AirDataDicNext && [self.m_AirDataDicNext valueForKey:K_alert])
    {
        self.m_itemTipsLabel.text = [NSString stringWithFormat:@"%@\n%@",[[self.m_AirDataDic objectForKey:selectedKey] objectForKey:K_alert],[self.m_AirDataDicNext valueForKey:K_alert]];
    }
    
    CGPoint pt = CGPointMake([self getYFromAQI:apiValue].x, [self getYFromAQI:apiValue].y);
    m_arrowImageView.frame = CGRectMake(pt.x,pt.y,18,20);
    
    [self adjustDeriction];
}


-(CGPoint)getYFromAQI:(NSString*)aAQIStr
{
    float xPx = 0;
    float aqiValue = [aAQIStr floatValue];
    float xP = 1.0;
    float x = 1.0f;
    if (aqiValue<=50)//[0,50] 一级 优 绿色
    {
        xPx = aqiValue/50.0f;
    }
    else if (aqiValue>=51&&aqiValue<=100)////[51,100] 二级 良 黄色
    {
        xPx = aqiValue/50.0f;
    }
    else if (aqiValue>=101&&aqiValue<=150)////[101,150] 三级 轻度污染 橙色
    {
        xPx = aqiValue/50.0f;
    }
    else if (aqiValue>=151&&aqiValue<=200)////[150,200] 四级 中度污染 红色
    {
        xPx = aqiValue/50.0f;
    }
    else if (aqiValue>=201&&aqiValue<=300)////[201,300] 五级 重度污染 紫色
    {
        xPx = aqiValue/100.0f;
        xPx = 4+(aqiValue-200)/100.0f;
    }
    else if (aqiValue>300)////[300,∞) 六级 严重污染 褐红色
    {
        xPx = 5+(aqiValue-300)/200.0f;
        if (xPx>6)
        {
            xPx=6;
        }
    }
    xP = xPx;
    x = xPx*46.0f;
    
    float y = 1.0;
    if (IPHONE_HEIGHT>480)
    {
        y = 160-0.08*xP*xP*46;
    }
    else
    {
        y = 110-0.05*xP*xP*46;
    }
    
    CGPoint targetP = CGPointMake(x+35-10,y-10);
    return targetP;
}

-(void)adjustDeriction
{
    CGFloat nameLabelW = [self.m_itemNameLabel.text sizeWithFont:self.m_itemNameLabel.font].width;
    CGFloat AQILabelW =  [self.m_itemAQILabel.text sizeWithFont:self.m_itemAQILabel.font].width;
    CGFloat distance = 10.0;
    
    CGRect rct = self.m_itemNameLabel.frame;
    rct.origin.x = CGRectGetWidth(self.frame)/2.0-(nameLabelW+AQILabelW+distance)/2.0;
    rct.size.width = nameLabelW;
    self.m_itemNameLabel.frame = rct;
    
    rct = self.m_itemAQILabel.frame;
    rct.origin.x = CGRectGetMaxX(self.m_itemNameLabel.frame)+distance;
    rct.size.width = AQILabelW;
    self.m_itemAQILabel.frame = rct;
}

@end
