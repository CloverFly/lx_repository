//
//  SKJC_KQZLViewController.h
//  MTQ
//
//  Created by Clover on 13-12-17.
//  Copyright (c) 2013年 Lesogo. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MTQ_LiveMonitoring_ViewController.h"
@interface SKJC_KQZLViewController : UIViewController
<UIScrollViewDelegate>
{
    BOOL isHaveLocationCity;
}

@property(nonatomic,strong)NSMutableArray*m_cityArr;
@property(nonatomic,strong)NSMutableArray*m_DataArr;
@property(nonatomic,strong)NSMutableArray*m_airForecstArray;

@property (strong, nonatomic) IBOutlet UILabel*m_CurrCityNameLabel;
@property (strong, nonatomic) IBOutlet UIImageView*m_LocationImageView;
@property (strong, nonatomic) IBOutlet UIPageControl*m_pageControl;
@property (strong, nonatomic) IBOutlet UIScrollView*m_scrollView;
@property (nonatomic)int m_currIndex;
@property (nonatomic)BOOL isHaveSearchCity;

-(void)addSearchPage:(BOOL)aScroll;
@end
