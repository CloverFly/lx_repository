//
//  SKJC_KQZLViewController.m
//  MTQ
//
//  Created by Clover on 13-12-17.
//  Copyright (c) 2013年 Lesogo. All rights reserved.
//

#import "SKJC_KQZLViewController.h"
#import "KQZKView.h"
#import "SHZSView.h"
#import <QuartzCore/QuartzCore.h>

#define TEMPCITYPATH [NSString stringWithFormat:@"%@/%@/",[NSSearchPathForDirectoriesInDomains( NSDocumentDirectory,NSUserDomainMask, YES) objectAtIndex:0],@"skQueryCity"]
@interface SKJC_KQZLViewController ()
{

}
#pragma mark 刷新滚动视图
-(void)refreshScrollView;
@end

@implementation SKJC_KQZLViewController

@synthesize m_DataArr;
@synthesize m_cityArr;
@synthesize m_airForecstArray;

@synthesize m_CurrCityNameLabel;
@synthesize m_LocationImageView;
@synthesize m_pageControl;
@synthesize m_scrollView;

@synthesize m_currIndex;
@synthesize isHaveSearchCity;
-(id)init
{
    if (iPhone5)
    {
        self = [super initWithNibName:@"SKJC_KQZLViewController_ip5" bundle:nil];
    }
    else
    {
        self = [super initWithNibName:@"SKJC_KQZLViewController" bundle:nil];
    }
    isHaveSearchCity = NO;
    return self;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}


-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    int page = [[[NSUserDefaults standardUserDefaults] objectForKey:SKINDEXKEY] integerValue];
    if (page>=[self.m_cityArr count])
    {
        page = 0;
        [[NSUserDefaults standardUserDefaults] setValue:[NSString stringWithFormat:@"%d",0] forKey:SKINDEXKEY];
    }
    m_pageControl.currentPage = page;
    self.m_scrollView.contentOffset = CGPointMake(self.m_scrollView.frame.size.width*page, 0);
    if (self.m_cityArr && self.m_cityArr.count>page)
    {
        [self reLoadCityNameLabelFrame:[self.m_cityArr objectAtIndex:page] page:page];
    }
    
    [self.m_cityArr removeAllObjects];
    [self.m_DataArr removeAllObjects];
    [self.m_airForecstArray removeAllObjects];
    
    DBMSEngine *tempDBMSEngine = [[DBMSEngine alloc] init];
    for (DB_CityInfo*cityInfo in [tempDBMSEngine querryCityWeather])
    {
        if (!isHaveLocationCity&&cityInfo.db_islocation.length>0&&[cityInfo.db_islocation integerValue]==1)
        {
            isHaveLocationCity = YES;
        }
        
        NSDictionary*kqDic = [cityInfo.db_content JSONValue];
        if ([[kqDic objectForKey:K_air] count]>0)
        {
            [self.m_DataArr addObject:[[kqDic objectForKey:K_air] objectAtIndex:0]];
        }
        else
        {
            [self.m_DataArr addObject:[[NSDictionary alloc] init]];
        }
        if ([[kqDic objectForKey:K_airForecst] count]>0)
        {
            [self.m_airForecstArray addObject:[[kqDic objectForKey:K_airForecst] objectAtIndex:0]];
        }
        else
        {
            [self.m_airForecstArray addObject:[[NSDictionary alloc] init]];
        }
        
        [self.m_cityArr addObject:cityInfo.db_cityName];
    }
    if (page>=[self.m_cityArr count])
    {
        page = 0;
        [[NSUserDefaults standardUserDefaults] setValue:[NSString stringWithFormat:@"%d",0] forKey:SKINDEXKEY];
    }
    if (isHaveSearchCity)
    {
        [self addSearchPage:NO];
    }
    tempDBMSEngine = nil;
    if ([self.m_DataArr count]>0)
    {
        [self refreshScrollView];
    }
    else
    {
        [[NSUserDefaults standardUserDefaults] setValue:[NSString stringWithFormat:@"%d",0] forKey:SKINDEXKEY];
        m_pageControl.numberOfPages = [self.m_DataArr count];
        int page = [[[NSUserDefaults standardUserDefaults] objectForKey:SKINDEXKEY] integerValue];
        m_currIndex = page;
        m_pageControl.currentPage = page;
    }
    m_pageControl.currentPage = page;
    
    self.m_scrollView.contentOffset = CGPointMake(self.m_scrollView.frame.size.width*page, 0);
    if (self.m_cityArr && self.m_cityArr.count>page)
    {
        [self reLoadCityNameLabelFrame:[self.m_cityArr objectAtIndex:page] page:page];
    }
}

-(void)reLoadCityNameLabelFrame:(NSString*)aText page:(int)aCurrPage
{
    m_CurrCityNameLabel.text = aText;
    int length = [aText sizeWithFont:m_CurrCityNameLabel.font].width;
    
    if (aCurrPage==0&&isHaveLocationCity)
    {
        m_CurrCityNameLabel.frame = CGRectMake((320-(length+12))/2, m_CurrCityNameLabel.frame.origin.y, length, m_CurrCityNameLabel.frame.size.height);
        m_LocationImageView.hidden = NO;
        m_LocationImageView.frame =CGRectMake((320-(length+12))/2+length, m_LocationImageView.frame.origin.y, 12, 14);
    }
    else
    {
        m_CurrCityNameLabel.frame = CGRectMake(0, m_CurrCityNameLabel.frame.origin.y, 320, m_CurrCityNameLabel.frame.size.height);
        m_LocationImageView.hidden = YES;
    }
}

- (void)viewDidLoad
{
    [super viewDidLoad];

    
    if (self.m_DataArr==nil)
    {
        self.m_DataArr = [[NSMutableArray alloc] init];
    }
    if (self.m_cityArr==nil)
    {
        self.m_cityArr = [[NSMutableArray alloc] init];
    }
    self.m_airForecstArray = [[NSMutableArray alloc] init];
    [self.m_DataArr removeAllObjects];
    [self.m_cityArr removeAllObjects];
    self.navigationController.navigationBarHidden = YES;
    return;
    //刷新
    isHaveLocationCity = NO;
    
    int page = [[[NSUserDefaults standardUserDefaults] objectForKey:SKINDEXKEY] integerValue];
    DBMSEngine *tempDBMSEngine = [[DBMSEngine alloc] init];
    for (DB_CityInfo*cityInfo in [tempDBMSEngine querryCityWeather])
    {
        if (!isHaveLocationCity&&cityInfo.db_islocation.length>0&&[cityInfo.db_islocation integerValue]==1)
        {
            isHaveLocationCity = YES;
        }
        
        
        NSDictionary*kqDic = [cityInfo.db_content JSONValue];
        if ([[kqDic objectForKey:K_air] count]>0)
        {
            [self.m_DataArr addObject:[[kqDic objectForKey:K_air] objectAtIndex:0]];
        }
        else
        {
            [self.m_DataArr addObject:[[NSDictionary alloc] init]];
        }
        
        [self.m_cityArr addObject:cityInfo.db_cityName];
    }
    if (page>=[self.m_cityArr count])
    {
        page = 0;
        [[NSUserDefaults standardUserDefaults] setValue:[NSString stringWithFormat:@"%d",0] forKey:SKINDEXKEY];
    }
    if (isHaveSearchCity)
    {
        [self addSearchPage:NO];
    }
    tempDBMSEngine = nil;
    if ([self.m_DataArr count]>0)
    {
        [self refreshScrollView];
    }
    else
    {
        [[NSUserDefaults standardUserDefaults] setValue:[NSString stringWithFormat:@"%d",0] forKey:SKINDEXKEY];
        m_pageControl.numberOfPages = [self.m_DataArr count];
        int page = [[[NSUserDefaults standardUserDefaults] objectForKey:SKINDEXKEY] integerValue];
        m_currIndex = page;
        m_pageControl.currentPage = page;
        
    }
    m_pageControl.currentPage = page;
    
    self.m_scrollView.contentOffset = CGPointMake(self.m_scrollView.frame.size.width*page, 0);
    [self reLoadCityNameLabelFrame:[self.m_cityArr objectAtIndex:page] page:page];
    
}

#pragma mark --
#pragma mark 刷新滚动视图

-(void)refreshScrollView
{
    for (KQZKView*tempView in [self.m_scrollView subviews])
    {
        [tempView removeFromSuperview];
    }
    
    m_pageControl.numberOfPages = [self.m_DataArr count];
    int page = [[[NSUserDefaults standardUserDefaults] objectForKey:SKINDEXKEY] integerValue];
    m_currIndex = page;
    m_pageControl.currentPage = page;
    
    if (m_currIndex >=[self.m_DataArr count])
    {
        [[NSUserDefaults standardUserDefaults] setValue:[NSString stringWithFormat:@"%d",0] forKey:SKINDEXKEY];
        m_currIndex = 0;
    }
    self.m_scrollView.contentSize=CGSizeMake(self.m_scrollView.frame.size.width*[self.m_DataArr count], self.m_scrollView.frame.size.height);
    self.m_scrollView.contentOffset = CGPointMake(self.m_scrollView.frame.size.width*page, 0);

    //加载当前页
    [self addPage:m_currIndex];
    
    //延后加载，防止主线程阻塞UI
    double delayInSeconds = 1.0;
    dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delayInSeconds * NSEC_PER_SEC));
    dispatch_after(popTime, dispatch_get_main_queue(), ^(void)
                   {
                       for (int i = 0; i<[self.m_DataArr count]; i++)
                       {
                           if (i!=m_currIndex)
                           {
                               [self addPage:i];
                           }
                       }

                   });
}

-(void)addPage:(int)targetIndex
{
    KQZKView* aView = nil;
    if (iPhone5)
    {
        aView = (KQZKView*)[[[NSBundle mainBundle]loadNibNamed:@"KQZKView_ip5" owner:self options:nil]objectAtIndex:0];
    }
    else
    {
        aView = (KQZKView*)[[[NSBundle mainBundle]loadNibNamed:@"KQZKView" owner:self options:nil]objectAtIndex:0];
    }
    [aView setFrame:CGRectMake(self.m_scrollView.frame.size.width*targetIndex, 0, self.m_scrollView.frame.size.width, self.m_scrollView.frame.size.height)];
    aView.m_AirDataDic = [[self.m_DataArr objectAtIndex:targetIndex] copy];
    aView.m_AirDataDicNext = [[self.m_airForecstArray objectAtIndex:targetIndex] copy];;
    [aView loadView];
    [self.m_scrollView addSubview:aView];
}

-(void)addSearchPage:(BOOL)aScroll
{
    DBMSEngine *tempDBMSEngine = [[DBMSEngine alloc] init];
    if ([self.m_DataArr count] >[[tempDBMSEngine querryCityWeather] count])
    {
        [self.m_DataArr removeLastObject];
        [self.m_cityArr removeLastObject];
    }
    tempDBMSEngine = nil;
    if ([self.m_scrollView viewWithTag:9999]!=nil)//已经添加过筛选
    {
        NSDictionary*kqDic = [self readDictionaryToFile:@"tempSK"];
        if (kqDic&&[[kqDic objectForKey:K_air] count]>0)
        {
            
            KQZKView* aView = (KQZKView*)[self.m_scrollView viewWithTag:9999];
            
            isHaveSearchCity = YES;
            [self.m_DataArr addObject:[[kqDic objectForKey:K_air] objectAtIndex:0]];
            aView.m_AirDataDic = [[kqDic objectForKey:K_air] objectAtIndex:0];
            [self.m_cityArr addObject:[[kqDic objectForKey:K_cityInfo] objectForKey:K_cityName]];
            
            NSArray *airForectArray = [kqDic objectForKey:K_airForecst];
            if (airForectArray && airForectArray.count)
            {
                aView.m_AirDataDicNext = [airForectArray objectAtIndex:0];
            }
        }
    }
    else
    {
        NSDictionary*kqDic = [self readDictionaryToFile:@"tempSK"];
        if (kqDic&&[[kqDic objectForKey:K_air] count]>0)
        {
            isHaveSearchCity = YES;
            KQZKView* aView = nil;
            if (iPhone5)
            {
                aView = (KQZKView*)[[[NSBundle mainBundle]loadNibNamed:@"KQZKView_ip5" owner:self options:nil]objectAtIndex:0];
            }
            else
            {
                aView = (KQZKView*)[[[NSBundle mainBundle]loadNibNamed:@"KQZKView" owner:self options:nil]objectAtIndex:0];
            }
            [aView setFrame:CGRectMake(self.m_scrollView.frame.size.width*[self.m_DataArr count], 0, self.m_scrollView.frame.size.width, self.m_scrollView.frame.size.height)];
            aView.tag = 9999;
            [self.m_DataArr addObject:[[kqDic objectForKey:K_air] objectAtIndex:0]];
            aView.m_AirDataDic = [[kqDic objectForKey:K_air] objectAtIndex:0];
            [self.m_cityArr addObject:[[kqDic objectForKey:K_cityInfo] objectForKey:K_cityName]];
            NSArray *airForectArray = [kqDic objectForKey:K_airForecst];
            if (airForectArray && airForectArray.count)
            {
                aView.m_AirDataDicNext = [airForectArray objectAtIndex:0];
            }
            
            [aView layoutSubviews];
            [self.m_scrollView addSubview:aView];
            self.m_scrollView.contentSize=CGSizeMake(self.m_scrollView.frame.size.width*([self.m_DataArr count]), self.m_scrollView.frame.size.height);
        }

    }
    m_pageControl.numberOfPages = [self.m_DataArr count];
    if (aScroll&&m_pageControl.numberOfPages!=0)
    {
        int currPage = m_pageControl.numberOfPages-1;
        m_pageControl.currentPage = currPage;
        [self reLoadCityNameLabelFrame:[self.m_cityArr objectAtIndex:currPage] page:currPage];
        
        [[NSUserDefaults standardUserDefaults] setValue:[NSString stringWithFormat:@"%d",currPage] forKey:SKINDEXKEY];
        self.m_scrollView.contentOffset = CGPointMake(self.m_scrollView.frame.size.width*m_pageControl.currentPage, 0);
    }
}

#pragma mark --
#pragma mark UIScrollViewDelegate

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    int page = scrollView.contentOffset.x/scrollView.frame.size.width;
    m_pageControl.currentPage = page;
    [self reLoadCityNameLabelFrame:[self.m_cityArr objectAtIndex:page] page:page];
    [[NSUserDefaults standardUserDefaults] setValue:[NSString stringWithFormat:@"%d",page] forKey:SKINDEXKEY];
}

-(NSDictionary*)readDictionaryToFile:(NSString*)aFileName
{
    NSString *newPath = [NSString stringWithFormat:@"%@%@.plist",TEMPCITYPATH,aFileName];
    if (![self isFileExistAtPath:newPath])
    {
        return nil;
    }
    NSDictionary*dic = [[NSDictionary alloc] initWithContentsOfFile:newPath];
    return dic;
}

-(BOOL)isFileExistAtPath:(NSString*)fileFullPath
{
    BOOL isExist = NO;
    isExist = [[NSFileManager defaultManager] fileExistsAtPath:fileFullPath];
    return isExist;
}

@end
