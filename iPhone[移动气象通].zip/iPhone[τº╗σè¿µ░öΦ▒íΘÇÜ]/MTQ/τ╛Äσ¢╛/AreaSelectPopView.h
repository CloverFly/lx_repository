//
//  AreaSelectPopView.h
//  scMobileWeatherIn
//
//  Created by lesogo on 14-2-25.
//  Copyright (c) 2014年 Lesogo. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol AreaSelectPopViewDelegate <NSObject>

-(void)didSelectTableView:(NSString*)aSelectString :(NSString*)aNameString;

@end

@interface AreaSelectPopView : UIView
<UITableViewDataSource,UITableViewDelegate>
{
    UIImageView *backGroundImageView;//背景视图(有效区域)
    
    NSArray     *dataArray;
}

@property(nonatomic,strong) UIButton        *backButton;
@property(nonatomic,strong) UIWindow        *alertWindow;
@property(nonatomic,strong) UIWindow        *previousKeyWindow;

@property (nonatomic, assign)   id <AreaSelectPopViewDelegate> popViewDelegate;

@property(nonatomic,strong) NSArray     *dataArray;


-(void)showPopView;

@end
