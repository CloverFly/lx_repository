//
//  AreaSelectPopView.m
//  scMobileWeatherIn
//
//  Created by lesogo on 14-2-25.
//  Copyright (c) 2014年 Lesogo. All rights reserved.
//

#import "AreaSelectPopView.h"

typedef void (^AHAnimationCompletionBlock)(BOOL);
typedef void (^AHAnimationBlock)();

#define KTableViewH 44.0

@implementation AreaSelectPopView

@synthesize dataArray;


- (void)performDismissalAnimation
{
    self.backButton.alpha = 0;
    //返回处理
    AHAnimationCompletionBlock completionBlock = ^(BOOL finished)
	{
		// Remove relevant views.
		[self.superview removeFromSuperview];
		[self removeFromSuperview];
        
		// Restore previous key window and tear down our own window
		[self.previousKeyWindow makeKeyWindow];
		self.alertWindow = nil;
		self.previousKeyWindow = nil;
	};
    
    
    [UIView animateWithDuration:0.3
                          delay:0.0
                        options:UIViewAnimationOptionCurveEaseIn
                     animations:^
     {
         self.transform = CGAffineTransformConcat(self.transform, CGAffineTransformMakeScale(0.01, 0.01));
     }
                     completion:completionBlock];
}

-(void)showPopView
{
    CGRect screenBounds = [[UIScreen mainScreen] bounds];
	self.alertWindow = [[UIWindow alloc] initWithFrame:screenBounds];
	self.alertWindow.windowLevel = UIWindowLevelNormal;
	self.previousKeyWindow = [[UIApplication sharedApplication] keyWindow];
    [self.alertWindow makeKeyWindow];
	[self.alertWindow makeKeyAndVisible];
    
	// Create a new radial gradiant background image to do the screen dimming effect
    self.frame = self.alertWindow.bounds;
    [self.alertWindow addSubview:self];
    
    //背景关闭按钮
    self.backButton = [[UIButton alloc] initWithFrame:self.alertWindow.bounds];
    self.backButton.backgroundColor = [UIColor blackColor];
    self.backButton.alpha = 0.5;
    [self.backButton addTarget:nil action:@selector(performDismissalAnimation) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:self.backButton];
    
    
    CGSize sizess  = CGSizeMake(120, 289);
    CGFloat leftDistance = 10.0;
    CGFloat upDistance = 40.0+20;
    CGRect tempRect ;
    tempRect.origin.x = leftDistance;
    tempRect.origin.y = upDistance;
    tempRect.size = sizess;
    
    backGroundImageView = [[UIImageView alloc] initWithFrame:tempRect];
    backGroundImageView.userInteractionEnabled = YES;
    backGroundImageView.image = [UIImage imageNamed:@"MT_PopBg.png"];
    
    [self addSubview:backGroundImageView];
    
    [self initInterface];
}

-(void)initInterface
{
    self.dataArray = [[NSArray alloc] initWithObjects:
                      @"成都*12028",@"乐山*12109",@"甘孜*12150",@"阿坝*12168",
                      @"雅安*12142",@"内江*12100",@"绵阳*12049",@"南充*12057",
                      @"遂宁*12072",@"泸州*12084",@"资阳*12105",@"广元*12187",
                      @"达州*12064",@"德阳*12181",@"凉山*12124",@"宜宾*12090",
                      @"攀枝花*12042",@"巴中*12080",@"眉山*12118",@"广安*12075",
                      @"自贡*12046",@"其他*10040",nil];
    
    
    CGFloat upDistance = 10.0;
    CGFloat downDistance = 5.0;
    CGSize  tableSize = CGSizeMake(CGRectGetWidth(backGroundImageView.frame), CGRectGetHeight(backGroundImageView.frame)-upDistance-downDistance);
    
    CGRect tableRect;
    tableRect.origin.x = 0.0;
    tableRect.origin.y = upDistance;
    tableRect.size = tableSize;
    
    UITableView *tableView = [[UITableView alloc] initWithFrame:tableRect];
    tableView.backgroundColor = [UIColor clearColor];
    tableView.delegate = self;
    tableView.dataSource = self;
    tableView.separatorColor = [UIColor lightGrayColor];
    if (ISIOS7)
    {
        tableView.separatorInset = UIEdgeInsetsMake(5.0,0.0,5.0,0.0);
    }
    
    [backGroundImageView addSubview:tableView];
}

#pragma mark --
#pragma mark UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    //预报数据
    static NSString *identifier = @"identifiers";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
        cell.backgroundColor = [UIColor clearColor];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    
    NSArray *arrays = [[dataArray objectAtIndex:indexPath.row] componentsSeparatedByString:@"*"];
    if (arrays && [arrays count]==2)
    {
        cell.textLabel.text = [NSString stringWithFormat:@"%@",[arrays objectAtIndex:0]];
    }
    
    return  cell;
}

#pragma mark --
#pragma mark UITableViewDelegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return KTableViewH;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    if (_popViewDelegate && [_popViewDelegate respondsToSelector:@selector(didSelectTableView::)])
    {
        NSArray *arrays = [[dataArray objectAtIndex:indexPath.row] componentsSeparatedByString:@"*"];
        if (arrays && [arrays count]==2)
        {
            [_popViewDelegate didSelectTableView:[arrays objectAtIndex:1] :[arrays objectAtIndex:0]];
            [self performDismissalAnimation];
        }
    }
}

@end
