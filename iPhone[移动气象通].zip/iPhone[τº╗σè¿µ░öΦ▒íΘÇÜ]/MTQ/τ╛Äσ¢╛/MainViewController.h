//
//  MainViewController.h
//  AOWaterView
//
//  Created by akria.king on 13-4-10.
//  Copyright (c) 2013年 akria.king. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MessageUI/MessageUI.h>

#import "EGORefreshTableHeaderView.h"
#import "EGORefreshTableFooterView.h"
#import "AOWaterView.h"
#import "DataInfo.h"
#import "GetOnlyLocation.h"
#import "AreaSelectPopView.h"

@interface MainViewController : UIViewController
<EGORefreshTableDelegate,UIScrollViewDelegate,
AOWaterViewdelegate,AreaSelectPopViewDelegate,
GetOnlyLocationDelegate>
{
    //EGOHeader
    EGORefreshTableHeaderView *_refreshHeaderView;
    //EGOFoot
    EGORefreshTableFooterView *_refreshFooterView;
    
    
    //
    BOOL _reloading;
    BOOL    isHeaderRefush;//是否刷新全部数据
    NSString    *m_KeyString;//城市id
}

@property(nonatomic,strong)AOWaterView *aoView;
@property(nonatomic,strong)IBOutlet UILabel *m_TitleLabel;

@property(nonatomic,strong) GetOnlyLocation *m_GetOnlyLocation;
@property(nonatomic,strong) NSDictionary    *m_locationDictionary;//定位信息

-(IBAction)citySelectBtPressed:(id)sender;

@end
