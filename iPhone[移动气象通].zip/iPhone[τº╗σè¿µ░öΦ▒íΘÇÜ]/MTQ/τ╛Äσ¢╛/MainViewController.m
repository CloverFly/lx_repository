//
//  MainViewController.m
//  AOWaterView
//
//  Created by akria.king on 13-4-10.
//  Copyright (c) 2013年 akria.king. All rights reserved.
//

#import "MainViewController.h"
#import "Tu_ViewController.h"
#import "DataAccess.h"

#define KIndexUpdata            [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/上传图片/"]

@interface MainViewController ()<UIImagePickerControllerDelegate,UINavigationControllerDelegate,ASIHTTPRequestDelegate>
{
    UIActivityIndicatorView *_ActivityView;
    ASIFormDataRequest      *_httpPostRequest;
    NSMutableDictionary     *_dicArray;
    NSInteger _numberdie;//数据请求是多少页；
}

@property (weak, nonatomic) IBOutlet UIView *myView;//添加瀑布流的view
@property (weak, nonatomic) IBOutlet UIImageView *testImage;

- (IBAction)Camera:(UIButton *)sender;//调用相机
- (IBAction)photo:(UIButton *)sender;//调用相册

@end

@implementation MainViewController

@synthesize     aoView;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        // Custom initialization
    }
    return self;
}


-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

-(void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


//初始化
- (void)viewDidLoad
{
    [super viewDidLoad];
    _numberdie=1;
    
    m_KeyString = @"12028";
    
    //定位
    self.m_GetOnlyLocation  = nil;
    self.m_GetOnlyLocation = [[GetOnlyLocation alloc] initWithDelegate:self];
    [self.m_GetOnlyLocation startUpdateLocation];
    
    //菊花
    _ActivityView       =   [[UIActivityIndicatorView alloc]initWithActivityIndicatorStyle: UIActivityIndicatorViewStyleWhiteLarge];
    _ActivityView.frame =   CGRectMake(self.view.frame.size.width/2, self.view.frame.size.height/2, 20, 20);
    _ActivityView.color =   [UIColor whiteColor];
    
    [self.view addSubview:_ActivityView];
    
    _dicArray =[[NSMutableDictionary alloc]init];
    
    self.aoView = [[AOWaterView alloc] initWithDataArray:nil];
    self.aoView.delegate=self;
    self.aoView.aodelegate=self;
    
    if (iPhone5)
    {
        [self.aoView setFrame:CGRectMake(0 ,0, _myView.frame.size.width, _myView.frame.size.height-(ISIOS7?20:0))];
    }
    else
    {
        [self.aoView setFrame:CGRectMake(0 ,0, _myView.frame.size.width, _myView.frame.size.height-(ISIOS7?110:90))];
    }
    
    [self.myView addSubview:self.aoView];
    
    [self createHeaderView];
    
    //请求瀑布流的图片
    isHeaderRefush = YES;
    [self advicehttprequest];
}

#pragma mark --
#pragma mark --------------请求所有图片列表-------------------
/*!
 *@brief        请求所有图片列表
 *@function     advicehttprequest
 *@param        (void)
 *@return       (void)
 */
-(void)advicehttprequest
{
    NSURL *urlss = [NSURL URLWithString:[URL get_imagearrayDataUrl]];
    _httpPostRequest = [ ASIFormDataRequest requestWithURL:urlss];
    [_httpPostRequest setStringEncoding :NSUTF8StringEncoding];//设置数据类型为utf-8
    
    [_httpPostRequest setPostValue:m_KeyString forKey:K_cityId];
    NSString *pageNo=[NSString stringWithFormat:@"%d",_numberdie];
    [_httpPostRequest setPostValue:pageNo forKey:K_pageNo];
    [_httpPostRequest setPostValue:@"20" forKey:K_pageSize];
    [_httpPostRequest setPostValue:[Tools getTokenString] forKey:K_token];
    [_httpPostRequest setDelegate:self];
    _httpPostRequest.tag=34345;
    [_httpPostRequest setDidFinishSelector : @selector (responseComplete:)];
    [_httpPostRequest setDidFailSelector : @selector (responseFailed:)];
    [_httpPostRequest startAsynchronous];
    
    [_ActivityView startAnimating];
}

/*
 *实景上图图片
 */
-(void)Livetouphttprequest
{
    if (self.m_locationDictionary == nil)
    {
        UtilAlert(@"获取定位信息失败，无法上传您的美图",nil);
        return;
    }
    
    
    NSDictionary *Tokendic = [Tools readUserDefaultsInfo:K_token];
    NSDictionary *UserInfo = [Tools readUserDefaultsInfo:K_userLoactionInfo];
    NSString *token     =[Tokendic objectForKey:K_token];
    NSString *cityid    =[UserInfo objectForKey:K_cityCode];
    NSString *address   =[self.m_locationDictionary objectForKey:K_address];
    NSString *latitude  =[self.m_locationDictionary objectForKey:K_latitude];
    NSString *longitude =[self.m_locationDictionary objectForKey:K_longitude];
    
    //若下面的数据为空的话，返回上一个界面
    if (token == nil || cityid == nil)
    {
        return;
    }
    else
    {
        UtilAlert(@"您拍摄的美图正在上传中，请耐心等待!",nil);
        
        NSURL *urlss = [NSURL URLWithString:[URL get_LivetouploadDataUrl]];
        ASIFormDataRequest *httpPostRequest = [ ASIFormDataRequest requestWithURL:urlss];
        [httpPostRequest setStringEncoding :NSUTF8StringEncoding];//设置数据类型为utf-8
        [httpPostRequest setPostValue:cityid forKey:K_cityId];
        [httpPostRequest setPostValue:token forKey:K_token];
        [httpPostRequest setPostValue:latitude forKey:K_latitude];
        [httpPostRequest setPostValue:longitude forKey:K_longitude];
        [httpPostRequest setPostValue:@"1" forKey:K_system];
        [httpPostRequest setPostValue:@"jpg" forKey:K_fileSuffix];
        [httpPostRequest setPostValue:address forKey:K_address];
        [httpPostRequest setPostValue:[Tools getTokenString] forKey:K_token];
        [httpPostRequest setDelegate:self];
        NSData *imageData = UIImageJPEGRepresentation([Tools fixOrientation:_testImage.image],0.4);
        [httpPostRequest setData:imageData forKey:K_image];
        httpPostRequest.tag=34346;
        [httpPostRequest setDidFinishSelector : @selector (responseComplete:)];
        [httpPostRequest setDidFailSelector : @selector (responseFailed:)];
        [httpPostRequest startAsynchronous];
    }
}

//照相机按钮
- (IBAction)Camera:(UIButton *)sender
{
    if (self.m_locationDictionary == nil)
    {
        self.m_GetOnlyLocation = nil;
        self.m_GetOnlyLocation = [[GetOnlyLocation alloc] initWithDelegate:self];
        [self.m_GetOnlyLocation startUpdateLocation];
    }
    
    UIImagePickerController *imagePiceker=[[UIImagePickerController alloc]init];
    imagePiceker.delegate=self;
    if (![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera])
    {
        UIAlertView *alter=[[UIAlertView alloc] initWithTitle:nil message:@"照相机不能使用" delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil];
        [alter show];
        return;
    }
    else
    {
        [imagePiceker setSourceType:UIImagePickerControllerSourceTypeCamera];
    }
    [self presentViewController:imagePiceker animated:YES completion:nil];
}

// 调用相册
- (IBAction)photo:(UIButton *)sender
{
    if (self.m_locationDictionary == nil)
    {
        self.m_GetOnlyLocation = nil;
        self.m_GetOnlyLocation = [[GetOnlyLocation alloc] initWithDelegate:self];
        [self.m_GetOnlyLocation startUpdateLocation];
    }
    
    UIImagePickerController *imagePiceker=[[UIImagePickerController alloc]init];
    imagePiceker.delegate=self;
    if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeSavedPhotosAlbum]) {
        [imagePiceker setSourceType:UIImagePickerControllerSourceTypeSavedPhotosAlbum];
        
    }
    else
    {
        return;
    }
    [self presentViewController:imagePiceker animated:YES completion:nil];
}

//城市切换
-(IBAction)citySelectBtPressed:(id)sender
{
    AreaSelectPopView *popView = [[AreaSelectPopView alloc] init];
    popView.popViewDelegate = self;
    [popView showPopView];
}

//创建刷新头
-(void)createHeaderView
{
    [self removeHeaderView];
    
	_refreshHeaderView = [[EGORefreshTableHeaderView alloc] initWithFrame:
                          CGRectMake(0.0f, 0.0f - self.view.bounds.size.height,
                                     self.view.frame.size.width, self.view.bounds.size.height)];
    _refreshHeaderView.delegate = self;
	[self.aoView addSubview:_refreshHeaderView];
    
    [_refreshHeaderView refreshLastUpdatedDate];
}

//移除刷新头
-(void)removeHeaderView
{
    if (_refreshHeaderView && [_refreshHeaderView superview])
    {
        [_refreshHeaderView removeFromSuperview];
    }
    _refreshHeaderView = nil;
}

//设置刷新尾
-(void)setFooterView
{
    //UIEdgeInsets test = self.aoView.contentInset;
    // if the footerView is nil, then create it, reset the position of the footer
    CGFloat height = MAX(self.aoView.contentSize.height, self.aoView.frame.size.height);
    if (_refreshFooterView && [_refreshFooterView superview])
    {
        // reset position
        _refreshFooterView.frame = CGRectMake(0.0f,
                                              height,
                                              self.aoView.frame.size.width,
                                              self.view.bounds.size.height);
    }
    else
    {
        // create the footerView
        _refreshFooterView = [[EGORefreshTableFooterView alloc] initWithFrame:
                              CGRectMake(0.0f, height,
                                         self.aoView.frame.size.width,
                                         self.view.bounds.size.height)];
        _refreshFooterView.delegate = self;
        [self.aoView addSubview:_refreshFooterView];
    }
    
    if (_refreshFooterView)
    {
        [_refreshFooterView refreshLastUpdatedDate];
    }
}

-(void)removeFooterView
{
    if (_refreshFooterView && [_refreshFooterView superview])
    {
        [_refreshFooterView removeFromSuperview];
    }
    _refreshFooterView = nil;
}

//===============
//刷新delegate
#pragma mark -
#pragma mark data reloading methods that must be overide by the subclass

-(void)beginToReloadData:(EGORefreshPos)aRefreshPos
{
	_reloading = YES;
    
    if (aRefreshPos == EGORefreshHeader)
    {
        // pull down to refresh data
        //[self performSelector:@selector(refreshView) withObject:nil afterDelay:0.5f];
        _numberdie = 1;
        isHeaderRefush = YES;
        [self advicehttprequest];
    }
    else if(aRefreshPos == EGORefreshFooter)
    {
        isHeaderRefush = NO;
        [self advicehttprequest];
    }
}

#pragma mark -
#pragma mark method that should be called when the refreshing is finished

- (void)finishReloadingData
{
	_reloading = NO;
    
	if (_refreshHeaderView)
    {
        [_refreshHeaderView egoRefreshScrollViewDataSourceDidFinishedLoading:self.aoView];
    }
    
    if (_refreshFooterView)
    {
        [_refreshFooterView egoRefreshScrollViewDataSourceDidFinishedLoading:self.aoView];
        [self setFooterView];
    }
}

-(void)testFinishedLoadData
{
    [self finishReloadingData];
    [self setFooterView];
}

#pragma mark-
#pragma mark force to show the refresh headerView

-(void)showRefreshHeader:(BOOL)animated
{
	if (animated)
	{
		[UIView beginAnimations:nil context:NULL];
		[UIView setAnimationDuration:0.2];
		self.aoView.contentInset = UIEdgeInsetsMake(60.0f, 0.0f, 0.0f, 0.0f);
        // scroll the table view to the top region
        [self.aoView scrollRectToVisible:CGRectMake(0, 0.0f, 1, 1) animated:NO];
        [UIView commitAnimations];
	}
	else
	{
        self.aoView.contentInset = UIEdgeInsetsMake(60.0f, 0.0f, 0.0f, 0.0f);
		[self.aoView scrollRectToVisible:CGRectMake(0, 0.0f, 1, 1) animated:NO];
	}
    [_refreshHeaderView setState:EGOOPullRefreshLoading];
}


#pragma mark
#pragma mark UIImagePickerControllerDelegate 回调

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [self dismissViewControllerAnimated:YES completion:^{
        if (ISIOS7)
        {
            [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
        }
    }];
}

-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    UIImage* aImage;
    if (picker.sourceType == UIImagePickerControllerSourceTypeCamera)
    {
        aImage= [info objectForKey:@"UIImagePickerControllerOriginalImage"];
        UIImageWriteToSavedPhotosAlbum(aImage, self, nil, nil);
    }
    else
    {
        UIImage *selectedImage = [info objectForKey:UIImagePickerControllerOriginalImage];
        aImage=selectedImage;
    }
    
    NSString* imagePath = [NSString stringWithFormat:@"%@%@.jpg",KIndexUpdata,@"updataZQSB"];
    if ([[NSFileManager defaultManager]fileExistsAtPath:imagePath])
    {
        [[NSFileManager defaultManager]removeItemAtPath:imagePath error:nil];
    }
    self.testImage.image = aImage;
    CGFloat height = self.testImage.image.size.width<self.testImage.image.size.height?640/0.75:640/1.33;
    [self createThumbImage:self.testImage.image size:CGSizeMake(640, height) percent:0.9 toPath:imagePath];
    [self dismissViewControllerAnimated:YES completion:nil];
    
    [self Livetouphttprequest];
}

#pragma mark --
#pragma mark -----------------压缩图片-----------------

-(void)createThumbImage:(UIImage *)image size:(CGSize )thumbSize percent:(float)percent toPath:(NSString *)thumbPath
{
    CGSize imageSize = image.size;
    CGFloat width = imageSize.width;
    CGFloat height = imageSize.height;
    CGFloat scaleFactor = 0.0;
    CGPoint thumbPoint = CGPointMake(0.0,0.0);
    CGFloat widthFactor = thumbSize.width / width;
    CGFloat heightFactor = thumbSize.height / height;
    
    if (widthFactor > heightFactor)
    {
        scaleFactor = widthFactor;
    }
    else
    {
        scaleFactor = heightFactor;
    }
    
    CGFloat scaledWidth  = width * scaleFactor;
    CGFloat scaledHeight = height * scaleFactor;
    
    if (widthFactor > heightFactor)
    {
        thumbPoint.y = (thumbSize.height - scaledHeight) * 0.5;
    }
    else if (widthFactor < heightFactor)
    {
        thumbPoint.x = (thumbSize.width - scaledWidth) * 0.5;
    }
    
    UIGraphicsBeginImageContext(thumbSize);
    
    CGRect thumbRect = CGRectZero;
    thumbRect.origin = thumbPoint;
    thumbRect.size.width  = scaledWidth;
    thumbRect.size.height = scaledHeight;
    [image drawInRect:thumbRect];
    UIImage *thumbImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    NSData *thumbImageData = UIImageJPEGRepresentation(thumbImage, percent);
    [thumbImageData writeToFile:thumbPath atomically:NO];
}


#pragma mark
#pragma mark AOWaterViewdelegate

//点击图片跳往下一个界面
-(void)aoclick:(DataInfo *)data aodata:(UIButton *)sender
{
    [_httpPostRequest cancel];
    [_ActivityView stopAnimating];
    
    Tu_ViewController *vieCtr=[[Tu_ViewController alloc]init];
    vieCtr.imageid  =data.imageid;
    vieCtr.smellUrl = data.url;
    vieCtr.width    = data.width;
    vieCtr.height   = data.height;
    
    [self.navigationController pushViewController:vieCtr animated:YES];
}

#pragma mark -
#pragma mark UIScrollViewDelegate

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
	if (_refreshHeaderView)
    {
        [_refreshHeaderView egoRefreshScrollViewDidScroll:scrollView];
    }
	
	if (_refreshFooterView)
    {
        [_refreshFooterView egoRefreshScrollViewDidScroll:scrollView];
    }
}

- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate
{
	if (_refreshHeaderView)
    {
        [_refreshHeaderView egoRefreshScrollViewDidEndDragging:scrollView];
    }
	
	if (_refreshFooterView)
    {
        [_refreshFooterView egoRefreshScrollViewDidEndDragging:scrollView];
    }
}

#pragma mark -
#pragma mark EGORefreshTableDelegate

- (void)egoRefreshTableDidTriggerRefresh:(EGORefreshPos)aRefreshPos
{
	[self beginToReloadData:aRefreshPos];
}

- (BOOL)egoRefreshTableDataSourceIsLoading:(UIView*)view
{
	return _reloading; // should return if data source model is reloading
}

// if we don't realize this method, it won't display the refresh timestamp
- (NSDate*)egoRefreshTableDataSourceLastUpdated:(UIView*)view
{
	return [NSDate date]; // should return date data source was last changed
}

#pragma mark
#pragma mark GetOnlyLocationDelegate

-(void)getOnlyLocation:(GetOnlyLocation *)aGetLocation locationInfo:(NSDictionary*)aDictionary
{
    if (aDictionary)
    {
        self.m_locationDictionary = aDictionary;
    }
}

-(void)locationError
{
    self.m_locationDictionary = nil;
}

#pragma mark --
#pragma mark AreaSelectPopViewDelegate区域选择回调

-(void)didSelectTableView:(NSString*)aSelectString :(NSString*)aNameString
{
    if (aSelectString && [aSelectString isKindOfClass:[NSString class]])
    {
        m_KeyString = aSelectString;
        _numberdie = 1;
        isHeaderRefush = YES;
        [self advicehttprequest];
        
        self.m_TitleLabel.text = [NSString stringWithFormat:@"%@",aNameString];
    }
}

#pragma mark
#pragma mark ASIFormDataRequest回调

-(void)responseComplete:(ASIFormDataRequest*)request
{
    [_ActivityView stopAnimating];
    if (request.tag==34345)
    {
        //关闭刷新tips
        [self testFinishedLoadData];
        
        NSDictionary *dic = [[request responseString] JSONValue];
        if(dic)
        {
            [_dicArray addEntriesFromDictionary:dic];
            DataAccess *dataAccess= [[DataAccess alloc]init];
            NSMutableArray *dataArray = [dataAccess getDateArray:_dicArray];
            if (dataArray && [dataArray count])
            {
                _numberdie++;
                if (self.aoView)
                {
                    if (isHeaderRefush)
                    {
                        isHeaderRefush = NO;
                        [self.aoView refreshView:dataArray];
                    }
                    else
                    {
                        [self.aoView getNextPage:dataArray];
                    }
                }
            }
            else
            {
                if (isHeaderRefush)
                {
                    isHeaderRefush = NO;
                    [self.aoView refreshView:nil];
                    [self.aoView setContentSize:CGSizeMake(self.aoView.frame.size.width, self.aoView.frame.size.height+0.5)];
                }
            }
        }
        else
        {
            if (isHeaderRefush)
            {
                isHeaderRefush = NO;
                [self.aoView refreshView:nil];
                [self.aoView setContentSize:CGSizeMake(self.aoView.frame.size.width, self.aoView.frame.size.height+0.5)];
            }
        }
        [self setFooterView];
    }
    else if(request.tag == 34346)
    {
        UtilAlert(@"您拍摄的美图上传完成!",nil);

        _numberdie = 1;
        isHeaderRefush = YES;
        [self advicehttprequest];
    }
}

-( void )responseFailed:(ASIFormDataRequest*)request
{
    [_ActivityView stopAnimating];
    self.view.userInteractionEnabled = YES;
    if (request.tag == 34354)
    {
        //关闭刷新tips
        [self performSelector:@selector(testFinishedLoadData) withObject:nil afterDelay:0.3f];
        
        if (isHeaderRefush)
        {
            isHeaderRefush = NO;
            [self.aoView refreshView:nil];
            [self.aoView setContentSize:CGSizeMake(self.aoView.frame.size.width, self.aoView.frame.size.height+0.5)];
        }
    }
    else if(request.tag == 34346)
    {
        UtilAlert(@"网络繁忙请稍后再试!",nil);
    }
}


@end
