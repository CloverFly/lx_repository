//
//  TU_TableViewCell.h
//  TestLxLibC
//
//  Created by 袁光明 on 14-1-19.
//  Copyright (c) 2014年 Clover. All rights reserved.
//

#import <UIKit/UIKit.h>
@protocol TU_TableViewCelldelegate;

@protocol TU_TableViewCelldelegate <NSObject>

-(void)chicknamedieButton:(NSIndexPath *)indextPath;

@end

@interface TU_TableViewCell : UITableViewCell
@property(weak,nonatomic)NSIndexPath *indexPath;
@property(strong,nonatomic)id<TU_TableViewCelldelegate>idelegate;

@property (weak, nonatomic) IBOutlet UILabel        *arrayLable;//分割线
@property (weak, nonatomic) IBOutlet UIImageView    *photolieImage;//头像
@property (weak, nonatomic) IBOutlet UILabel        *timeLable;//时间


@end
