//
//  Tu_ViewController.h
//  AOWaterView
//
//  Created by apple on 14-1-18.
//  Copyright (c) 2014年 akria.king. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Tu_ViewController : UIViewController
<UIAlertViewDelegate,UIScrollViewDelegate>
{
    ASIFormDataRequest  *_httpPostRequest_image;
    ASIFormDataRequest  *_httpPostRequest1;
    ASIFormDataRequest  *_httpPostRequest2;
    ASIFormDataRequest  *_httpPostRequest3;
    ASIFormDataRequest  *_httpPostRequest4;
}

//获取数据
@property(strong,nonatomic)NSArray *dataArray;
@property(nonatomic,strong)NSString *mess;
//id
@property(nonatomic,strong)NSString *imageid;
@property(nonatomic,strong)NSString *smellUrl;
@property float width;
@property float height;

@end
