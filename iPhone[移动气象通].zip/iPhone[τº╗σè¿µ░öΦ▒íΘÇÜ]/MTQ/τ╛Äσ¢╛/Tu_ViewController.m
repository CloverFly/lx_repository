//
//  Tu_ViewController.m
//  AOWaterView
//
//  Created by apple on 14-1-18.
//  Copyright (c) 2014年 akria.king. All rights reserved.
//

#import "Tu_ViewController.h"
#import "UIImageView+WebCache.h"
#import "TU_TableViewCell.h"
#import "DetailTextView.h"
#import "UIColor+RGBColor.h"

@interface Tu_ViewController ()<UITableViewDataSource,UITableViewDelegate,UITextViewDelegate,TU_TableViewCelldelegate,UITextFieldDelegate>
{
    CGFloat keyboardHeight;
    UIActivityIndicatorView *_ActivityView;
    UIActivityIndicatorView *_ActivityViewtwo;
    NSDictionary            *_dicArray;
    NSDictionary            *_myself;
    float         imageheight;
    float         numberdie;
    BOOL          isheight;
    NSInteger     _arraytabhight;
    
}

@property (weak, nonatomic) IBOutlet UITableView *arrayTableView;//tableView
//上面半部分的数据；
@property (weak, nonatomic) IBOutlet UIImageView *myImage;//自己的头像
@property (weak, nonatomic) IBOutlet UILabel *myNmae;//自己的名字
@property (weak, nonatomic) IBOutlet UILabel *weatherLable;//天气状况
@property (weak, nonatomic) IBOutlet UILabel *addrLabler;//自己的地址
@property (weak, nonatomic) IBOutlet UILabel *mytimeLable;//我的时间的
@property (weak, nonatomic) IBOutlet UILabel *barMyNmaeButton;//导航栏上得名字的button
@property (weak, nonatomic) IBOutlet UIView  *middleView;//中间的View
@property (weak, nonatomic) IBOutlet UIView  *onMiddleView;//中间上面的View
@property (weak, nonatomic) IBOutlet UIView  *textView;//放textView的框
@property (weak, nonatomic) IBOutlet UIButton    *sendButton;//回复的按钮
@property (weak, nonatomic) IBOutlet UITextView  *inputText;//输入的textView
@property (weak, nonatomic) IBOutlet UIButton    *praiseButton;//点赞

@property (weak, nonatomic) IBOutlet UILabel        *browseLable;//浏览了多少次；
@property (weak, nonatomic) IBOutlet UILabel        *numberPraise;//被赞的次数
@property (weak, nonatomic) IBOutlet UIScrollView   *imageScollView;//scollView
@property (weak, nonatomic) IBOutlet UIView         *lastTextView;//text后面的view
@property (weak, nonatomic) IBOutlet UIImageView    *onImage;//显示图片的image
@property (weak, nonatomic) IBOutlet UIView         *topView; //弹出的view
@property (weak, nonatomic) IBOutlet UIImageView    *topImage;//弹出的image
@property (weak, nonatomic) IBOutlet UIScrollView   *topScollView;

- (IBAction)clickpraiseButton:(UIButton *)sender;//点击赞
- (IBAction)goBack:(UIButton *)sender;//返回上一页
- (IBAction)chicksendButton:(UIButton *)sender;//发布评论
- (IBAction)downloandButton:(UIButton *)sender;//下载

@end

@implementation Tu_ViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        // Custom initialization
    }
    return self;
}

-(void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    isheight=YES;
    //添加图片；
    _myself=[[NSDictionary alloc]init];
    
    //用来第一次加载图片
    NSURL *url=[NSURL URLWithString:_smellUrl];
    [_onImage setImageWithURL:url];
    
    CGRect rct = _onImage.frame;
    rct.size.height = _height*(320/ _width);
    _onImage.frame = rct;
    
    
    if (iPhone5)
    {
        rct = _topView.frame;
        rct.origin.y = 0;
        rct.size.height = (ISIOS7?568:548);
        _topView.frame = rct;
    }
    else
    {
        rct = _topView.frame;
        rct.origin.y = 0;
        rct.size.height = (ISIOS7?480:460);
        _topView.frame = rct;
    }
    
    [self calculateheight];
    
    //圆角
    _myImage.layer.cornerRadius=3;
    _myImage.layer.masksToBounds=YES;
    _onMiddleView.layer.cornerRadius=3;
    _arrayTableView.layer.cornerRadius=3;
    [_arrayTableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
    
    //菊花
    _ActivityView =[[UIActivityIndicatorView alloc]initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
    _ActivityView.color=[UIColor whiteColor];
    _ActivityView.center=CGPointMake(100, 100);
    _ActivityView.center=CGPointMake(self.view.frame.size.width/2, self.view.frame.size.height/2-60);
    [self.view addSubview:_ActivityView];
    
    //菊花two
    _ActivityViewtwo =[[UIActivityIndicatorView alloc]initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
    _ActivityViewtwo.color=[UIColor whiteColor];
    _ActivityViewtwo.center=CGPointMake(100, 100);
    _ActivityViewtwo.center=CGPointMake(self.view.frame.size.width/2, self.view.frame.size.height/2-60);
    [self.view addSubview:_ActivityViewtwo];
    
    
    //请求详细数据
    [self advicehttprequest];
    //请求评论列表
    [self advicecommenthttprequest];
    
}
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    //添加手势
    UISwipeGestureRecognizer *swipe=[[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(swipeGoBack:)];
    [self.view addGestureRecognizer:swipe];
    
    //添加键盘的监听
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillShow:)
                                                 name:UIKeyboardWillShowNotification
                                               object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillHide:)
                                                 name:UIKeyboardWillHideNotification
                                               object:nil];
    //添加inputtext的阴影；
    CALayer *layer=_lastTextView.layer;
    layer.borderColor=[UIColor whiteColor].CGColor;
    layer.borderWidth=1.0f;
    
    _lastTextView.layer.shadowColor=[UIColor lightGrayColor].CGColor;
    _lastTextView.layer.shadowOffset=CGSizeMake(0, 0) ;
    _lastTextView.layer.shadowOpacity=1;
    _lastTextView.layer.shadowRadius=1.0;
    //点击图片查看大图
    UITapGestureRecognizer *tap=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(chickImage)];
    [_onImage addGestureRecognizer:tap];
    
    UITapGestureRecognizer *taptwo=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(chickImagetwo)];
    [_topImage addGestureRecognizer:taptwo];
    
}

#pragma mark
#pragma mark 保存图片到相册

- (IBAction)downloandButton:(UIButton *)sender
{
    UIImageWriteToSavedPhotosAlbum(_onImage.image, nil, nil, nil);
    UtilAlert(@"图片以保存成功", nil);
}


#pragma mark
#pragma mark 点击图片把图片放大

-(void)chickImage
{
    [self.view endEditing:YES];
    [UIView animateWithDuration:0.5 animations:^{
        [_topView setHidden:NO];
    }];
    
}

#pragma mark
#pragma mark 点击图片把图片缩小

-(void)chickImagetwo
{
    
    [UIView animateWithDuration:0.5 animations:^{
        [_topView setFrame:CGRectMake(_topView.frame.size.width/2, _topView.frame.size.height/2, 0, 0)];
        _topView.alpha=0.1;
        
    }];
    double delayInSeconds = 0.5;
    dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delayInSeconds * NSEC_PER_SEC));
    dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
        [_topView setHidden:YES];
        [_topView setFrame:CGRectMake(0, 0,self.view.frame.size.width, self.view.frame.size.height)];
        [_topScollView setFrame:CGRectMake(0, 0, _topView.frame.size.width, _topView.frame.size.height)];
        _topView.alpha=1;
        _topScollView.zoomScale=1;
    });
    
}

#pragma mark 
#pragma mark 请求详细信息

-(void)advicehttprequest
{
    if (_httpPostRequest1)
    {
        [_httpPostRequest1 clearDelegatesAndCancel];
    }
    NSURL *urlss = [NSURL URLWithString:[URL get_twoimagearrayDataUrl]];
    _httpPostRequest1 = [ ASIFormDataRequest requestWithURL:urlss];
    [_httpPostRequest1 setStringEncoding :NSUTF8StringEncoding];//设置数据类型为utf-8
    [_httpPostRequest1 setPostValue:_imageid forKey:K_id];
    [_httpPostRequest1 setPostValue:[Tools getTokenString] forKey:K_token];
    [_httpPostRequest1 setDelegate:self];
    _httpPostRequest1.tag=7877;
    [_httpPostRequest1 setDidFinishSelector : @selector (responseComplete:)];
    [_httpPostRequest1 setDidFailSelector : @selector (responseFailed:)];
    [_httpPostRequest1 startAsynchronous];
    [_ActivityView startAnimating];
    
    
}


#pragma mark
#pragma mark 请求评论数据

-(void)advicecommenthttprequest
{
    [_ActivityViewtwo startAnimating];
    if (_httpPostRequest2)
    {
        [_httpPostRequest2 clearDelegatesAndCancel];
    }
    NSURL *urlss = [NSURL URLWithString:[URL get_commentsDataUrl]];
    _httpPostRequest2 = [ ASIFormDataRequest requestWithURL:urlss];
    [_httpPostRequest2 setStringEncoding :NSUTF8StringEncoding];//设置数据类型为utf-8
    [_httpPostRequest2 setPostValue:_imageid forKey:K_id];
    [_httpPostRequest2 setPostValue:[Tools getTokenString] forKey:K_token];
    [_httpPostRequest2 setPostValue:@"1" forKey:K_pageNo];
    [_httpPostRequest2 setPostValue:@"1000" forKey:K_pageSize];
    [_httpPostRequest2 setDelegate:self];
    _httpPostRequest2.tag=7878;
    [_httpPostRequest2 setDidFinishSelector : @selector (responseComplete:)];
    [_httpPostRequest2 setDidFailSelector : @selector (responseFailed:)];
    [_httpPostRequest2 startAsynchronous];
}


#pragma mark
#pragma mark 提交评论

-(void)advicewritehttprequest
{
    [_ActivityViewtwo startAnimating];
    if (_httpPostRequest3)
    {
        [_httpPostRequest3 clearDelegatesAndCancel];
    }
    NSURL *urlss = [NSURL URLWithString:[URL get_writeDataUrl]];
    _httpPostRequest3 = [ ASIFormDataRequest requestWithURL:urlss];
    [_httpPostRequest3 setStringEncoding :NSUTF8StringEncoding];//设置数据类型为utf-8
    [_httpPostRequest3 setPostValue:_imageid forKey:K_id];
    [_httpPostRequest3 setPostValue:[Tools getTokenString] forKey:K_token];
    [_httpPostRequest3 setPostValue:_inputText.text forKey:K_content];
    [_httpPostRequest3 setDelegate:self];
    _httpPostRequest3.tag=7879;
    [_httpPostRequest3 setDidFinishSelector : @selector (responseComplete:)];
    [_httpPostRequest3 setDidFailSelector : @selector (responseFailed:)];
    [_httpPostRequest3 startAsynchronous];
}

#pragma mark
#pragma mark 提交赞

-(void)advicezhanhttprequest
{
    if (_httpPostRequest4)
    {
        [_httpPostRequest4 clearDelegatesAndCancel];
    }
    NSURL *urlss = [NSURL URLWithString:[URL get_zhanDataUrl]];
    _httpPostRequest4 = [ ASIFormDataRequest requestWithURL:urlss];
    [_httpPostRequest4 setStringEncoding :NSUTF8StringEncoding];//设置数据类型为utf-8
    [_httpPostRequest4 setPostValue:_imageid forKey:K_id];
    [_httpPostRequest4 setPostValue:[Tools getTokenString] forKey:K_token];
    [_httpPostRequest4 setDelegate:nil];
    [_httpPostRequest4 startAsynchronous];
}

#pragma mark
#pragma mark 下载实景大图

-(void)downLoadImage:(NSString*)aUrl
{
    if (aUrl && [aUrl isKindOfClass:[NSString class]] && [aUrl length]>10)
    {
        NSString *imageSavePath = [Tools readDocumentsImageSavePath:aUrl];
        if ([Tools isFileExitPath:imageSavePath])
        {
            UIImage *imagedata = [UIImage imageWithContentsOfFile:imageSavePath];
            if (imagedata)
            {
                _topImage.image = imagedata;
                _onImage.image = imagedata;
                [self calculateheight];
            }
        }
        else
        {
            [_ActivityView startAnimating];
            if (_httpPostRequest_image)
            {
                [_httpPostRequest_image clearDelegatesAndCancel];
            }
            NSURL *urlss = [NSURL URLWithString:aUrl];
            _httpPostRequest_image = [ ASIFormDataRequest requestWithURL:urlss];
            [_httpPostRequest_image setStringEncoding :NSUTF8StringEncoding];//设置数据类型为utf-8
            _httpPostRequest_image.username = aUrl;
            [_httpPostRequest_image setDelegate:self];
            [_httpPostRequest_image setDidFinishSelector : @selector(responseComplete_image:)];
            [_httpPostRequest_image setDidFailSelector : @selector(responseFailed_image:)];
            [_httpPostRequest_image startAsynchronous];
        }
    }
}

#pragma mark 发布评论按钮

- (IBAction)chicksendButton:(UIButton *)sender
{
    if (_inputText.text.length==0)
    {
        UIAlertView *alter=[[UIAlertView alloc]initWithTitle:@"温馨提示"
                                                     message:@"输入的内容不能为空"
                                                    delegate:self
                                           cancelButtonTitle:nil
                                           otherButtonTitles:@"确定", nil];
        [alter show];
        return;
    }
    [self advicewritehttprequest];
    _inputText.text=nil;
    [self.view endEditing:YES];
}

#pragma mark 返回上一个页面

- (IBAction)goBack:(UIButton *)sender
{
    if (_httpPostRequest_image)
    {
        [_httpPostRequest_image clearDelegatesAndCancel];
    }
    if (_httpPostRequest1)
    {
        [_httpPostRequest1 clearDelegatesAndCancel];
    }
    if (_httpPostRequest2)
    {
        [_httpPostRequest2 clearDelegatesAndCancel];
    }
    if (_httpPostRequest3)
    {
        [_httpPostRequest3 clearDelegatesAndCancel];
    }
    if (_httpPostRequest4)
    {
        [_httpPostRequest4 clearDelegatesAndCancel];
    }
    
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark
#pragma mark 赞按钮

- (IBAction)clickpraiseButton:(UIButton *)sender
{
    [self advicezhanhttprequest];
    NSString *str = _numberPraise.text;
    NSInteger intger=str.intValue+1;
    
    self.praiseButton.userInteractionEnabled = NO;
    [self.praiseButton setBackgroundImage:[self.praiseButton backgroundImageForState:UIControlStateHighlighted] forState:0];
    
    _numberPraise.text=[NSString stringWithFormat:@"%d",intger];
}


#pragma mark ------------------判断scollView的高-----------------------
/*!
 *@brief       判断scollView的高
 *@function     calculateheight
 */
-(void)calculateheight
{
    if (_onImage != nil)
    {
        [UIView animateWithDuration:0.5 animations:^{
            
            NSInteger imgageHeight  = _onImage.frame.size.height;
            
            imgageHeight += 5.0;
            
            [_middleView setFrame:CGRectMake(_middleView.frame.origin.x, imgageHeight, _middleView.frame.size.width, _middleView.frame.size.height)];
            
            if (_arraytabhight < 191)
            {
                _arraytabhight=191;
            }
            
            [_arrayTableView setFrame:CGRectMake(_arrayTableView.frame.origin.x,imgageHeight +_middleView.frame.size.height, _arrayTableView.frame.size.width, _arraytabhight)];
            if (iPhone5)
            {
                [_imageScollView setContentSize:CGSizeMake(34, imgageHeight +_middleView.frame.size.height+_arraytabhight)];
            }
            else
            {
                [_imageScollView setContentSize:CGSizeMake(34, imgageHeight +_middleView.frame.size.height+_arraytabhight+88)];
            }
            [_arrayTableView reloadData];
        }];
    }
    
}

#pragma mark
#pragma mark 键盘监听 弹出、回收，

- (void)keyboardWillShow:(NSNotification *)notification
{
    NSDictionary *userInfo = [notification userInfo];
    NSValue *aValue = [userInfo objectForKey:UIKeyboardFrameEndUserInfoKey];
    
    CGRect keyboardRect = [aValue CGRectValue];
    keyboardRect = [self.view convertRect:keyboardRect fromView:nil];
    
    NSValue *animationDurationValue = [userInfo objectForKey:UIKeyboardAnimationDurationUserInfoKey];
    NSTimeInterval animationDuration;
    [animationDurationValue getValue:&animationDuration];
    
    [UIView animateWithDuration:animationDuration
                     animations:^{
                         CGRect frame = _textView.frame;
                         frame = _textView.frame;
                         frame.origin.y += keyboardHeight;
                         frame.origin.y -= keyboardRect.size.height;
                         _textView.frame = frame;
                         
                         keyboardHeight = keyboardRect.size.height;
                     }];
    
}
/*!
 *@brief        键盘监听，将要收回
 *@function     keyboardWillShow:
 *@param        sender
 *@return       (void)
 */
- (void)keyboardWillHide:(NSNotification *)notification
{
    
    NSDictionary *userInfo = [notification userInfo];
    
    NSValue *animationDurationValue = [userInfo objectForKey:UIKeyboardAnimationDurationUserInfoKey];
    NSTimeInterval animationDuration;
    [animationDurationValue getValue:&animationDuration];
    
    [UIView animateWithDuration:animationDuration
                     animations:^{
                         CGRect frame = _textView.frame;
                         frame.size.height += keyboardHeight;
                         frame = _textView.frame;
                         frame.origin.y += keyboardHeight;
                         _textView.frame = frame;
                         keyboardHeight = 0;
                         
                     }];
    
}

#pragma mark-
#pragma mark UITextFieldDelegate

-(BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    if ([text isEqualToString:@"\n"])
    {
        [textView resignFirstResponder];
        return NO;
    }
    return YES;
}

#pragma mark-
#pragma mark TU_TableViewCelldelegate method
/*!
 *@brief     点击tableView上的名字时触发
 *@function     chicknamedieButton:
 *@param        event  -点击事件
 *@return       (void)
 */
-(void)chicknamedieButton:(NSIndexPath *)indextPath;
{
    
}

#pragma mark-
#pragma mark UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (_dicArray)
    {
        return [[_dicArray objectForKey:@"total"] intValue];
    }
    return 0;
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *showCell=@"showCell";
    TU_TableViewCell *cell=[_arrayTableView dequeueReusableCellWithIdentifier:showCell];
    if (cell==nil)
    {
        cell=[[[NSBundle mainBundle]loadNibNamed:@"TU_TableViewCell" owner:nil options:nil]lastObject];
        [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
        cell.idelegate=self;
    }
    
    cell.indexPath=indexPath;
    //去掉第一个的线
    cell.arrayLable.hidden = (indexPath.row==0)?YES:NO;
    
    NSArray *commentArray = [_dicArray objectForKey:K_comment];
    if (commentArray && commentArray.count>indexPath.row)
    {
        NSDictionary *commentDictionary = [commentArray objectAtIndex:indexPath.row];
        if (commentDictionary)
        {            
            //用户头像
            NSString *imagePath = [NSString stringWithFormat:@"%@",[commentDictionary valueForKey:K_head]];
            [cell.photolieImage setImageWithURL:[NSURL URLWithString:imagePath]];
            cell.photolieImage.layer.cornerRadius=3;
            cell.photolieImage.layer.masksToBounds=YES;
            
            //用户名称和评论内容
            NSString *usernameString = [NSString stringWithFormat:@"%@",[commentDictionary valueForKey:K_source]];
            NSString *content = [NSString stringWithFormat:@"%@",[commentDictionary valueForKey:K_content]];
            NSMutableString *contentsource = [[NSMutableString alloc] init];
            [contentsource appendFormat:@"%@ :%@",usernameString,content];
            if (contentsource!=nil)
            {
                DetailTextView *ygblabel = [[DetailTextView alloc]initWithFrame:CGRectMake(60, 15, 202, 46)];
                [ygblabel setText:contentsource WithFont:[UIFont systemFontOfSize:12] AndColor:[UIColor blackColor]];
                [ygblabel setKeyWordTextArray:[NSArray arrayWithObjects:usernameString, nil]
                                     WithFont:[UIFont systemFontOfSize:12]
                                     AndColor:[UIColor getColorWithRed:73 andGreen:131 andBlue:250]];
                [cell.contentView addSubview:ygblabel];
                
            }
            
            //时间
            NSString *timePath = [NSString stringWithFormat:@"%@",[commentDictionary valueForKey:K_time]];
            cell.timeLable.text  = [Tools dateFormatTimeString:@"HH:mm" setString:timePath];
            _arraytabhight = _arrayTableView.contentSize.height;
        }
    }
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 75;
}

#pragma mark
#pragma mark UIScrollViewDelegate

- (UIView *)viewForZoomingInScrollView:(UIScrollView *)scrollView
{
    return _topImage;
}

#pragma mark
#pragma mark ASIFormDataRequest网络回调

/*!
 *@brief        请求成功
 *@function     responseComplete
 *@param        (void)
 *@return        request
 */
-( void )responseComplete:(ASIFormDataRequest*)request
{
    if (request.tag==7877)
    {
        [_ActivityView stopAnimating];
        _myself = [[request responseString] JSONValue];
        if(_myself)
        {
            imageheight = [NSString stringWithFormat:@"%@",[_myself objectForKey:K_height]].intValue ;
            float imagewidth = [NSString stringWithFormat:@"%@",[_myself objectForKey:K_width]].intValue ;
            
            numberdie = 320 / imagewidth;

            //下载实景大图
            [self downLoadImage:[_myself objectForKey:K_url]];
            
            if (ISIOS7)
            {
                CGRect rct = _imageScollView.frame;
                rct.origin.y = 62.0;
                _imageScollView.frame = rct;
                //[_imageScollView setFrame:CGRectMake(2, 62, _imageScollView.frame.size.width, _imageScollView.frame.size.height)];
            }
            
            CGRect rct = _onImage.frame;
            rct.size.height = imageheight*numberdie;
            _onImage.frame = rct;
            
            [_myImage setImageWithURL:[_myself objectForKey:K_head]];
            _myNmae.text=[NSString stringWithFormat:@"%@",[_myself objectForKey:K_userName]];
            _barMyNmaeButton.text=[NSString stringWithFormat:@"%@",[_myself objectForKey:K_userName]];
            NSString *timestr=[_myself objectForKey:K_time];
            _mytimeLable.text=[Tools dateFormatTimeString:@"yyyy/MM/dd HH:mm" setString:timestr];
            _addrLabler.text=[NSString stringWithFormat:@"%@",[_myself objectForKey:K_address]];
            _numberPraise.text=[NSString stringWithFormat:@"%@",[_myself objectForKey:K_good]];
            _browseLable.text=[NSString stringWithFormat:@"%@",[_myself objectForKey:K_browse]];
            NSDictionary *wher=[_myself objectForKey:K_weather];
            NSString *temp=[wher objectForKey:K_temp];
            NSString *weather_cn=[wher objectForKey:K_weather_cn];
            if (temp)
            {
                _weatherLable.text=[temp stringByAppendingFormat:@"%@%@",@"°C ",weather_cn];
            }
            NSString *zhan = [_myself objectForKey:K_handle];
            
            //判断能赞否
            self.praiseButton.hidden = NO;
            if (zhan && [zhan isEqual:[NSNumber numberWithInt:0]])
            {
                //不能赞
                self.praiseButton.userInteractionEnabled = NO;
                [self.praiseButton setBackgroundImage:[self.praiseButton backgroundImageForState:UIControlStateHighlighted] forState:0];
            }
            else
            {
                //能赞
                self.praiseButton.userInteractionEnabled = YES;
                [self.praiseButton setBackgroundImage:[self.praiseButton backgroundImageForState:UIControlStateSelected] forState:0];
            }
            [self calculateheight];
            
        }
        else
        {
            return;
        }
        
    }
    else if(request.tag==7878)
    {
        [_ActivityViewtwo stopAnimating];
        //请求评论数据
        _dicArray = [[request responseString] JSONValue];
        if(_dicArray)
        {
            [_arrayTableView reloadData];
            _arraytabhight = _arrayTableView.contentSize.height;
            [self calculateheight];
            
        }
    }
    else if(request.tag==7879)
    {
        [_ActivityViewtwo stopAnimating];
        //提交评论返回
        NSDictionary *dic = [[request responseString] JSONValue];
        if(dic)
        {
            [_arrayTableView reloadData];
            _arraytabhight = _arrayTableView.contentSize.height;
            [self advicecommenthttprequest];
        }
    }
}


-( void )responseFailed:(ASIFormDataRequest*)request
{
    if (request.tag==7877)
    {
        [_ActivityView stopAnimating];
    }
    else if (request.tag==7878)
    {
         [_ActivityViewtwo stopAnimating];
    }
    else if (request.tag==7879)
    {
    }
}

#pragma mark -
#pragma mark ASIFormDataRequest-背景图下载

-( void )responseComplete_image:(ASIFormDataRequest*)request
{
    [_ActivityView stopAnimating];
    NSData *imageData = [request responseData];
    UIImage *image = [UIImage imageWithData:imageData];
    if (image)
    {
        [Tools saveDocumentsImagData:imageData setFileName:request.username];
        _onImage.image = image;
        _topImage.image = image;
        [self calculateheight];
    }
}

-( void )responseFailed_image:(ASIFormDataRequest*)request
{
    [_ActivityView stopAnimating];
}

@end
